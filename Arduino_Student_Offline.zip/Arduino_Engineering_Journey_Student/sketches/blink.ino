// Blink the external LED connected to D8.
const byte ledPin = 8;
const unsigned long intervalMs = 1000;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  digitalWrite(ledPin, HIGH);
  delay(intervalMs);
  digitalWrite(ledPin, LOW);
  delay(intervalMs);
}
