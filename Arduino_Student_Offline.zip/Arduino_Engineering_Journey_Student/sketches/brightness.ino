const byte potPin = A0;
const byte ledPin = 9;

void setup() { pinMode(ledPin, OUTPUT); }

void loop() {
  int reading = analogRead(potPin);
  int duty = map(reading, 0, 1023, 0, 255);
  analogWrite(ledPin, duty);
}
