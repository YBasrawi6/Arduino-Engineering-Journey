#include <LiquidCrystal.h>

const byte temperaturePin = A0;
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

void setup() {
  lcd.begin(16, 2);
  lcd.setCursor(0, 0);
  lcd.print(F("Temperature:"));
}

void loop() {
  float volts = analogRead(temperaturePin) * (5.0f / 1024.0f);
  float celsius = (volts - 0.5f) * 100.0f;
  lcd.setCursor(0, 1);
  size_t columns = lcd.print(celsius, 1);
  columns += lcd.print(F(" C"));
  while (columns++ < 16) lcd.write(' ');
  delay(500);
}
