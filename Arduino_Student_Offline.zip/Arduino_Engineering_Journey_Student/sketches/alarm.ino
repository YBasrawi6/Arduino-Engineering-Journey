const byte pirPin = 2;
const byte ledPin = 9;
const byte piezoPin = 8;
bool previous = false;

void setup() {
  pinMode(pirPin, INPUT);
  pinMode(ledPin, OUTPUT);
  pinMode(piezoPin, OUTPUT);
}

void loop() {
  bool motion = digitalRead(pirPin) == HIGH;
  if (motion != previous) {
    digitalWrite(ledPin, motion ? HIGH : LOW);
    if (motion) {
      tone(piezoPin, 1200);
    } else {
      noTone(piezoPin);
    }
    previous = motion;
  }
  delay(30);
}
