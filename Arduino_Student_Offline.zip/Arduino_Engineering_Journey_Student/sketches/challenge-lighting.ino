const byte sensorPin = A0;
const byte ledPin = 9;
// Sample thresholds for this divider. Adjust after measuring your room.
const int turnOnBelow = 400;
const int turnOffAbove = 480;
bool lightOn = false;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  const int light = analogRead(sensorPin);
  if (light < turnOnBelow) lightOn = true;
  if (light > turnOffAbove) lightOn = false;
  digitalWrite(ledPin, lightOn ? HIGH : LOW);
  delay(40);
}
