const byte trigPin = 6;
const byte echoPin = 7;
const byte piezoPin = 8;
unsigned long lastBeep = 0;
bool wasNear = false;

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(piezoPin, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  unsigned long duration = pulseIn(echoPin, HIGH, 30000UL);
  float cm = duration * 0.0343f / 2.0f;
  bool valid = duration > 0 && cm >= 2 && cm <= 400;
  if (valid) {
    Serial.print(cm, 1);
    Serial.println(F(" cm"));
  } else {
    Serial.println(F("No valid echo"));
  }

  if (valid && cm < 30) {
    unsigned long period = cm < 10 ? 130UL : cm < 20 ? 300UL : 650UL;
    unsigned long now = millis();
    if (!wasNear || now - lastBeep >= period) {
      tone(piezoPin, 1200, 55);
      lastBeep = now;
    }
    wasNear = true;
  } else {
    noTone(piezoPin);
    wasNear = false;
  }
  delay(65);
}
