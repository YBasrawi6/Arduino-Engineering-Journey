const byte potPin = A0;
const byte motorPin = 9;

void setup() {
  pinMode(motorPin, OUTPUT);
  analogWrite(motorPin, 0);
}

void loop() {
  int duty = map(analogRead(potPin), 0, 1023, 0, 255);
  analogWrite(motorPin, duty);
  delay(10);
}
