#include <Servo.h>

const byte trigPin = 6;
const byte echoPin = 7;
const byte servoPin = 9;
const int openAngle = 95;
const int closedAngle = 15;
Servo gate;
bool open = false;
bool timingFar = false;
unsigned long farSince = 0;

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  gate.attach(servoPin);
  gate.write(closedAngle);
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  const unsigned long duration = pulseIn(echoPin, HIGH, 26000UL);
  const float cm = duration * 0.0343f / 2;
  const bool valid = duration && cm >= 2 && cm <= 400;
  if (valid && cm <= 15 && !open) {
    gate.write(openAngle);
    open = true;
  }
  if (open && valid && cm >= 20) {
    const unsigned long now = millis();
    if (!timingFar) {
      farSince = now;
      timingFar = true;
    } else if (now - farSince >= 2000UL) {
      gate.write(closedAngle);
      open = false;
      timingFar = false;
    }
  } else {
    timingFar = false;
  }
  delay(65);
}
