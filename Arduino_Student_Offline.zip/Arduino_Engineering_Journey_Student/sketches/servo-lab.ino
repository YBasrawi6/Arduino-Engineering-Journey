#include <Servo.h>

const byte potPin = A0;
const byte servoPin = 9;
// Simulation limits. Calibrate and narrow these before attaching a real load.
const int minAngle = 0;
const int maxAngle = 180;
Servo arm;

void setup() {
  arm.attach(servoPin);
  arm.write(90);
}

void loop() {
  int angle = map(analogRead(potPin), 0, 1023, minAngle, maxAngle);
  arm.write(angle);
  delay(20);
}
