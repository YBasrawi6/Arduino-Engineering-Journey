const byte tempPin = A0;
const byte fanPin = 9;
bool fanOn = false;

void setup() {
  pinMode(fanPin, OUTPUT);
  digitalWrite(fanPin, LOW);
}

void loop() {
  unsigned long sum = 0;
  for (byte sample = 0; sample < 16; ++sample) {
    sum += analogRead(tempPin);
    delay(5);
  }
  const float adcReference = 5.0f;  // Use the measured Uno 5V reference if needed.
  const float volts = (sum / 16.0f) * adcReference / 1024.0f;
  const float celsius = (volts - 0.5f) * 100.0f;
  if (celsius >= 30.0f) fanOn = true;
  if (celsius <= 28.0f) fanOn = false;
  digitalWrite(fanPin, fanOn ? HIGH : LOW);
  delay(125);
}
