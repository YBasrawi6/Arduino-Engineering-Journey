(() => {
  'use strict';
  const {escape} = globalThis.Workshop;
  const aliases = {
    resistor:'resistance مقاومة رزيستور أوم ohm',pot:'pot potentiometer wiper مقاومة متغيرة مقبض',
    capacitor:'cap electrolyte مكثف كابستور فاراد',ceramic:'ceramic cap مكثف خزفي سيراميك',
    film:'film cap مكثف فيلم',inductor:'coil ملف حث محث',diode:'rectifier دايود صمام ثنائي ديود',
    led:'diode light دايود مضيء لمبة مصباح ليد',rgb:'rgb ليد ألوان ألوان متعددة',
    button:'push button tactile زر ضاغط كبسة مفتاح لحظي',latch:'self locking latch DPDT زر قفل تثبيت',
    transistor:'BJT NPN 2N2222 ترانزستور ترنسيستور',mosfet:'MOSFET موسفت موسفيت ترانزستور gate drain source',
    relay:'relay ريليه ريلي مرحل مُرحِّل coil COM NO NC',dc:'driver محرك تيار مستمر جسر H bridge',
    'dc-motor':'DC motor موتور محرك سرعة مروحة',servo:'servo سيرفو محرك مؤازر SG90 زاوية',
    stepper:'stepper محرك خطوي ستيبر A4988',stepper28:'28BYJ-48 محرك خطوي',
    ultrasonic:'ultrasound ultrasonic HC SR04 HC-SR04 ألتراسونك التراسونك فوق صوتي حساس مسافة سونار',
    temp:'TMP36 temperature حسّاس حرارة درجة حرارة',pir:'PIR infrared حساس حركة حركة الإنسان',
    ldr:'LDR photoresistor مقاومة ضوئية حساس ضوء إضاءة',lcd:'LCD1602 16x2 LiquidCrystal شاشة عرض حروف تباين VO',
    'lcd-i2c':'I2C LCD شاشة محول SDA SCL',oled:'OLED display شاشة أوليد او ليد',
    buzzer:'buzzer piezo جرس صوت طنان صفارة',pwm:'pulse width modulation تعديل عرض النبضة عرض النبضة سطوع',
    i2c:'I²C IIC SCL SDA Wire ناقل اتصال',uart:'serial USART RX TX اتصال تسلسلي',
    spi:'MOSI MISO SCK CS COPI CIPO اتصال متزامن',interrupt:'attachInterrupt ISR مقاطعة المقاطعات',
    power:'power supply طاقة تغذية تيار فولت جهد مصدر',ground:'GND common ground أرضي أرضي مشترك',
    analog:'ADC analogRead دخل تناظري قراءة جهد مقسم جهد',digital:'GPIO digitalRead digitalWrite رقمي دخل خرج HIGH LOW',
  };
  const references = [
    ['breadboard','لوحة التجارب','Breadboard · Jumper wires','ثقوب شريط التغذية أسلاك توصيل','breadboard'],
    ['supply','مصادر التغذية','Power Bench','تيار فولت بطارية محول USB VIN 3.3V','supply'],
    ['power-effects','حاسبة مقاومة LED','Power calculators','أوم pull-up pull-down LED current تيار مقاومة','supply/explore'],
    ['recordings','تسجيلات الورشة','Workshop recordings','فيديو يوتيوب اليوم الأول اليوم الثاني video','recordings'],
  ];
  function normal(value) {
    return String(value || '').normalize('NFKD').toLowerCase()
      .replace(/\p{M}|\u0640/gu,'').replace(/[أإآٱ]/g,'ا').replace(/ؤ/g,'و').replace(/ئ|ى/g,'ي').replace(/ة/g,'ه')
      .replace(/[^\p{L}\p{N}]+/gu,' ').trim();
  }
  const itemText = item => [
    item.type, item.functionText, item.understand, item.project, item.output,
    ...(item.terminals?.map(([role])=>role) || []),
  ].filter(Boolean).join(' ');
  function entries() {
    const {items,groups}=globalThis.JourneyLabData;
    const board=globalThis.BoardData;
    const forItem=({id,title,type,...item})=>({
      title, type:type || 'مكوّن إلكتروني', href:'#journey/library/' + id,
      keywords:[id,aliases[id],itemText({type,...item}),groups.filter(group=>group.items.includes(id)).map(group=>group.title).join(' ')].join(' '),
      primary:[id,title,type,aliases[id]].join(' '),
    });
    const boardEntry=item => ({
      title:item.name || item.label || item.id, type:'Arduino Explorer', href:'#explorer/' + item.id,
      keywords:[item.id,aliases[item.id],item.type,item.why,item.features,item.example,item.use].flat().join(' '),
      primary:[item.id,item.name,item.label,aliases[item.id]].join(' '),
    });
    return [
      ...Object.values(items).map(forItem), ...[...board.pins,...board.parts,...board.groups].map(boardEntry),
      ...globalThis.MissionData.map((m,index)=>({
        title:m.title,type:'المشروع ' + String(index+1).padStart(2,'0'),href:'#journey/projects/' + m.id,
        primary:[m.id,m.title,m.focus].join(' '),keywords:[m.brief,m.skill,m.components.map(part=>part.name).join(' ')].join(' '),
      })),
      ...globalThis.Day2ChallengeData.map(task=>({
        title:task.title,type:'تحدٍّ هندسي',href:'#journey/final-challenge/' + task.id,primary:task.title + ' ' + task.en, keywords:task.brief,
      })),
      ...references.map(([id,title,type,keywords,path])=>({title,type,primary:id+' '+title+' '+type,keywords,href:'#journey/'+path})),
    ].map(entry=>({...entry, first:normal(entry.primary), all:normal(entry.primary+' '+entry.keywords)}));
  }
  let index;
  let query='';
  function search(value) {
    index ??= entries();
    const terms=normal(value).split(' ').filter(Boolean);
    if(!terms.length)return [];
    return index.filter(entry=>terms.every(term=>entry.all.includes(term))).map(entry=>({
      ...entry, score:terms.reduce((n,term)=>n+(entry.first.split(' ').includes(term)?4:entry.first.includes(term)?2:1),0),
    })).sort((a,b)=>b.score-a.score);
  }
  function mountSearch(host) {
    host.innerHTML = '<section class="surface student-search" aria-label="البحث في المكتبة الهندسية">' +
      '<label for="student-search-input">ابحث في المكتبة والمشاريع</label>' +
      '<div class="student-search-line"><input id="student-search-input" type="search" dir="auto" placeholder="مثال PWM أو مقاومة أو حساس مسافة" aria-controls="student-search-results" autocomplete="off">' +
      '<button class="secondary-button" type="button" data-student-clear>مسح</button></div>' +
      '<output role="status" data-student-search-count></output><ul id="student-search-results" class="student-search-results"></ul></section>';
    const input=host.querySelector('input');
    const output=host.querySelector('output');
    const hits=host.querySelector('ul');
    input.value=query;
    const render=()=>{
      query=input.value.slice(0,100);
      const active=normal(query);
      const results=search(query);
      output.textContent=active ? (results.length ? results.length+' نتيجة' : 'ما وجدنا نتائج. جرّب اسم القطعة أو الاختصار.') : '';
      hits.innerHTML=results.map(item=>'<li><a href="' + escape(item.href) + '"><bdi>' + escape(item.title) +
        '</bdi><span>' + escape(item.type) + '</span></a></li>').join('');
      hits.hidden=!results.length;
    };
    input.addEventListener('input',render);
    host.querySelector('button').addEventListener('click',()=>{input.value='';render();input.focus();});
    hits.addEventListener('click',()=>{query='';});
    render();
  }

  function recordings() {
    const rows=[
      ['day1','اليوم الأول','أساسيات Arduino، ومنافذ Uno، والتغذية والتجارب الأولى.'],
      ['day2','اليوم الثاني','اختيار القطع، وتصميم الدوائر، والمشاريع والتحديات.'],
    ];
    return '<header class="day2-heading"><h1 id="scene-title">تسجيلات الورشة</h1></header><div class="student-recordings">' +
      rows.map(([day,title,copy])=>{
        const url=globalThis.StudentLinks.recording(day);
        return '<article class="surface student-recording"><h2>' + title + '</h2><p>' + copy + '</p>' +
          (url ? '<a class="primary-button" href="' + escape(url) + '" target="_blank" rel="noopener noreferrer">شاهد على YouTube</a>' :
          '<p class="fine-print">يُضاف رابط التسجيل عند توفره.</p>') + '</article>';
      }).join('') + '</div>';
  }

  document.addEventListener('journey:context',event=>{
    const context=event.detail;
    if (context?.kind !== 'board' || !context.id) return;
    const panel=document.querySelector('#inspector');
    panel?.querySelector('.student-science')?.remove();
    panel?.insertAdjacentHTML('beforeend',globalThis.StudentScience.board(context.id));
  });
  globalThis.StudentCatalog={mountSearch,recordings,search};
})();
