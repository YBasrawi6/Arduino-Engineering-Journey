(() => {
  'use strict';

  const scenes = [
    ['idea','فكرة المشروع'],
    ['needs','احتياجات المشروع'],
    ['choose','اختيار القطعة'],
    ['shop','شراء القطع'],
  ];
  const items = [
    {role:'Input',name:'HC-SR04',copy:'يقيس مسافة السيارة.',src:'assets/photos/ultrasonic.webp'},
    {role:'Processing',name:'Arduino Uno',copy:'يقرر متى يفتح البوابة.',src:'assets/uno-r3.jpg'},
    {role:'Output',name:'Servo Motor',copy:'يحرّك ذراع البوابة.',src:'assets/photos/servo.webp'},
    {role:'Power',name:'DC Power Supply',copy:'يغذّي السيرفو بجهد وتيار مناسبين.',src:'assets/photos/lab-bench.webp'},
    {role:'Connections',name:'Breadboard + Wires',copy:'تربط القطع والإشارات.',src:'assets/photos/breadboard-top.webp',extra:'assets/photos/jumper-mm.webp'},
  ];
  const stores = ['AliExpress','Amazon.sa','Noon','متاجر الإلكترونيات المحلية','متاجر المكونات المتخصصة'];

  function image(src,name) {
    return '<img src="'+src+'" alt="'+name+'" decoding="async">';
  }

  function cards(basket) {
    return '<ul class="build-cards'+(basket ? ' build-basket' : '')+'">' + items.map(item =>
      '<li><div class="build-photo'+(item.extra ? ' build-photo-pair' : '')+'">' + image(item.src,item.name) +
      (item.extra ? image(item.extra,'أسلاك توصيل') : '') + '</div><div class="build-card-caption">' +
      (basket ? '<span class="build-count" aria-label="مجموعة واحدة">×1</span>' : '<bdi class="build-role">'+item.role+'</bdi>') +
      '<strong><bdi>'+item.name+'</bdi></strong>' + (basket ? '' : '<p>'+item.copy+'</p>') + '</div></li>').join('') + '</ul>';
  }

  function idea() {
    return '<div class="build-split"><div class="build-idea-copy"><h2>حدّد فكرة المشروع</h2>' +
      '<p class="stage-lead">أريد تصميم بوابة تفتح عندما تقترب منها سيارة.</p>' +
      '<p>متى تفتح؟ ومتى يكون إغلاقها مناسبًا؟</p></div><div class="build-story" aria-label="قياس اقتراب السيارة ثم تحريك البوابة">' +
      '<figure>'+image(items[0].src,items[0].name)+'<figcaption>يقيس المسافة</figcaption></figure>' +
      '<span class="build-story-arrow" aria-hidden="true">←</span>' +
      '<figure>'+image(items[2].src,items[2].name)+'<figcaption>يرفع ذراع البوابة</figcaption></figure></div></div>';
  }

  function needs() {
    return '<h2>حدّد احتياجات المشروع</h2>'+cards(false);
  }

  function choose() {
    const checks = [
      ['الوظيفة','هل تؤدي القطعة ما أحتاجه؟'],
      ['الجهد والتيار','ما جهد تشغيلها؟ كم تيارًا تحتاج؟'],
      ['التوافق','هل تتوافق إشارتها وتوصيلاتها مع Arduino؟'],
      ['القطع الإضافية','هل تحتاج Driver أو مصدرًا خاصًا أو قطعًا أخرى؟'],
      ['الحجم والأداء','هل يناسبني الحجم والمدى والدقة؟'],
      ['المصدر','هل أجد Datasheet أو شرحًا موثوقًا للموديل؟'],
    ];
    return '<div class="build-split"><div><h2>كيف تختار القطعة المناسبة؟</h2><ul class="build-checks">' +
      checks.map(([label,question]) => '<li><strong>'+label+'</strong><span>'+question+'</span></li>').join('') +
      '</ul></div><figure class="build-detail">'+image('assets/photos/lab-servo-wires.webp','قابس وأسلاك سيرفو') +
      '<figcaption>مثال السيرفو · تحقّق من ترتيب الأسلاك وجهد التغذية للنسخة التي ستشتريها.</figcaption></figure></div>';
  }

  function shop() {
    return '<h2>من أين أشتري القطع؟</h2><div class="build-shop-layout"><div class="build-shop-notes">' +
      '<ul class="build-stores" aria-label="أمثلة على أماكن الشراء">'+stores.map(name => '<li><bdi>'+name+'</bdi></li>').join('') +
      '</ul><p>ابحث باسم القطعة أو رقم الموديل، مثل <bdi>HC-SR04</bdi>. قارن المواصفات واقرأ التقييمات، وتحقّق من الجهد وأسماء الأطراف قبل الطلب.</p>' +
      '<dl class="build-kit"><div><dt>قطعة واحدة</dt><dd>مناسبة إذا عرفت الموديل وتحتاجه لمشروع محدد.</dd></div>' +
      '<div><dt><bdi>Components Kit</bdi></dt><dd>تشكيلة للتجارب. قارن محتوياتها بقائمة مشروعك وأكمل ما ينقص.</dd></div></dl></div>' +
      '<section class="build-cart" aria-label="سلة مشروع بوابة المواقف"><h3>سلة مشروع بوابة المواقف</h3>'+cards(true)+'</section></div>';
  }

  function link(id,label,attrs = '',buttonClass = 'secondary-button') {
    return '<a class="'+buttonClass+'" href="#journey/build/'+id+'"'+attrs+'>'+label+'</a>';
  }

  const content = {idea,needs,choose,shop};
  globalThis.HotfixBuild = {
    ids:scenes.map(([id]) => id),
    render(detail) {
      const selected = scenes.findIndex(([id]) => id === detail);
      const index = Math.max(0,selected);
      const [id] = scenes[index];
      const tabs = scenes.map(([key,label]) => link(key,label,key === id ? ' aria-current="step"' : '')).join('');
      return '<section class="build-chapter" data-build-scene="'+id+'">' +
        '<header class="build-title"><h1 id="scene-title"><bdi>Build Your Project</bdi><span>كيف تختار قطع مشروعك؟</span></h1>' +
        '<nav class="build-tabs" aria-label="مشاهد اختيار القطع">'+tabs+'</nav></header>' +
        '<article class="surface show-stage build-stage">'+content[id]()+'</article>' +
        '<nav class="build-navigation" aria-label="خطوات اختيار القطع">' +
        (index > 0 ? link(scenes[index-1][0],'المشهد السابق',' data-show-prev') : '') +
        (index < scenes.length-1 ?
          link(scenes[index+1][0],'المشهد التالي',' data-show-next','primary-button') :
          '<a class="primary-button" href="#journey/projects" data-show-next>المشاريع العملية</a>') +
        '</nav></section>';
    },
  };
})();
