(() => {
  'use strict';

  const { escape } = globalThis.Workshop;
  const photos = {
    button:['button',[['زوج A',31,62,17,79],['زوج B',63,57,81,78]]],
    latch:['latch',[['ست أرجل',63,46,78,30]]],
    slide:['lab-slide',[['Throw 1',34,45,20,28],['COM',40,40,40,22],['Throw 2',46,36,65,22]]],
    toggle:['lab-toggle-pins',[['LED GND',26,55,13,36],['+ / LOAD',48,77,73,85]]],
    relay:['relay',[['أرجل التوصيل',59,23,75,11]]],
    'relay-module':['relay-module',[['NO',14,64,10,87],['COM',20,71,28,94],['NC',26,77,50,91],['IN / 5V / GND',88,30,78,15]]],
    rgb:['lab-rgb-pins',[['COM (+)',25.6,86,42,89],['أرجل الألوان',23.3,52,45,54]]],
    stepper:['lab-stepper-wires',[['A+',42,91,29,85],['A−',91,45,78,24],['B+',65,78,48,71],['B−',84,62,73,49]]],
    stepper28:['lab-stepper28',[['موصل 5 أسلاك',29,71,15,51],['28BYJ-48',63,59,77,76]]],
    uln2003:['lab-uln2003',[['IN1–IN4',13,38,26,16],['GND / VCC',39,77,28,95],['5-pin Motor',69,43,78,17]]],
    fan:['lab-fan',[['طرفا التغذية',29,27,19,11]]],
    solenoid:['lab-solenoid',[['طرفا الملف',53,89,69,86]]],
    dht11:['lab-dht11',[['VCC',39,65,14,81],['DATA',44,65,33,88],['NC',49,65,60,88],['GND',54,65,79,80]]],
    dht22:['lab-dht22',[['VCC',44,73,17,77],['DATA',48,74,33,90],['NC',53,74,62,90],['GND',57,74,83,78]]],
    gas:['lab-gas-pins',[['أرجل الحساس',50,38,74,18]]],
    mpu6050:['mpu6050',[['VIN / GND',41,78,20,92],['SCL / SDA',53,78,63,92]]],
    rfid:['rfid',[['صف SPI والتغذية',49,13,51,30]]],
    color:['lab-color-pins',[['VIN / GND / I²C',52,53,66,31]]],
    lcd:['lab-lcd-back-labels',[['1 · VSS',66,33,69,15],['16 · K',35,33,30,15]]],
    'lcd-i2c':['lab-lcd-i2c-labels',[['DAT',69,65,49,86],['CLK',75,65,64,90],['3–5V',81,65,81,86],['GND',86,65,93,91]]],
    seven:['lab-seven-front',[['عرض المقاطع',46,38,65,20]]],
    'seven-multi':['lab-seven-multi-pins',[['مقاطع + خانات',51,55,72,82]]],
    tm1637:['lab-tm1637',[['موصل Grove',27,78,17,54]]],
    tft:['lab-tft-header',[['SPI + Power',50,76,75,72]]],
  };

  const row = (...labels) => labels;
  const inputSwitch = [row('Arduino D2 · INPUT_PULLUP','Switch','GND')];
  const motor28 = {
    title:'28BYJ-48 · ULN2003',
    pins:[['COM','مشترك الملفات. يصله موجب تغذية الموتور عبر موصل الدرايفر.'],['A · B · C · D','الأطراف الأربعة للملفات. يسحب كل مخرج طرفه إلى GND بالتتابع.']],
    figure:'unipolar', wires:[row('Motor supply +','Driver VCC'),row('Supply − + Uno GND','Driver GND')],
    check:'ركّب الفيشة باتجاهها الصحيح وتحقق من جهد الموتور المكتوب عليه. وحدة Joy-IT المصوّرة تأتي بموتور 5V. بعض نسخ 28BYJ-48 تتطلب 12V.',
    source:['دليل Joy-IT للمجموعة المصوّرة','https://joy-it.net/files/files/Produkte/SBC-Moto1/SBC-Moto1_Manual_2024-05-08.pdf'],
  };

  const dht = {
    title:'DHT · أربعة أطراف',
    pins:[['1 · VCC','تغذية الحساس.'],['2 · DATA','إشارة القراءة إلى منفذ رقمي.'],['3 · NC','اتركه بلا توصيل في الحساس المجرّد.'],['4 · GND','الأرضي.']],
    wires:[row('5V','VCC'),row('DATA','Arduino D7'),row('DATA','10 kΩ','VCC'),row('GND','Arduino GND')],
    check:'واجه الشبكة الأمامية والأرجل للأسفل لترى الترتيب من اليسار إلى اليمين. لوحات DHT الجاهزة قد تعيد ترتيب الأرجل وتضيف مقاومة السحب.',
    source:['توصيل DHT من Adafruit','https://learn.adafruit.com/dht/connecting-to-a-dhtxx-sensor'],
  };

  const relayContacts = [
    ['COM','الطرف المشترك الذي ينتقل بين المخرجين.'],
    ['NC','يتصل بـCOM والملف مطفأ.'],
    ['NO','يتصل بـCOM والملف شغّال.'],
  ];
  function motorDiagram(driver,signal,motor,ports) {
    const height = 26 + ports.length * 22;
    const midpoint = Math.floor(height / 2);
    const links = ports.map(([output,input],index) => {
      const y = 31 + index * 22;
      return '<path class="pin-wire" d="M285 ' + y + 'h130"/><text x="350" y="' + (y - 5) + '">' +
        escape(output + ' ↔ ' + input) + '</text>';
    }).join('');
    return '<svg viewBox="0 0 522 ' + height + '" role="img" aria-label="توصيل Arduino ودرايفر ' + escape(driver) +
      ' وأطراف الموتور">' +
      '<g class="pin-device"><rect x="3" y="8" width="90" height="' + (height-16) +
      '" rx="7"/><rect x="190" y="8" width="95" height="' + (height-16) +
      '" rx="7"/><rect x="415" y="8" width="104" height="' + (height-16) + '" rx="7"/></g>' +
      '<text x="48" y="' + (midpoint+4) + '">Arduino Uno</text><text x="237" y="' + (midpoint+4) + '">' +
      escape(driver) + '</text><text x="467" y="' + (midpoint+4) + '">' + escape(motor) + '</text>' +
      '<path class="pin-wire" d="M93 ' + midpoint + 'h97 m-7 -4 7 4-7 4"/><text x="142" y="' + (midpoint-7) + '">' +
      escape(signal) + '</text>' + links + '</svg>';
  }

  const diagram = {
    bipolar:motorDiagram('A4988','STEP / DIR','4-wire Motor',[['1A','A+'],['1B','A−'],['2A','B+'],['2B','B−']]),
    unipolar:motorDiagram('ULN2003','D8–D11','28BYJ-48',[['Motor +','COM'],['OUT1','A'],['OUT2','B'],['OUT3','C'],['OUT4','D']]),
    button:'<svg viewBox="0 0 430 135" role="img" aria-label="زوجان متصلان داخليًا مع مفتاح لحظي بينهما"><path class="pin-wire" d="M82 26V105 M348 26V105 M82 65h105 M242 65h106 M187 65l52-24"/><g class="pin-node"><circle cx="82" cy="26" r="5"/><circle cx="82" cy="105" r="5"/><circle cx="348" cy="26" r="5"/><circle cx="348" cy="105" r="5"/><circle cx="187" cy="65" r="4"/><circle cx="242" cy="65" r="4"/></g><text x="50" y="30">A1</text><text x="50" y="110">A2</text><text x="380" y="30">B1</text><text x="380" y="110">B2</text><text x="215" y="105">PRESS · A ↔ B</text></svg>',
    dpdt:'<svg viewBox="0 0 480 142" role="img" aria-label="مخطط وظيفي لقطبي DPDT ومفتاحين يتحركان معًا"><path class="pin-wire" d="M55 35h83l59-18M197 17h35m-35 38h35M55 104h83l59-18M197 86h35m-35 38h35"/><path class="pin-wire pin-mechanical" d="M116 39v60"/><g class="pin-node"><circle cx="138" cy="35" r="4"/><circle cx="197" cy="17" r="4"/><circle cx="197" cy="55" r="4"/><circle cx="138" cy="104" r="4"/><circle cx="197" cy="86" r="4"/><circle cx="197" cy="124" r="4"/></g><text x="44" y="31" text-anchor="end">COM A</text><text x="241" y="23" text-anchor="start">NC A</text><text x="241" y="60" text-anchor="start">NO A</text><text x="44" y="100" text-anchor="end">COM B</text><text x="241" y="92" text-anchor="start">NC B</text><text x="241" y="129" text-anchor="start">NO B</text><text x="375" y="77">DPDT · ON / ON</text></svg>',
  };

  const guides = {
    button:{
      title:'Push Button · زوجان داخليان',
      pins:[['A1 / A2','متصلان دائمًا في الجانب A.'],['B1 / B2','متصلان دائمًا في الجانب B. الضغط يصل A بـB.']],
      figure:'button', wires:inputSwitch,
      check:'افصل الكهرباء وافحص الاستمرارية دون ضغط لتعرف الزوجين، ثم اختر رجلًا واحدة من كل زوج. ركّب الزر على شق Breadboard.',
      source:['مرجع زر Omron B3F','https://components.omron.com/us-en/datasheet_pdf/A070-E1.pdf'],
    },
    latch:{
      title:'Self-locking · DPDT شائع',
      pins:[['COM A / B','طرف مشترك مستقل لكل مجموعة.'],['NC A / B','يتصل بكل COM في وضع المرجع، مثل الوضع المرفوع بعد التحقق.'],['NO A / B','يتصل بكل COM في وضع التثبيت الآخر.']],
      figure:'dpdt', wires:[row('Arduino D2 · INPUT_PULLUP','COM A → NO A','GND')],
      check:'مع فصل التغذية، رقّم الأرجل الست واختبر كل زوج في وضعي الزر بعد رفع إصبعك. في كل مجموعة، الرجل التي تبدّل اتصالها بين رجلين هي COM. الرسم وظيفي وترتيب صفوفه لا يمثل أماكن اللحام.',
    },
    slide:{
      title:'Slide Switch · SPDT',
      pins:[['COM','الرجل الوسطى في القطعة المصوّرة.'],['Throw 1 / 2','الطرفان الخارجيان؛ يتصل COM بأحدهما في كل وضع.']],
      wires:[row('COM','Arduino D2 · INPUT_PULLUP'),row('Throw 1','GND'),row('Throw 2','اتركه مفتوحًا')],
      check:'حرّك المنزلق وقِس بين الوسط وكل طرف خارجي لتعرف أي جهة تتصل في كل وضع.',
      source:['القطعة المصوّرة من Adafruit','https://www.adafruit.com/product/805'],
    },
    toggle:{
      title:'Toggle Switch · SPST مضيء',
      pins:[['+','يدخل جهد الحمل.'],['LOAD · رمز المصباح','خرج المفتاح إلى الحمل.'],['LED GND','الرجل الجانبية هي سالب لمبة المفتاح.']],
      wires:[row('مصدر DC +','+  →  LOAD','الحمل','GND'),row('LED GND','GND')],
      check:'افصل التغذية واستعمل الملتيميتر لتحديد الطرفين السفليين اللذين يتصلان عند التشغيل. في Toggle عادي من نوع SPDT، ينتقل COM بين طرفين؛ النوع المصوّر هنا يضم لمبة.',
      source:['مخطط المفتاح المصوّر من Adafruit','https://www.adafruit.com/product/3218'],
    },
    relay:{
      title:'Relay · دائرة الملف ودائرة الحمل',
      pins:[['Coil 1 / 2','طرفا الملف، يشغّلهما ترانزستور ودائرة حماية.'],...relayContacts],
      wires:[row('Arduino signal','Transistor driver','Coil'),row('5V coil supply','Coil','Transistor','GND'),row('مصدر الحمل +','COM → NO','حمل DC','سالب مصدر الحمل')],
      check:'افصل التغذية وحدد طرفي الملف بقياس مقاومة نحو 56Ω في النموذج المصوّر. بعدها طابق رسم الأرجل السفلي، واختبر COM مع NC ثم NO. ضع دايودًا عكسيًا على الملف، وشريطه نحو موجب التغذية.',
      source:['مخطط أسفل Relay المصوّر JZC-11F','https://cdn.sparkfun.com/assets/f/4/7/b/0/DS-00100-Relay_SPDT_Sealed.pdf'],
    },
    'relay-module':{
      title:'Relay Module · KY-019',
      pins:[['IN / S','إشارة تشغيل من Arduino.'],['VCC / GND','تغذية دائرة التحكم وأرضيها.'],...relayContacts],
      wires:[row('Uno D10','IN'),row('5V / GND','VCC / GND'),row('مصدر الحمل +','COM → NO','حمل DC','سالب مصدر الحمل')],
      check:'طابق كتابة NO وCOM وNC على مسامير الحمل. اختبر الاستجابة لـHIGH وLOW قبل توصيل الحمل، فبعض الوحدات تعمل عند LOW.',
      source:['Joy-IT KY-019 · التوصيل','https://sensorkit.joy-it.net/en/sensors/ky-019'],
    },
    rgb:{
      title:'RGB LED · ثلاثة ألوان وطرف مشترك',
      pins:[['R','الأحمر.'],['G','الأخضر.'],['B','الأزرق.'],['COM','مشترك القنوات. في القطعة المصوّرة هو الأنود الموجب.']],
      wires:[row('Common Anode: COM → +5V','R / G / B','ثلاث مقاومات','Arduino LOW للتشغيل'),row('Common Cathode: COM → GND','R / G / B','ثلاث مقاومات','Arduino HIGH للتشغيل')],
      check:'استخدم مقاومة مستقلة لكل لون. افحص ترتيب الألوان واتجاه المشترك بوضع Diode Test في الملتيميتر، أو بمصدر منخفض الجهد مع مقاومة حماية. قد لا يكفي جهد بعض الملتيميترات لإضاءة الأزرق.',
      source:['الـRGB المصوّرة من Adafruit','https://www.adafruit.com/product/302'],
    },
    stepper:{
      title:'4-wire Stepper · A4988',
      pins:[['A+ / A−','طرفا الملف الأول.'],['B+ / B−','طرفا الملف الثاني.']],
      figure:'bipolar', wires:[row('Arduino 5V / GND','VDD / GND'),row('Motor supply + / −','VMOT / GND')],
      check:'الأسلاك أطراف ملفات يتحكم فيها الدرايفر. قِس المقاومة والموتور مفصول لتحديد الزوجين. اضبط حد التيار. في لوحة Pololu صِل RST مع SLP لإبقائه HIGH، وضع مكثفًا 47µF على الأقل بين VMOT وGND قرب اللوحة. افصل الكهرباء قبل إعادة التوصيل.',
      source:['Pololu A4988 · التغذية والتوصيل','https://www.pololu.com/product/1182'],
      secondary:['Adafruit #324 · الملفان في الموتور المصوّر','https://www.adafruit.com/product/324'],
    },
    stepper28:motor28,
    uln2003:motor28,
    fan:{
      title:'DC Fan · التغذية والتحكم',
      pins:[['V+ / GND','تغذية المروحة المصوّرة ذات السلكين.'],['TACH','في مراوح ثلاثية أو رباعية محددة، يرسل نبضات تدل على السرعة.'],['PWM','مدخل التحكم بالسرعة في مروحة رباعية تدعمه.']],
      wires:[row('مصدر مناسب + / −','Fan V+ / GND'),row('4-wire only','PWM input + TACH output')],
      check:'حدّد أطراف الموصل من رقم الموديل قبل التغذية. طرف TACH خرج للقراءة. تحكّم بمدخل PWM طبقًا لمواصفات المروحة.',
    },
    solenoid:{
      title:'Solenoid DC · طرفا الملف',
      pins:[['Coil 1 / 2','سلكا الملف؛ يعمل الملف المجرد بتمرير التيار عبرهما.']],
      wires:[row('+V مناسب','Coil','MOSFET driver','GND'),row('Flyback diode','بين طرفي الملف · الشريط نحو +V')],
      check:'إذا أدمج الطراز دايودًا للحماية، اتبع القطبية المحددة له. غذّ الملف من مصدره المناسب وليس من منفذ الإشارة.',
    },
    dht11:dht,
    dht22:dht,
    gas:{
      title:'MQ-3 · القطعة المجرّدة مقابل الوحدة',
      pins:[['H / H','طرفا السخان.'],['A / A · B / B','زوجان مكرران يتصل بهما عنصر الاستشعار المقاوم.'],['AO / DO','في وحدة جاهزة فقط: AO جهد القياس وDO حد مضبوط بالمقارن.']],
      wires:[row('MQ-3 module VCC / GND','5V / GND حسب الوحدة'),row('Module AO','Arduino A0')],
      check:'حدد أرجل H وA وB من رسم أسفل الحساس، وميّز زوج السخان بالمقاومة قبل التغذية. القطعة المجرّدة تحتاج دائرة حمل وتسخين مناسبة.',
    },
    mpu6050:{
      title:'MPU6050 · لوحة Adafruit المصوّرة',
      pins:[['VIN / GND','تغذية اللوحة والأرضي.'],['3Vo','خرج منظم 3.3V في هذه اللوحة.'],['SDA / SCL','بيانات I²C والساعة.'],['INT / AD0','خرج مقاطعة واختيار عنوان I²C، حسب اللوحة.']],
      wires:[row('Uno A4 / A5','SDA / SCL'),row('Uno 5V / GND','VIN / GND')],
      check:'جهد VIN المذكور خاص بلوحة Adafruit المزودة بمنظم ومبدّل مستويات. لا تعممه على شريحة منفردة أو لوحة أخرى.',
      source:['Adafruit · Pinouts','https://learn.adafruit.com/mpu6050-6-dof-accelerometer-and-gyro/pinouts'],
    },
    rfid:{
      title:'RFID-RC522 · SPI',
      pins:[['SDA / NSS','اختيار القارئ في وضع SPI لهذا الموديل.'],['SCK · MOSI · MISO','الساعة، الإرسال إلى القارئ، والاستقبال منه.'],['RST · IRQ','إعادة ضبط وإشارة مقاطعة اختيارية.'],['3.3V / GND','تغذية 3.3V وأرضي.']],
      wires:[row('Uno D10 / D13 / D11','محول مستوى 5V → 3.3V','NSS / SCK / MOSI'),row('Uno D12','MISO'),row('Uno D9','محول مستوى 5V → 3.3V','RST')],
      check:'راقب كتابة الأطراف على اللوحة. استخدم مستويات 3.3V للإشارات الداخلة إلى القارئ؛ IRQ غير مستخدم في هذا المثال.',
      source:['Joy-IT · قارئ MFRC522','https://joy-it.net/en/products/SBC-RFID-RC522'],
    },
    color:{
      title:'TCS34725 · I²C',
      pins:[['VIN / GND','تغذية لوحة الحساس والأرضي.'],['SDA / SCL','بيانات I²C والساعة.'],['INT / LED','مقاطعة وتحكم بإضاءة اللوحة في هذا الطراز.']],
      wires:[row('Uno A4 / A5','SDA / SCL'),row('5V / GND','VIN / GND في لوحة Adafruit')],
      check:'اتبع الكتابة المطبوعة على اللوحة. تأكد من توافق الجهد قبل استعمال وحدة من مصنع آخر.',
      source:['Adafruit · Color Sensor Wiring','https://learn.adafruit.com/adafruit-color-sensors/assembly-and-wiring'],
    },
    lcd:{
      title:'LCD 16×2 · شريط الأرجل',
      pins:[['1 VSS · 2 VDD · 3 VO','أرضي، تغذية، وضبط التباين.'],['4 RS · 5 R/W · 6 E','أمر/بيانات، قراءة/كتابة، وتثبيت البيانات.'],['7–14 · D0–D7','نستخدم D4–D7 في وضع 4-bit.'],['15 A · 16 K','طرفا إضاءة الخلفية.']],
      asset:['temperature','مخطط LCD وTMP36'],
      check:'ابدأ من رقم 1 على اللوحة. الصورة الخلفية معكوسة مقارنة بواجهة الشاشة. في مثال الورشة R/W إلى GND واستخدم مقاومة للإضاءة إن تطلب الطراز.',
    },
    'lcd-i2c':{
      title:'LCD Backpack · I²C',
      pins:[['DAT / SDA','خط البيانات.'],['CLK / SCL','خط الساعة.'],['3–5V / GND','تغذية لوحة Adafruit المصوّرة وأرضيها.'],['LAT','يُستخدم مع SPI فقط في هذه اللوحة.']],
      wires:[row('Uno A4 / A5','DAT / CLK'),row('Uno 5V / GND','3–5V / GND')],
      check:'طابق كتابة الأطراف. عنوان لوحة Adafruit الافتراضي 0x20؛ لوحات أخرى قد تختلف في العنوان وترتيب الأطراف.',
      source:['Adafruit · LCD Backpack Pinouts','https://learn.adafruit.com/i2c-spi-lcd-backpack/pinouts'],
    },
    seven:{
      title:'7-Segment · مقاطع الرقم',
      pins:[['A–G','سبعة مقاطع LED.'],['DP','النقطة العشرية.'],['COM','أرضي للكاثود المشترك أو موجب للأنود المشترك.']],
      wires:[row('Digital Output','مقاومة لكل مقطع','A–G / DP'),row('COM','GND أو V+ حسب النوع')],
      check:'استخدم Diode Test أو مصدرًا منخفضًا مع مقاومة لاختبار كل مقطع وتحديد اتجاه المشترك. الترتيب الفعلي مكتوب في مخطط الطراز.',
    },
    'seven-multi':{
      title:'7-Segment · أربع خانات',
      pins:[['A–G / DP','خطوط المقاطع التي تتشاركها الخانات.'],['DIG1–DIG4','كل طرف مشترك يفعّل خانة مختلفة.']],
      wires:[row('مخارج المقاطع','مقاومات','A–G / DP'),row('مخارج اختيار الخانات','Digit driver','DIG1–DIG4')],
      check:'تأكد من مقطع واحد وخانة واحدة بمقاومة حماية قبل تشغيل الباقي. اختر درايفرًا يتوافق مع نوع المشترك والتيار.',
      source:['الشاشة المصوّرة من SparkFun','https://www.sparkfun.com/7-segment-display-4-digit-red.html'],
    },
    tm1637:{
      title:'TM1637 · موصل Grove',
      pins:[['CLK','الساعة.'],['DIO','البيانات.'],['VCC / GND','التغذية والأرضي.']],
      wires:[row('Uno D2 / D3','CLK / DIO'),row('Uno 5V / GND','VCC / GND في النموذج المصوّر')],
      check:'طابق كتابة موصل Grove. استخدم مكتبة TM1637؛ البروتوكول مختلف عن I²C.',
      source:['Seeed Studio · Grove 4-Digit Display','https://wiki.seeedstudio.com/Grove-4-Digit_Display/'],
    },
    tft:{
      title:'TFT · شاشة SPI',
      pins:[['SCK · MOSI · MISO','الساعة وخطا الإرسال والاستقبال.'],['TFT CS · D/C · RST','اختيار الشاشة، أمر/بيانات، وإعادة الضبط.'],['CCS','اختيار بطاقة SD، إن استُخدمت.'],['VIN / GND · LITE','تغذية اللوحة والأرضي والتحكم بإضاءة الخلفية.']],
      wires:[row('Uno D13 / D11','TFT SCK / MOSI'),row('Uno D10 / D9 / D8','TFT CS / D/C / RST'),row('Compatible power','VIN / GND')],
      check:'استخدم الكتابة المطبوعة على وحدة Adafruit. اللوحات المختلفة قد تحتاج تحويل مستوى إشارات 5V إلى 3.3V.',
      source:['Adafruit · TFT Pinouts','https://learn.adafruit.com/1-8-tft-display/pinouts'],
    },
  };

  function photo(item) {
    const entry = photos[item.id];
    if (!entry) return '';
    const [key,labels] = entry;
    const illustration = globalThis.StudentPublicMedia(key,item.title,escape);
    if (illustration) return illustration;
    const marker = 'hotfix-arrow-' + item.id;
    return '<figure class="final-part-photo hotfix-annotated"><img src="assets/photos/' + escape(key) +
      '.webp" alt="' + escape(item.title) + '" decoding="async">' +
      '<svg viewBox="0 0 100 100" preserveAspectRatio="none" class="final-photo-arrows" aria-hidden="true">' +
      '<defs><marker id="' + marker + '" markerWidth="4" markerHeight="4" refX="3" refY="2" orient="auto"><path d="M0 0 L4 2 L0 4 Z"/></marker></defs>' +
      labels.map(([,x,y,lx,ly]) => '<path d="M' + lx + ' ' + ly + ' L' + x + ' ' + y + '" marker-end="url(#' + marker + ')"/>').join('') + '</svg>' +
      labels.map(([name,,,x,y]) => '<bdi class="final-photo-label" style="--x:' + x + '%;--y:' + y + '%">' + escape(name) + '</bdi>').join('') + '</figure>';
  }

  function details(item) {
    const guide = guides[item.id];
    if (!guide) return '';
    return '<section class="final-part-circuit hotfix-pin-guide"><h3><bdi>' + escape(guide.title) + '</bdi></h3>' +
      '<dl class="final-part-pins">' + guide.pins.map(([pin,role]) => '<div><dt><bdi>' + escape(pin) + '</bdi></dt><dd>' +
        escape(role) + '</dd></div>').join('') + '</dl>' +
      (guide.figure ? '<figure class="hotfix-pin-diagram">' + diagram[guide.figure] + '</figure>' : '') +
      (guide.asset ? '<a href="assets/circuits/' + guide.asset[0] + '.svg" target="_blank" rel="noopener"><img src="assets/circuits/' +
        guide.asset[0] + '.svg" alt="' + escape(guide.asset[1]) + '"></a>' : '') +
      (guide.wires ?? []).map(wire => '<div class="final-circuit-path" dir="ltr">' +
        wire.map(label => '<bdi>' + escape(label) + '</bdi>').join('<i aria-hidden="true">─</i>') + '</div>').join('') +
      '<p class="hotfix-pin-check">' + escape(guide.check) + '</p>' +
      [guide.source,guide.secondary].filter(Boolean).map(([label,url]) => '<a class="hotfix-pin-source" href="' + escape(url) +
        '" target="_blank" rel="noopener noreferrer">' + escape(label) + '</a>').join('') + '</section>';
  }

  globalThis.HotfixPins = { photo, details, has: item => Boolean(guides[item.id]) };
})();

