// Workshop design permalinks and optional public recording URLs.
(() => {
  'use strict';
  const circuits = Object.freeze({
    "blink": "https://www.tinkercad.com/things/hkwb3ehavzE-01-led-basics-digital-output",
    "button-led": "https://www.tinkercad.com/things/gXSN3HprBsM-02-button-controlled-led-digital-input",
    "brightness": "https://www.tinkercad.com/things/fPXmLxD11nU-03-led-brightness-control-analog-and-pwm",
    "motor": "https://www.tinkercad.com/things/0CMjSiKeHdG-04-dc-motor-speed-control-mosfet-and-pwm",
    "servo-lab": "https://www.tinkercad.com/things/c4sgQLkpINo-05-servo-angle-control-potentiometer",
    "distance": "https://www.tinkercad.com/things/iHsg9HhNhHF-06-ultrasonic-distance-alarm-hc-sr04",
    "alarm": "https://www.tinkercad.com/things/bOkPOI141T1-07-motion-detection-alarm-pir-sensor",
    "temperature": "https://www.tinkercad.com/things/cCeKlSkESrt-08-digital-temperature-monitor-tmp36-and-lcd",
    "lighting": "https://www.tinkercad.com/things/1z0wlTr8k0b-09-challenge-01-smart-lighting",
    "parking": "https://www.tinkercad.com/things/em9TOxyzCie-10-challenge-02-smart-parking-gate",
    "fan": "https://www.tinkercad.com/things/cwv5iVKlYzk-11-challenge-03-automatic-cooling-fan"
  });
  const recordings = Object.freeze({day1:'',day2:''});
  function circuit(id) {
    try {
      const url = new URL(circuits[id]);
      const path = /^\/(?:things|embed)\/[A-Za-z0-9_-]+\/?$/.test(url.pathname);
      return url.protocol === 'https:' && ['www.tinkercad.com','tinkercad.com'].includes(url.hostname) &&
        path && !url.username && !url.password && !url.search && !url.hash ? url.href : '';
    } catch { return ''; }
  }
  function recording(day) {
    try {
      const url = new URL(recordings[day]);
      if (url.protocol !== 'https:' || url.username || url.password) return '';
      let id = '';
      if (url.hostname === 'youtu.be') id = url.pathname.slice(1);
      if (['www.youtube.com','youtube.com','m.youtube.com'].includes(url.hostname)) {
        id = url.pathname === '/watch' ? url.searchParams.get('v') : url.pathname.match(/^\/(?:live|shorts)\/([A-Za-z0-9_-]+)\/?$/)?.[1];
      }
      return /^[A-Za-z0-9_-]{11}$/.test(id || '') ? 'https://www.youtube.com/watch?v=' + id : '';
    } catch { return ''; }
  }
  function circuitAccess(id) {
    return ['temperature','lighting','parking','fan'].includes(id)
      ? 'الوصول إلى تصميم الورشة يحتاج إذنًا من مالكه. مخطط التوصيل والكود متاحان هنا.'
      : 'سجّل الدخول إلى Tinkercad لفتح الدائرة. مخطط التوصيل والكود متاحان هنا.';
  }
  globalThis.StudentLinks = {circuit,circuitAccess,recording};
})();
