(() => {
  'use strict';
  const { parts, modules, jumperTypes, powerTopics, prompts } = globalThis.LessonData;
  const { format, escape } = globalThis.Workshop;
  const credits = { ...globalThis.PhotoCredits, ...globalThis.JourneyLabCredits };
  const outlet = document.getElementById('lesson-page');
  const explorer = document.getElementById('explorer-page');
  const routeNames = {
    electronics: ['المكوّنات الأساسية', 'اختر مكوّنًا وافحص أطرافه قبل توصيله.'],
    wiring: ['لوحة التجارب والتوصيل', 'اضغط على أي ثقب لإضاءة الثقوب المتصلة به كهربائيًا.'],
    power: ['التغذية والسلامة الكهربائية', 'راجع الجهد والتيار والقطبية قبل تغذية الدائرة.'],
    modules: ['الحساسات والوحدات', 'من القياس إلى الحركة والعرض. اختر الوحدة لتتعرّف إلى توصيلها.'],
    projects: ['مشاريع Tinkercad Circuits', 'نفّذ التوصيلات في محرّر الدوائر، ثم اختبر سلوك المشروع.'],
    ai: ['الذكاء الاصطناعي مع Arduino', 'صف الدائرة بدقة ثم اختبر البرنامج خطوة بخطوة.'],
    challenges: ['تحديات الورشة', 'انتقل من اختيار منفذ إلى تصميم دائرة كاملة.'],
    references: ['المراجع والصور', 'مصادر التحقق الفني ونسب الأصول المستخدمة في الورشة.'],
  };
  const wire = { mode:'holes', split:false, pressed:false, selected:null, tabX:2, tabY:5, quiz:false, answer:null };
  let route = { page:'explorer', detail:'' };
  let promptIndex = 0;
  let latched = false;
  const photo = (key, alt, load = 'lazy') => '<img src="assets/photos/' + key + '.webp" alt="' + escape(alt) + '" loading="' + load + '">';
  const external = (href, label, cls = '') =>
    '<a' + (cls ? ' class="' + cls + '"' : '') + ' href="' + escape(href) + '" target="_blank" rel="noopener noreferrer">' + label + '</a>';
  const articleHead = (title, subtitle) => '<div class="page-intro"><div><h1 id="lesson-title">' + format(title) +
    '</h1><p>' + format(subtitle) + '</p></div></div>';
  const notes = (label, copy) => '<div class="note-row"><h3>' + label + '</h3><p>' + format(copy) + '</p></div>';
  const imageLink = key => external(credits[key].page, 'الصورة من <bdi>' + escape(credits[key].source) + '</bdi>');
  const activeLink = active => active ? ' aria-current="true"' : '';
  const linkedList = (data, selected, page) =>
    '<nav class="lesson-list surface" aria-label="مواضيع هذه الوحدة">' + data.map(item =>
      '<a href="#' + page + '/' + item.id + '"' + activeLink(item.id === selected) + '>' + photo(item.image, '') +
      '<span><bdi dir="ltr">' + escape(item.title) + '</bdi><small>' + escape(item.type || item.focus) + '</small></span></a>').join('') + '</nav>';

  function componentPage(page, detail) {
    const content = page === 'electronics' ? parts : modules;
    const item = content.find(entry => entry.id === detail) || content[0];
    globalThis.PresentationData.publish({kind:'lab',id:item.id,phase:'discover'});
    const lab = page === 'electronics' ? 'components' : 'sensors';
    return '<p class="reference-lab-link"><a class="secondary-button" href="#journey/' + lab + '/' + item.id +
      '">افتح القطعة في المختبر الكامل</a></p><div class="lesson-grid">' + linkedList(content, item.id, page) +
      '<article class="surface content-panel component-lesson"><div class="component-header"><figure>' +
      photo(item.image, 'صورة ' + item.title, 'eager') + '<figcaption>' + imageLink(item.image) + '</figcaption></figure>' +
      '<div><h2><bdi dir="ltr">' + escape(item.title) + '</bdi></h2><p class="inspector-type">' + escape(item.type) +
      '</p><p class="component-purpose">' + format(item.functionText) + '</p></div></div>' +
      '<div class="lesson-notes">' + notes('التوصيل والاستخدام', item.wiring) + notes('ما يجب التحقق منه', item.check) +
      notes('جرّب في الورشة', item.project) + '</div>' +
      (item.id === 'latch' ? '<div class="latch-demo"><div><h3>جرّب التبديل بين الحالتين</h3><p>تحتفظ الدائرة بحالتها بعد رفع إصبعك.</p></div>' +
        '<button type="button" class="latch-toggle" data-latch aria-pressed="' + latched + '">اضغط الزر</button><output class="latch-result" data-lit="' + latched + '" aria-live="polite">' +
        (latched ? 'المسار موصول' : 'المسار مفتوح') + '</output></div>' : '') + '</article></div>';
  }

  const letters = 'ABCDEFGHIJ';
  const railY = [46, 70, 345, 369];
  const rowsY = [...railY.slice(0, 2), ...Array.from({ length:10 }, (_, n) => 101 + 20 * n + (n >= 5 ? 46 : 0)), ...railY.slice(2)];
  const colX = col => 43 + 34 * col;
  function breadboardNet(col, row) {
    if (row >= 2 && row < 12) return (row < 7 ? 'upper-' : 'lower-') + col;
    return 'rail-' + row + (wire.split ? (col < 7 ? '-left' : '-right') : '');
  }
  function breadboardHoles() {
    return rowsY.map((y, row) => Array.from({ length:14 }, (_, col) => {
      const hit = breadboardNet(col, row);
      const label = row >= 2 && row < 12 ? letters[row - 2] + String(col + 1)
        : (row < 2 ? 'علوي' : 'سفلي') + ' ' + (row % 2 === 0 ? 'موجب' : 'سالب') + ' ' + (col + 1);
      return '<g role="button" tabindex="' + (col === wire.tabX && row === wire.tabY ? '0' : '-1') + '" aria-label="' + label +
        '" aria-pressed="false" data-hole="' + col + ',' + row + '" data-net="' + hit + '" transform="translate(' + colX(col) + ' ' + y + ')">' +
        '<rect class="hole-hit" x="-15" y="-10" width="30" height="20"></rect><circle r="4.1" class="hole-core"></circle></g>';
    }).join('')).join('');
  }

  function overlay() {
    if (wire.mode === 'led') {
      return '<g class="circuit-overlay"><path class="wire-blue" d="M18 158H77V121M77 121L87 111H103L112 119V135H146L179 101"/>' +
        '<rect class="resistor-body" x="101" y="125" width="54" height="19" rx="6"/><path class="resistor-bands" d="M111 125v19m9-19v19m8-19v19m15-19v19"/>' +
        '<path class="wire-red" d="M179 121V146h23m22 0h23v-25"/><ellipse cx="213" cy="145" rx="15" ry="11" class="demo-led"/>' +
        '<path class="wire-ground" d="M247 161H257V309H315V369"/><text x="84" y="111" class="diagram-label">220 Ω</text><text x="26" y="151" class="diagram-label">D8</text><text x="327" y="389" class="diagram-label">GND</text></g>';
    }
    if (wire.mode === 'button') {
      return '<g class="circuit-overlay"><path class="wire-blue" d="M18 138H145V181"/><path class="wire-ground" d="M179 247V310H315V369"/>' +
        '<path class="wire-blue" d="M145 181V200h34v19"/><path class="wire-ground" d="M179 247V231"/>' +
        '<rect class="switch-body" x="133" y="189" width="63" height="49" rx="6"/><circle cx="163" cy="214" r="13" class="switch-cap' + (wire.pressed ? ' pressed' : '') + '"/>' +
        '<circle cx="145" cy="181" r="5" class="wire-node"/><circle cx="179" cy="247" r="5" class="wire-node"/>' +
        '<text x="28" y="128" class="diagram-label">D2</text><text x="327" y="390" class="diagram-label">GND</text></g>';
    }
    if (wire.mode === 'ground') {
      return '<g class="circuit-overlay"><path class="wire-ground" d="M77 313H111V369 M216 313H213V369"/>' +
        '<circle cx="111" cy="369" r="6" class="wire-node"/><circle cx="213" cy="369" r="6" class="wire-node"/>' +
        '<rect x="33" y="292" width="84" height="24" rx="5" class="terminal-label"/><text x="75" y="307" class="diagram-label" text-anchor="middle">UNO GND</text>' +
        '<rect x="174" y="292" width="86" height="24" rx="5" class="terminal-label"/><text x="217" y="307" class="diagram-label" text-anchor="middle">DC (−)</text></g>';
    }
    return '';
  }

  function statusForHole(col, row) {
    if (row >= 2 && row < 12) {
      return 'العمود ' + (col + 1) + ' · ' + (row < 7 ? 'A–E' : 'F–J') + ' · خمس فتحات متصلة على جانب واحد من الشق.';
    }
    const polarity = row % 2 === 0 ? 'الموجب' : 'السالب';
    return 'الخط ' + polarity + (row < 2 ? ' العلوي' : ' السفلي') + ' · ' + (wire.split
      ? 'هذا الجزء معزول عن النصف الآخر في النموذج المقسوم.' : 'خط متصل على طوله في هذا النموذج.');
  }
  const wireExplanation = () => wire.mode === 'led'
    ? 'يمر التيار من [D8] عبر [220 Ω] إلى أنود المصباح، ثم من الكاثود إلى خط [GND]. تأكد من وضع كل طرف في مجموعة ثقوب مناسبة.'
    : wire.mode === 'button'
      ? 'يمر المسار من [D2] إلى [GND] عند ضغط الزر. استخدم [INPUT_PULLUP] وركّب الزر عبر الشق بعد فحص أزواج الأرجل.'
      : wire.mode === 'ground'
        ? 'اربط أرضي [Uno] وسالب المصدر على نفس خط الأرضي حتى يفهم الدرايفر إشارة التحكم.'
        : 'خمس فتحات متصلة في كل عمود على جانب واحد. يفصل الشق بين الجانبين. خطوط الطاقة مستقلة، وقد تنقسم في منتصف بعض اللوحات.';
  function wiringPage() {
    const railLines = railY.map((y, n) =>
      '<path class="rail-track ' + (n % 2 === 0 ? 'positive' : 'negative') + '" d="' +
      (wire.split ? 'M29 ' + y + 'H247 M282 ' + y + 'H499' : 'M29 ' + y + 'H499') + '"/>').join('');
    const nums = Array.from({ length:14 }, (_, n) => '<text x="' + colX(n) + '" y="88" text-anchor="middle">' + (n+1) + '</text>').join('');
    const rowLabels = Array.from(letters, (name,n) => '<text x="19" y="' + (rowsY[n+2]+3) + '" text-anchor="middle">' + name + '</text>').join('');
    return '<div class="audience-wiring-tabs" role="group" aria-label="مشهد لوحة التجارب">' +
      [['holes','اتصال الثقوب'],['photo','اللوحة من الداخل'],['jumpers','أنواع الأسلاك']].map(([id,label]) =>
        '<button type="button" class="secondary-button" data-wire-view="' + id + '" aria-pressed="' +
        (outlet.dataset.wireView === id || (!outlet.dataset.wireView && id === 'holes')) + '">' + label + '</button>').join('') +
      '</div><div class="lesson-wide-grid wiring-layout"><section class="surface content-panel wiring-model"><div class="subpage-toolbar"><h2>خريطة التوصيلات</h2>' +
      '<div class="mode-bar breadboard-modes" role="group" aria-label="حالة نموذج لوحة التجارب">' +
      [['holes','الفتحات'],['led','مصباح ومقاومة'],['button','زر لحظي'],['ground','أرضي مشترك']].map(([id,label]) =>
        '<button type="button" data-wire-mode="' + id + '" aria-pressed="' + (wire.mode === id) + '">' + label + '</button>').join('') + '</div></div>' +
      '<div class="breadboard-diagram"><svg viewBox="0 20 540 382" role="group" aria-label="نموذج تفاعلي للوحة تجارب، استخدم الأسهم للتنقل بين الثقوب">' +
      '<rect width="523" height="360" x="6" y="27" rx="13" class="breadboard-outline"/><rect x="24" width="481" y="192" height="45" rx="5" class="breadboard-gap"/>' +
      '<text x="265" y="219" class="diagram-label" text-anchor="middle">شق يفصل الجانبين</text>' +
      railLines + '<g class="diagram-label">' + nums + rowLabels +
      '<text x="507" y="50">+</text><text x="507" y="73">−</text><text x="507" y="350">+</text><text x="507" y="372">−</text></g>' +
      breadboardHoles() + overlay() + '</svg></div>' +
      '<p class="wiring-explanation">' + format(wireExplanation()) + '</p><div class="wire-feedback" data-wire-status role="status">اختر فتحة لفحص مسارها.</div>' +
      '<div class="wiring-controls"><label><input type="checkbox" data-split ' + (wire.split ? 'checked' : '') + '> افصل خطوط التغذية في المنتصف</label>' +
      (wire.mode === 'button' ? '<button class="primary-button" data-wire-press aria-pressed="' + wire.pressed + '">بدّل حالة الزر</button> <output data-wire-signal><bdi>' +
        (wire.pressed ? 'LOW' : 'HIGH') + '</bdi></output>' : '') + '</div>' +
      '<div class="wire-challenge"><button type="button" class="secondary-button" data-wire-quiz aria-pressed="' + wire.quiz + '">' +
      (wire.quiz ? 'إنهاء التحدي' : 'تحدّي الاتصال') + '</button><p data-wire-quiz-feedback role="status">' +
      (wire.quiz ? 'اختر فتحة أخرى تتصل بـ B5. الشق قد يفصل المجموعتين.' : '') + '</p></div></section>' +
      '<aside class="surface content-panel wiring-side"><h2>داخل لوحة التجارب</h2><figure>' + photo('breadboard-top','صورة علوية للوحة التجارب','eager') +
      '<figcaption>' + imageLink('breadboard-top') + '</figcaption></figure><figure>' + photo('breadboard-strip','شريط معدني يربط خمس فتحات','eager') +
      '<figcaption>شريط معدني يربط خمس فتحات. ' + imageLink('breadboard-strip') + ' · <bdi>CC BY-SA 4.0</bdi></figcaption></figure>' +
      '<div class="callout"><strong>خطوط التغذية</strong><p>اللون يسهّل التتبع. لا يصل جهد إلى الخط قبل توصيل المصدر. اختبر استمراريته ودبوس الأرضي بمقياس بعد فصل الطاقة.</p></div></aside></div>' +
      '<div class="jumper-grid">' + jumperTypes.map(jumper =>
        '<article class="surface jumper-card"><div>' + photo(jumper.image, jumper.name) + '</div><h3><bdi>' +
        jumper.name + '</bdi></h3><p>' + jumper.copy + '</p></article>').join('') + '</div>';
  }

  function highlightHole(col, row) {
    wire.selected = [col, row];
    if (wire.quiz) {
      const correct = col === 4 && row >= 2 && row < 7 && row !== 3;
      wire.answer = correct;
      outlet.querySelectorAll('[data-hole]').forEach(hole => {
        hole.toggleAttribute('data-quiz-target',hole.dataset.hole === '4,3');
        hole.setAttribute('aria-pressed',String(correct && hole.dataset.net === 'upper-4'));
      });
      outlet.querySelector('[data-wire-quiz-feedback]').textContent = correct
        ? 'صحيح. A5 وB5 وC5 وD5 وE5 تشترك في شريط معدني واحد.'
        : 'جرّب فتحة أخرى في العمود 5 على الجانب نفسه من الشق.';
      outlet.querySelector('[data-wire-status]').textContent = 'الفتحة المختارة لاختبارها: ' + (row >= 2 && row < 12 ? letters[row - 2] + String(col + 1) : 'خط تغذية');
      return;
    }
    const net = breadboardNet(col,row);
    outlet.querySelectorAll('[data-hole]').forEach(hole => hole.setAttribute('aria-pressed', String(hole.dataset.net === net)));
    outlet.querySelector('[data-wire-status]').textContent = statusForHole(col,row);
  }

  function powerPage() {
    return '<div class="lesson-wide-grid power-grid"><section class="surface content-panel"><h2>قبل تشغيل الدائرة</h2><div class="lesson-notes">' +
      powerTopics.map(([label,copy]) => notes(label,copy)).join('') + '</div></section><div class="power-demos">' +
      '<section class="surface content-panel"><h2>حاسبة مقاومة LED</h2><p>المقاومة = فرق الجهد مقسومًا على التيار المطلوب.</p>' +
      '<form class="calculator" data-led-calculator><label>جهد التغذية <bdi>V</bdi><select name="supply"><option value="5">5.0</option><option value="3.3">3.3</option></select></label>' +
      '<label>الجهد الأمامي <bdi>V</bdi><input name="forward" type="number" min="1" max="4.9" value="2" step=".1" inputmode="decimal" required></label>' +
      '<label>التيار المستهدف <bdi>mA</bdi><input name="current" type="number" min="1" max="15" value="10" step="1" inputmode="numeric" required></label>' +
      '<output class="calculator-output" data-led-result aria-live="polite"></output></form>' +
      '<p class="fine-print">ابدأ بقيمة الجهد الأمامي والتيار المسموح في ورقة بيانات المصباح. الحساب تقريبي؛ اختر مقاومة معيارية مساوية أو أعلى.</p></section>' +
      '<section class="surface content-panel"><h2>مدخل الزر</h2><div class="pull-demo" data-pull-state="up">' +
      '<label>اختر نوع السحب<select data-pull-mode><option value="up">سحب إلى الأعلى · INPUT_PULLUP</option><option value="down">سحب إلى الأرضي · مقاومة خارجية</option></select></label>' +
      '<button type="button" class="secondary-button" data-pull-toggle aria-pressed="false">ضغط الزر</button>' +
      '<output data-pull-output aria-live="polite"><bdi>HIGH</bdi> · الزر غير مضغوط</output></div></section></div></div>';
  }

  function updateCalculator() {
    const calculator = outlet.querySelector('[data-led-calculator]');
    const result = calculator.querySelector('output');
    const form = new FormData(calculator);
    const supply = Number(form.get('supply'));
    const forward = Number(form.get('forward'));
    const current = Number(form.get('current'));
    if (!calculator.checkValidity() || forward >= supply) {
      result.textContent = 'أدخل جهدًا أماميًا أقل من جهد التغذية وتيارًا بين 1 و15 mA.';
      return;
    }
    const ohms = (supply - forward) * 1000 / current;
    const standard = [1, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2];
    const scale = 10 ** Math.floor(Math.log10(ohms));
    const rounded = (standard.find(value => value * scale >= ohms - 1e-8) || 10) * scale;
    result.innerHTML = '<strong><bdi>' + String(rounded) + ' Ω</bdi></strong> قيمة معيارية مناسبة<br>الحساب: <bdi>' +
      ohms.toFixed(1) + ' Ω</bdi> · التيار التقريبي <bdi>' + ((supply - forward) * 1000 / rounded).toFixed(1) + ' mA</bdi>';
  }

  function updatePull() {
    const demo = outlet.querySelector('.pull-demo');
    const pressed = demo.querySelector('button').getAttribute('aria-pressed') === 'true';
    const up = demo.querySelector('select').value === 'up';
    demo.querySelector('output').innerHTML = '<bdi>' + (up !== pressed ? 'HIGH' : 'LOW') + '</bdi> · ' + (pressed ? 'الزر مضغوط' : 'الزر غير مضغوط');
  }

  function aiPage() {
    const steps = [
      'اعرف وظيفة كل مكوّن وجهده وأطرافه.',
      'ارسم الدائرة واحسب احتياجات التغذية والحماية.',
      'اكتب جدول المنافذ بين اللوحة والقطع.',
      'اطلب من الذكاء الاصطناعي برنامجًا يطابق الجدول.',
      'راجع التهيئة وحدود القيم وحالات غياب القياس.',
      'جرّب المشروع في المحاكاة واختبر الحدود.',
      'افصل التغذية ثم انقل المخطط إلى العتاد خطوة بخطوة.',
    ];
    return '<div class="lesson-wide-grid ai-grid"><section class="surface content-panel"><h2>من المكوّن إلى الاختبار</h2><ol class="process-steps">' +
      steps.map(label => '<li>' + label + '</li>').join('') + '</ol></section><section class="surface content-panel"><h2>اطلب برنامجًا محدّدًا</h2>' +
      '<div class="prompt-picker mode-bar" role="group" aria-label="أمثلة المطالبات">' +
      prompts.map((item,i) => '<button type="button" data-prompt="' + i + '" aria-pressed="' + (i===promptIndex) + '">' + item.label + '</button>').join('') +
      '</div><textarea id="prompt-text" rows="8" aria-label="نص المطالبة القابل للتعديل">' + escape(prompts[promptIndex].text) +
      '</textarea><div class="code-tools"><button type="button" class="primary-button" data-copy="prompt">نسخ المطالبة</button>' +
      '<span class="copy-status" role="status"></span></div></section></div>';
  }

  function referencesPage() {
    const sources = [
      ['Arduino Uno R3 · المواصفات','https://docs.arduino.cc/hardware/uno-rev3/'],
      ['Arduino Uno R3 · مخطط الدائرة','https://docs.arduino.cc/resources/schematics/A000066-schematics.pdf'],
      ['Arduino · تشريح اللوحة','https://docs.arduino.cc/tutorials/uno-rev3/board-anatomy/'],
      ['Arduino · المقاطعات','https://docs.arduino.cc/language-reference/en/functions/external-interrupts/attachInterrupt/'],
      ['Arduino · التحكم بالسيرفو','https://docs.arduino.cc/learn/electronics/servo-motors/'],
      ['SparkFun · آلية لوحة التجارب','https://learn.sparkfun.com/tutorials/how-to-use-a-breadboard/all'],
      ['Analog Devices · TMP36','https://www.analog.com/media/en/technical-documentation/data-sheets/TMP35_36_37.pdf'],
      ['Adafruit · لوحة MPU6050','https://www.adafruit.com/product/3886'],
      ['Joy-IT · وحدة MFRC522','https://joy-it.net/en/products/SBC-RFID-RC522'],
      ['DFRobot · وحدة Bluetooth','https://wiki.dfrobot.com/tel0026/'],
    ];
    return '<div class="lesson-wide-grid references-grid"><section class="surface content-panel"><h2>الوثائق الفنية</h2>' +
      '<p><a href="assets/uno-r3-pinout.pdf" target="_blank" rel="noopener">نسخة محلية من مخطط المنافذ الرسمي</a> · <bdi>CC BY-SA 4.0</bdi></p><ul>' +
      sources.map(([label,url]) => '<li>' + external(url, format(label)) + '</li>').join('') +
      '</ul></section><section class="surface content-panel"><h2>الصور</h2><p>تُحمَّل الصور من ملفات الورشة المحلية. راجع ترخيص المصدر عند توزيعها.</p>' +
      '<ul class="credits">' + Object.entries(credits).map(([id,credit]) => {
        const license = credit.license || (credit.rights?.match(/\bCC (?:BY(?:-SA)?|0)(?: \d\.\d)?/)?.[0] ?? '');
        const rights = credit.licenseUrl ? external(credit.licenseUrl,escape(license)) : escape(license || 'ترخيص إعادة الاستخدام غير موثّق');
        return '<li><span><bdi>' + escape(id) + '</bdi> · ' + external(credit.page,escape(credit.source)) +
          (credit.origin ? ' · ' + external(credit.origin,'الأصل') : '') + '</span><small class="credit-status">' + rights + '</small></li>';
      }).join('') + '</ul></section></div>';
  }

  const routes = {
    electronics: detail => componentPage('electronics', detail),
    modules: detail => componentPage('modules', detail),
    wiring: wiringPage,
    power: powerPage,
    projects: () => '<div data-free-missions></div>',
    ai: aiPage,
    challenges: () => '<div data-free-challenges></div>',
    references: referencesPage,
  };

  function renderLesson() {
    const [title, subtitle] = routeNames[route.page];
    outlet.innerHTML = articleHead(title, subtitle) + routes[route.page](route.detail);
    outlet.setAttribute('aria-labelledby','lesson-title');
    if (route.page === 'wiring' && wire.selected) highlightHole(...wire.selected);
    if (route.page === 'wiring' && wire.quiz) outlet.querySelector('[data-hole="4,3"]').setAttribute('data-quiz-target','');
    if (route.page === 'power') updateCalculator();
    if (route.page === 'projects') globalThis.JourneyMissions.mountMissions(outlet.querySelector('[data-free-missions]'),route.detail);
    if (route.page === 'challenges') globalThis.Day2Challenges.mount(outlet.querySelector('[data-free-challenges]'),route.detail);
  }

  function navigate(moveFocus) {
    const [page, detail = '', sub = ''] = location.hash.slice(1).split('/');
    const journey = globalThis.Journey;
    journey.release();
    const guided = !page || page === 'journey';
    explorer.hidden = true;
    outlet.hidden = true;
    if (guided) {
      const embedded = journey.activate(detail || 'welcome', sub);
      route = { page:embedded, detail:'' };
      if (embedded) renderLesson();
    } else {
      route = { page: Object.hasOwn(routes,page) ? page : 'explorer', detail };
      journey.free(route.page);
      const showBoard = route.page === 'explorer';
      explorer.hidden = !showBoard;
      outlet.hidden = showBoard;
      if (!showBoard) renderLesson();
      else if (detail) globalThis.Workshop.openReference(detail);
      else globalThis.Workshop.refreshContext();
    }
    document.querySelectorAll('[data-page]').forEach(link => {
      if (link.dataset.page === route.page) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    window.scrollTo({ top:0, left:0, behavior:'instant' });
    if (moveFocus) {
      const heading = document.getElementById(guided ? 'scene-title' : route.page === 'explorer' ? 'explorer-title' : 'lesson-title');
      heading.tabIndex = -1;
      heading.focus({ preventScroll:true });
    }
  }

  async function copyText(text, area) {
    if (navigator.clipboard) {
      try {
        await navigator.clipboard.writeText(text);
        return true;
      } catch {
        // File-URL and browser permissions vary. Offer native selection as a fallback.
      }
    }
    const previous = document.activeElement;
    const temporary = !area;
    area ??= document.createElement('textarea');
    if (temporary) {
      area.value = text;
      area.className = 'copy-helper';
      document.body.append(area);
    }
    area.select();
    let copied = false;
    try { copied = document.execCommand('copy'); } catch { /* Native copy remains available. */ }
    if (temporary) area.remove();
    if (copied) previous.focus();
    return copied;
  }

  outlet.addEventListener('click', async event => {
    const hole = event.target.closest('[data-hole]');
    if (hole) {
      const [col,row] = hole.dataset.hole.split(',').map(Number);
      outlet.querySelector('[data-hole][tabindex="0"]').tabIndex = -1;
      hole.tabIndex = 0;
      wire.tabX = col;
      wire.tabY = row;
      highlightHole(col,row);
      return;
    }
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.wireView) {
      outlet.dataset.wireView = button.dataset.wireView;
      outlet.querySelectorAll('[data-wire-view]').forEach(item => item.setAttribute('aria-pressed',String(item === button)));
      return;
    }
    if (button.hasAttribute('data-latch')) {
      latched = !latched;
      button.setAttribute('aria-pressed',String(latched));
      const result = outlet.querySelector('.latch-result');
      result.dataset.lit = String(latched);
      result.textContent = latched ? 'المسار موصول' : 'المسار مفتوح';
    }
    if (button.dataset.wireMode) {
      wire.mode = button.dataset.wireMode;
      wire.pressed = false;
      renderLesson();
      outlet.querySelector('[data-wire-mode="' + wire.mode + '"]').focus({preventScroll:true});
    }
    if (button.hasAttribute('data-wire-press')) {
      wire.pressed = !wire.pressed;
      button.setAttribute('aria-pressed',String(wire.pressed));
      outlet.querySelector('[data-wire-signal] bdi').textContent = wire.pressed ? 'LOW' : 'HIGH';
      outlet.querySelector('.switch-cap').classList.toggle('pressed',wire.pressed);
    }
    if (button.hasAttribute('data-wire-quiz')) {
      wire.quiz = !wire.quiz;
      wire.answer = null;
      wire.selected = null;
      wire.mode = 'holes';
      renderLesson();
      outlet.querySelector('[data-wire-quiz]').focus({preventScroll:true});
    }
    if (button.hasAttribute('data-pull-toggle')) {
      const pressed = button.getAttribute('aria-pressed') === 'true';
      button.setAttribute('aria-pressed',String(!pressed));
      button.textContent = pressed ? 'ضغط الزر' : 'إفلات الزر';
      updatePull();
    }
    if (button.dataset.prompt !== undefined) {
      promptIndex = Number(button.dataset.prompt);
      outlet.querySelector('#prompt-text').value = prompts[promptIndex].text;
      outlet.querySelectorAll('[data-prompt]').forEach(item => item.setAttribute('aria-pressed',String(button === item)));
      outlet.querySelector('.copy-status').textContent = '';
    }
    if (button.dataset.copy) {
      const area = outlet.querySelector('#prompt-text');
      const text = area.value;
      const result = button.parentElement.querySelector('[role="status"]');
      const copied = await copyText(text, area);
      result.textContent = copied ? 'نُسخ إلى الحافظة.' : 'النص محدد. اضغط Ctrl+C لنسخه.';
    }
  });

  outlet.addEventListener('keydown', event => {
    const hole = event.target.closest('[data-hole]');
    if (!hole) return;
    const [col,row] = hole.dataset.hole.split(',').map(Number);
    const offset = { ArrowLeft:[-1,0], ArrowRight:[1,0], ArrowUp:[0,-1], ArrowDown:[0,1] }[event.key];
    if (offset) {
      event.preventDefault();
      wire.tabX = Math.min(13,Math.max(0,col+offset[0]));
      wire.tabY = Math.min(13,Math.max(0,row+offset[1]));
      const next = outlet.querySelector('[data-hole="' + wire.tabX + ',' + wire.tabY + '"]');
      hole.tabIndex = -1;
      next.tabIndex = 0;
      next.focus();
    } else if (event.key === ' ' || event.key === 'Enter') {
      event.preventDefault();
      highlightHole(col,row);
    }
  });

  outlet.addEventListener('change', event => {
    if (event.target.matches('[data-split]')) {
      wire.split = event.target.checked;
      renderLesson();
      outlet.querySelector('[data-split]').focus({preventScroll:true});
    }
    if (event.target.matches('[data-pull-mode]')) updatePull();
  });
  outlet.addEventListener('input', event => {
    if (event.target.closest('[data-led-calculator]')) updateCalculator();
  });
  outlet.addEventListener('submit', event => {
    if (event.target.matches('[data-led-calculator]')) event.preventDefault();
  });

  document.querySelector('.skip-link').addEventListener('click',event => {
    event.preventDefault();
    document.querySelector('main').focus();
  });
  window.addEventListener('hashchange', () => navigate(true));
  navigate(false);
})();
