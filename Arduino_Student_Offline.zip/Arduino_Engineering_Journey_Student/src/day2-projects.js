(() => {
  'use strict';
  const { escape, format } = globalThis.Workshop;
  const missions = globalThis.MissionData;
  const projectState = new Map();
  const lowerPriority = ['alarm','temperature'];
  const core = ['brightness','motor','servo-lab','distance'];
  const previous = ['blink','button-led'];
  const stageNames = [
    ['brief','The Problem'],
    ['components','Choose Components'],
    ['wiring','Design the Circuit'],
    ['tinkercad','Open Tinkercad'],
    ['ask','AI Code'],
    ['test','Test & Debug'],
    ['applications','Engineering Applications'],
  ];

  const content = {
    blink: {
      problem:'كيف نخلّي لمبة تشتغل ثانية وتطفأ ثانية من دون الضغط على زر؟',
      parts:['led','resistor'],
      errors:['افحص أن السلك يخرج من D8 مثل الكود.','صل Anode بالمقاومة، وCathode بـGND.','استخدم مقاومة 220 Ω في المسار نفسه مع LED.'],
      uses:[['هندسة صناعية','إشارة ضوئية دورية تُظهر أن جهاز الاختبار ما زال يعمل.'],['هندسة مدنية','نموذج لمؤشر ضوئي متقطع يلفت الانتباه إلى تحويلة مؤقتة.']],
    },
    'button-led': {
      problem:'كيف نجعل لمبة تشتغل فقط طوال الضغط على زر؟',
      parts:['button','led','resistor'],
      errors:['وصّل الزر على جانبي شق Breadboard واستخدم طرفين يتصلان عند الضغط فقط.','مع INPUT_PULLUP تكون قراءة D2 هي LOW عند الضغط.','افحص اتجاه LED ووجود مقاومة 220 Ω.'],
      uses:[['هندسة صناعية','زر طلب مساعدة يضيء إشارة للمشرف عند الضغط.'],['هندسة ميكانيكية','لوحة تدريب تبين أن زر تشغيل حركة يدوية مضغوط.']],
    },
    brightness: {
      problem:'كيف نستخدم مقبضًا لرفع سطوع LED وخفضه؟',
      parts:['pot','led','resistor'],
      errors:['استخدم D9 في هذه الدائرة. اختيار منفذ بلا PWM يمنع تغيير السطوع بالطريقة المطلوبة.','إذا بقي السطوع على حاله، افحص أن Wiper هو الطرف الواصل إلى A0.','راجع اتجاه LED ومقاومة 220 Ω وتوصيل GND.'],
      uses:[['هندسة كهربائية','ضبط سطوع مؤشر على لوحة تحكم لسهولة قراءته ليلًا.'],['هندسة صناعية','مقارنة درجات إضاءة محطة فحص بصري لتقليل الوهج.']],
    },
    motor: {
      problem:'كيف نغيّر سرعة موتور من دون أن يمر تياره في منفذ Arduino؟',
      parts:['pot','dc-motor','mosfet','resistor','diode','bench'],
      errors:['تحقق من ترتيب Gate وDrain وSource لطراز MOSFET الذي تستخدمه.','اربط سالب مصدر الموتور مع GND على Arduino.','افحص اتجاه Flyback Diode. الطرف المخطّط على موجب الموتور.','إذا توقف الموتور عند PWM منخفض، افحص جهد المصدر وتيار بدء الدوران.'],
      uses:[['هندسة ميكانيكية','ضبط سرعة مروحة اختبار لدراسة تغيّر تدفق الهواء.'],['هندسة صناعية','تجربة تغيير سرعة سير ناقل مصغّر قبل قياس زمن فرز القطع.']],
    },
    'servo-lab': {
      problem:'كيف نحرّك ذراعًا لزاوية يحددها مقبض؟',
      parts:['pot','servo','bench'],
      errors:['تأكد من سلك Signal حسب طراز السيرفو، ووصّله بـD9.','إذا اهتز السيرفو أو أعاد Arduino التشغيل، افحص قدرة مصدر السيرفو واربط الأرضي.','إذا اصطدم الذراع بحد الحركة، اضبط الزوايا في الكود على مجال أضيق بعد فحصه دون حمل.'],
      uses:[['هندسة ميكانيكية','توجيه ذراع نموذج آلي إلى زاوية محددة.'],['هندسة مدنية','تحريك بوابة في نموذج مصغّر لموقف سيارات.']],
    },
    distance: {
      problem:'كيف نصمم نظامًا يحذّر السائق كلما اقترب من جدار؟',
      parts:['ultrasonic','passive-buzzer'],
      errors:['طابق Trig مع D6 وEcho مع D7 في التوصيل والكود.','عند غياب الصدى، اترك الإنذار صامتًا واقرأ رسالة الخطأ.','استخدم Passive Piezo لتجربة النغمة من tone().'],
      uses:[['هندسة مدنية','رصد اقتراب مركبة من حاجز في نموذج موقف سيارات.'],['هندسة صناعية','تنبيه عند اقتراب صندوق من نهاية ناقل صغير.']],
    },
    alarm: {
      problem:'كيف ننبه الموجودين بضوء وصوت عند مرور شخص؟',
      parts:['pir','led','resistor','passive-buzzer'],
      errors:['راجع ترتيب VCC وGND وOUT حسب طراز PIR.','اترك PIR يستقر بعد توصيل الكهرباء قبل الحكم على التجربة.','إذا اشتغلت اللمبة دون الجرس، افحص توصيل D8 ونوع Piezo.'],
      uses:[['هندسة صناعية','إشارة مرور قرب محطة عرض تفاعلية.'],['هندسة كهربائية','رصد الحركة في ممر لتشغيل إنارة تلقائية.']],
    },
    temperature: {
      problem:'كيف نعرض درجة الحرارة الحالية على شاشة صغيرة؟',
      parts:['temp','lcd','pot','resistor'],
      errors:['اتبع رسم أطراف TMP36 لطرازك. في TO-92 الموضح، الوسط VOUT يذهب إلى A0.','إذا أضاءت الشاشة ولم تظهر الحروف، اضبط VO بالمقبض.','طابق RS وE وD4–D7 مع ترتيبها في الكود، واربط R/W بـGND.'],
      uses:[['هندسة كيميائية','عرض حرارة حمام مائي في تجربة مخبرية منخفضة الحرارة.'],['هندسة ميكانيكية','متابعة حرارة الهواء قرب فتحة تبريد في نموذج اختبار.']],
    },
  };

  const customParts = {
    uno: { title:'Arduino Uno R3', photo:'assets/uno-r3.jpg', role:'يقرأ المدخلات ويشغّل الكود ويرسل إشارات التحكم.', pins:['5V','GND'], use:'التحكم في مؤشرات لوحة أو قراءة حساس.' },
    breadboard: { title:'Breadboard + Jumper Wires', image:'breadboard-top', role:'تربط القطع مؤقتًا من دون لحام.', pins:['صفوف الثقوب','+ / −'], use:'اختبار الدائرة وتغيير سلك بسرعة.' },
    diode: { title:'Flyback Diode', role:'يمر فيه التيار لحظة فصل الموتور، فيحمي MOSFET.', pins:['Anode','Cathode'], use:'حماية مفتاح مروحة تدور في اتجاه واحد.' },
    pot: { pins:['طرف خارجي','Wiper','طرف خارجي'] },
    'passive-buzzer': { pins:['+','−'] },
    bench: { pins:['+','−'] },
    'dc-motor': { pins:['M+','M−'] },
    lcd: { pins:['VSS','VDD','VO','RS','R/W','E','D4–D7','A / K'] },
  };
  const formatShort = value => (value || '').replace(/\.(?=\s|$).*/,'');
  const library = id => '#journey/library/' + id;
  const journey = id => '#journey/' + id;
  const editorUrl = 'https://www.tinkercad.com/dashboard/designs/circuits';

  function promptFor(mission) {
    const lines = mission.prompt.split('\n');
    lines.splice(2, 0, 'القطع: ' + mission.components.map(part => part.name).join('، ') + '.');
    return lines.join('\n');
  }

  const photo = (src,alt) => '<img src="' + escape(src) + '" alt="' + escape(alt) + '">';
  const button = (id,label,extra='',style='secondary-button') =>
    '<button type="button" data-project-action="' + id + '" class="' + style + '"' + extra + '>' + label + '</button>';
  const link = (url,label,style='secondary-button') => '<a href="' + escape(url) + '" class="' + style + '">' + label + '</a>';
  const external = (url,label,style) => '<a href="' + escape(url) + '" target="_blank" rel="noopener noreferrer" class="' + style + '">' + label + '</a>';

  function componentCopy(id,mission) {
    const item = globalThis.JourneyLabData.items[id];
    const custom = customParts[id] || {};
    const curated = item ? globalThis.PresentationData.component(item) : [];
    const title = custom.title || item.title;
    const file = custom.photo || 'assets/photos/' + (custom.image || item.image) + '.webp';
    const pins = id === 'uno' ? custom.pins.concat(mission.pins) : custom.pins || item.terminals?.map(([pin]) => pin) || [];
    const role = custom.role || curated[1] || formatShort(item.functionText);
    const use = custom.use || curated[2] || formatShort(item.project);
    const values = mission.values;
    const valueText = id === 'resistor' ?
      (mission.id === 'motor' ? values.gateResistance + ' Ω + ' + values.pulldown + ' kΩ' : (values.ledResistance ?? values.backlightResistance) + ' Ω') :
      id === 'pot' ? values.potResistance + ' kΩ' : '';
    const optional = id === 'bench' && mission.id === 'servo-lab' ? '<span class="practice-tag">للتركيب الفعلي</span>' : '';
    return '<article class="practice-part"><figure>' + photo(file,title) + '</figure><div><h3><bdi>' + escape(title + (valueText ? ' · ' + valueText : '')) +
      '</bdi></h3>' + optional + '<p>' + format(role) + '</p>' + (pins.length ? '<p class="practice-pins" aria-label="أطراف القطعة">' +
        pins.map(pin => '<bdi>' + escape(pin) + '</bdi>').join(' ') + '</p>' : '') +
      '<p class="practice-example">' + format(use) + '</p>' +
      (!item ? '' : link(library(id),'تفاصيل في المكتبة','text-button')) + '</div></article>';
  }

  function chooseMarkup() {
    const list = ids => ids.map(id => {
      const mission = missions.find(entry => entry.id === id);
      return '<a href="' + journey('practice/' + id) + '" class="surface practice-choice"><strong><bdi>' + escape(mission.title) +
        '</bdi></strong><span>' + format(mission.brief) + '</span>' + (id === 'servo-lab' ? '<small>اختياري عند ضيق الوقت</small>' : '') + '</a>';
    }).join('');
    return '<section class="surface practice-shell"><header class="practice-head"><h2 id="scene-title" tabindex="-1" lang="en">Practical Projects</h2>' +
      '<p>اختر المشروع الذي ستبنيه مع الطلاب.</p></header>' +
      '<h3>المسار الأساسي</h3><div class="practice-chooser">' + list(core) + '</div>' +
      '<h3>مشاريع إضافية</h3><div class="practice-chooser">' + list(lowerPriority) + '</div>' +
      '<details class="engineering-detail practice-previous"><summary>مشروعا اليوم الأول</summary><div class="practice-chooser">' + list(previous) +
      '</div></details>' + link(journey('final-challenge'),'التحدي النهائي','primary-button') + '</section>';
  }

  function wiring(mission,state) {
    const rows = mission.wiring.slice(0,state.wires);
    const full = rows.length === mission.wiring.length;
    const hint = '<p class="practice-question">أين نوصّل كل طرف؟ اقترحوا التوصيلات أولًا.</p>';
    if (!rows.length) return hint + button('wire','اكشف أول توصيل','','primary-button');
    const table = '<div class="wiring-table-wrap practice-wiring" aria-live="polite"><table class="wiring-table"><thead><tr>' +
      '<th>من</th><th>إلى</th><th>السبب</th></tr></thead><tbody>' + rows.map(row =>
        '<tr><td><bdi>' + escape(row.from) + '</bdi></td><td><bdi>' + escape(row.to) + '</bdi></td><td>' +
        format(row.because) + '</td></tr>').join('') + '</tbody></table></div>';
    const controls = '<div class="practice-actions">' +
      (!full ? button('wire','اكشف التوصيل التالي','','primary-button') + button('wire-all','اكشف بقية الجدول') : '') +
      '<span><bdi>' + rows.length + '/' + mission.wiring.length + '</bdi> توصيلات</span></div>';
    const diagram = full ? '<details class="engineering-detail practice-diagram"><summary>اعرض مخطط الدائرة</summary>' +
      photo('assets/circuits/' + mission.id + '.svg','مخطط توصيل ' + mission.title) + '</details>' : '';
    return table + controls + diagram;
  }

  function toolsForPrompt(mission,state) {
    const fields = [
      ['اللوحة','Arduino Uno R3'],
      ['القطع',mission.components.slice(1).map(part => part.name).join('، ')],
      ['المنافذ والتوصيلات','اكتب أرقام المنافذ وما يتصل بكل واحد حسب جدولنا.'],
      ['السلوك المطلوب',mission.brief],
    ];
    const scaffold = '<dl class="practice-prompt-steps">' + fields.map(([label,value]) =>
      '<div><dt>' + label + '</dt><dd>' + escape(value) + '</dd></div>').join('') + '</dl>';
    const reveal = state.prompt ? '<textarea readonly rows="8" aria-label="الطلب الجاهز للنسخ" class="mission-prompt" data-practice-prompt>' +
      escape(promptFor(mission)) + '</textarea>' : '';
    return scaffold + '<div class="practice-actions">' +
      button('prompt',state.prompt ? 'أخفِ الطلب الجاهز' : 'اكشف الطلب الجاهز',' aria-expanded="' + state.prompt + '"') +
      button('copy','انسخ الطلب','','primary-button') + external('https://chatgpt.com/','افتح ChatGPT','secondary-button') +
      button('backup',state.code ? 'أخفِ الكود المرجعي' : 'اكشف الكود المرجعي',' aria-expanded="' + state.code + '"') + '<output role="status" data-practice-feedback></output></div>' + reveal + referenceCode(mission,state);
  }

  function referenceCode(mission,state) {
    if (!state.code) return '';
    return '<div class="mission-tools">' + button('copy-code','انسخ الكود') +
      button('download','تنزيل ملف .ino') +
      '<output role="status" data-practice-code-feedback></output></div><pre class="mission-code" dir="ltr"><code>' +
      escape(mission.code) + '</code></pre>';
  }

  function test(mission,state) {
    const current = mission.tests[state.test];
    const question = '<p class="practice-question">' + format(current.step) + ' ماذا تتوقع أن يحدث؟</p>';
    const answer = state.result ? '<p role="status" class="practice-answer">' + format(current.expected) + '</p>' : '';
    const errors = '<details class="engineering-detail"><summary>افحص هذه الأخطاء إذا اختلفت النتيجة</summary><ul>' +
      content[mission.id].errors.map(error => '<li>' + escape(error) + '</li>').join('') + '</ul></details>';
    return question + answer + '<div class="practice-actions">' +
      button('result',state.result ? 'أخفِ النتيجة' : 'اكشف النتيجة',' aria-expanded="' + state.result + '"','primary-button') +
      (mission.tests.length > 1 ? button('test-next','اختبار آخر') : '') + button('backup',state.code ? 'أخفِ الكود المرجعي' : 'اكشف الكود المرجعي',' aria-expanded="' + state.code + '"') + '</div>' + errors + referenceCode(mission,state);
  }

  function bodyFor(mission,state,phase) {
    const item = content[mission.id];
    switch (phase) {
      case 'brief':
        return '<p class="practice-question">' + escape(item.problem) + '</p>';
      case 'components':
        return '<div class="practice-parts">' + ['uno','breadboard',...item.parts].map(id => componentCopy(id,mission)).join('') + '</div>';
      case 'wiring':
        return wiring(mission,state);
      case 'tinkercad': {
        const circuit = globalThis.StudentLinks.circuit(mission.id);
        return '<p class="practice-question">جرّب بناء الدائرة في محرّر Tinkercad.</p><div class="practice-actions">' +
          external(editorUrl,'افتح محرّر الدوائر','primary-button') +
          (circuit ? external(circuit,'افتح دائرة الورشة','secondary-button') : '') + '</div>' +
          (circuit ? '<p class="fine-print">' + escape(globalThis.StudentLinks.circuitAccess(mission.id)) + '</p>' : '');
      }
      case 'ask':
        return toolsForPrompt(mission,state);
      case 'test':
        return test(mission,state);
      case 'applications':
        return '<div class="practice-uses">' + item.uses.map(([field,use]) => '<article><h3>' + escape(field) + '</h3><p>' +
          escape(use) + '</p></article>').join('') + '</div>';
    }
  }

  // A copied prompt can work from file:// even when the asynchronous clipboard API is unavailable.
  async function copyPrompt(text,host) {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch { /* Use the selected text fallback. */ }
    const before = document.activeElement;
    const field = document.createElement('textarea');
    field.value = text;
    field.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
    host.append(field);
    field.select();
    try { return document.execCommand('copy'); }
    catch { return false; }
    finally { field.remove(); before?.focus({preventScroll:true}); }
  }

  function mount(host,detail = '') {
    const mission = missions.find(entry => entry.id === detail);
    if (!mission) {
      host.innerHTML = chooseMarkup();
      globalThis.PresentationData.publish(null);
      return;
    }
    const state = projectState.get(mission.id) || {page:0,wires:0,prompt:false,code:false,test:0,result:false};
    projectState.set(mission.id,state);

    function publish(phase = stageNames[state.page][0]) {
      globalThis.PresentationData.publish({kind:'mission',id:mission.id,phase});
    }

    function render(focus) {
      const [phase,title] = stageNames[state.page];
      host.innerHTML = '<section class="surface practice-shell" data-practical-project="' + mission.id + '" data-practical-phase="' + phase + '">' +
        '<header class="practice-head"><div><p class="eyebrow"><bdi>' + escape(phase === 'brief' ? 'PROJECT ' + String(missions.indexOf(mission) + 1).padStart(2,'0') : mission.title) +
        '</bdi></p><h2 id="scene-title" tabindex="-1" lang="en" dir="ltr">' + title + '</h2></div><nav aria-label="أقسام المشاريع" class="practice-destinations">' +
        link(journey('practice'),'كل المشاريع','text-button') + link(journey('final-challenge'),'التحدي النهائي','text-button') + '</nav></header>' +
        '<nav class="mission-phases student-project-jumps" aria-label="مراحل المشروع">' +
        stageNames.map(([id,label],index) => button('jump',label,' data-stage-index="' + index + '" aria-pressed="' + (index === state.page) + '"')).join('') + '</nav>' +
        '<div class="practice-body" data-practical-info="' + phase + '">' + bodyFor(mission,state,phase) + '</div>' +
        '<nav class="practice-actions practice-nav" aria-label="خطوات المشروع">' +
        (state.page > 0 ? button('prev','السابق',' data-show-prev') : '') +
        '<span><bdi>' + (state.page + 1) + '/' + stageNames.length + '</bdi></span>' +
        (state.page + 1 < stageNames.length ? button('next','التالي',' data-show-next','primary-button') :
          link(journey('practice'),'اختر مشروعًا آخر','primary-button')) + '</nav></section>';
      publish();
      if (focus === 'wire' || focus === 'wire-all') {
        const table = host.querySelector('.practice-wiring');
        if (table) table.scrollTop = table.scrollHeight;
      }
      if (focus) (host.querySelector('[data-project-action="' + focus + '"]') || host.querySelector('h2')).focus({preventScroll:true});
    }

    host.onclick = async event => {
      const control = event.target.closest('[data-project-action]');
      if (!control || !host.contains(control)) return;
      const action = control.dataset.projectAction;
      switch (action) {
        case 'next': case 'prev':
          state.page += action === 'next' ? 1 : -1;
          state.code = false;
          render('heading');
          return;
        case 'jump':
          state.page = Number(control.dataset.stageIndex);
          state.code = false;
          render('heading');
          return;
        case 'wire': state.wires++; break;
        case 'wire-all': state.wires = mission.wiring.length; break;
        case 'prompt': state.prompt = !state.prompt; break;
        case 'test-next':
          state.test = (state.test + 1) % mission.tests.length;
          state.result = false;
          break;
        case 'result': state.result = !state.result; break;
        case 'backup':
          state.code = !state.code;
          break;
        case 'download':
          globalThis.JourneyMissions.downloadSketch(mission.id,mission.code);
          return;
        case 'copy-code': {
          const copied = await copyPrompt(mission.code,host);
          if (!host.contains(control)) return;
          host.querySelector('[data-practice-code-feedback]').textContent = copied ? 'نُسخ الكود.' : 'يمكنك تحديد الكود أو تنزيل الملف.';
          return;
        }
        case 'copy': {
          const copied = await copyPrompt(promptFor(mission),host);
          if (!host.contains(control)) return;
          if (!copied && !state.prompt) {
            state.prompt = true;
            render();
          }
          if (!copied) host.querySelector('[data-practice-prompt]')?.select();
          host.querySelector('[data-practice-feedback]').textContent = copied ? 'نُسخ الطلب.' : 'حُدّد النص. اضغط Ctrl+C للنسخ.';
          return;
        }
        default: return;
      }
      render(action);
    };
    render();
  }

  globalThis.Day2Projects = { mount, promptFor };
})();

