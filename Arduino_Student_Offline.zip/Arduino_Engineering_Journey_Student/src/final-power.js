(() => {
  'use strict';

  const supplyCards = [
    {
      id: 'usb', title: 'USB Type-B', label: 'ابدأ من الكمبيوتر', photo: 'lab-usb-head',
      alt: 'صورة رأس كابل USB Type-B',
      function: 'يوصل 5V من الكمبيوتر ويتيح رفع البرنامج إلى Arduino.',
      connection: 'ركّب الطرف المربّع في منفذ USB Type-B على اللوحة. استخدم كابل بيانات لرفع البرنامج.',
    },
    {
      id: 'jack', title: 'DC Jack', label: 'مدخل الطاقة الدائري', photo: 'lab-barrel',
      alt: 'صورة مدخل الطاقة الدائري على Arduino Uno R3',
      function: 'يشغّل Uno R3 من مصدر خارجي عبر مدخل الطاقة الدائري.',
      connection: 'استخدم محول DC بجهد 7–12V. يجب أن يكون الموجب في وسط القابس.',
    },
    {
      id: 'vin', title: 'VIN', label: 'غذّ اللوحة بسلكين', photo: 'lab-vin',
      alt: 'صورة صف منافذ الطاقة على Arduino Uno R3',
      function: 'يدخل جهد المصدر إلى اللوحة قبل منظم الجهد.',
      connection: 'على صف POWER، وصل موجب مصدر DC من 7–12V إلى VIN والسالب إلى GND.',
    },
    {
      id: 'adapter', title: 'DC Adapter', label: 'محول تيار مستمر', photo: 'lab-adapter-rating',
      alt: 'صورة ملصق مواصفات محول طاقة مستمر',
      function: 'يوفّر جهدًا مستمرًا. اقرأ OUTPUT لمعرفة جهد الخرج والتيار المتاح.',
      connection: 'لـDC Jack اختر 7–12V، وموجبًا في الوسط، وتيارًا يكفي الحمل. طابق مقاس القابس.',
    },
    {
      id: 'bench', title: 'Bench Power Supply', label: 'اضبط الجهد والتيار', photo: 'lab-bench-terminals',
      alt: 'صورة أطراف خرج مصدر الطاقة المخبري',
      function: 'يتيح لك ضبط الجهد ووضع حد للتيار.',
      connection: 'والخرج مطفأ، اضبط الجهد وحد التيار ثم وصّل طرفي + و−. اختر 7–12V إذا بتغذّي Uno عبر VIN.',
    },
    {
      id: 'breadboard-module', title: 'Breadboard Power Module', label: 'طاقة على خطوط Breadboard', photo: 'lab-bread-power-installed',
      alt: 'صورة وحدة التغذية مركبة على Breadboard',
      function: 'يوزع 5V أو 3.3V على خطوط الطاقة في Breadboard، بحسب ضبط الوحدة.',
      connection: 'ركّبها على خطوط + و− حسب العلامات. اضبط الجهد وقِسه على الخطوط قبل توصيل القطع.',
    },
    {
      id: 'batteries', title: 'Batteries', label: 'توالي وتوازي', photo: 'lab-aa4',
      alt: 'صورة حامل أربع بطاريات AA',
      function: 'اختر حزمة تناسب جهد الدائرة والتيار الذي تحتاجه.',
      connection: 'في التوالي صِل موجب بطارية بسالب التالية. في التوازي صِل الموجب بالموجب والسالب بالسالب.',
      examples: [
        ['Series', 'بطاريتان متطابقتان بجهد 1.5V تعطيان 3V في التوالي.'],
        ['Parallel', 'في التوازي يبقى الجهد 1.5V وتزداد السعة. استخدم حزمة مصممة لذلك بخلايا متطابقة ومن نفس حالة الشحن.'],
      ],
    },
    {
      id: 'rails', title: '5V / 3.3V', label: 'اختر جهد القطعة', photo: 'lab-vin',
      alt: 'صورة صف POWER وفيه 5V و3.3V وGND',
      function: 'هما خرجا تغذية بجهدين مختلفين. اختر الجهد المكتوب على القطعة.',
      connection: 'صل طرف تغذية القطعة VCC بالخرج المناسب وأرضيها بـGND. إشارات Uno R3 الرقمية تعمل بمنطق 5V.',
      examples: [
        ['Logic Level', 'الجهد الذي تقرؤه القطعة على أنه HIGH أو LOW. إذا لم تتحمل إشارة 5V، استخدم محوّل مستويات مناسبًا.'],
      ],
    },
    {
      id: 'ground', title: 'Common Ground', label: 'مرجع واحد للإشارة', photo: 'breadboard-rails',
      alt: 'صورة خطوط الطاقة الموجبة والسالبة في Breadboard',
      function: 'يجعل Arduino والقطعة يقيسان الإشارة من نفس نقطة الصفر.',
      connection: 'في دائرة موتور بدرايفر غير معزول، صِل GND من Arduino بـGND الدرايفر وسالب مصدر الموتور. يبقى موجب مصدر الموتور على مدخل تغذيته.',
    },
    {
      id: 'limits', title: 'Current Limits', label: 'كم تيار يتحمّل؟', photo: 'lab-vin',
      alt: 'صورة صف الطاقة في Uno R3',
      function: 'اختر مصدرًا يتحمّل التيار الذي تسحبه القطعة أثناء العمل.',
      connection: 'غذّ الموتور من مصدر مناسب عبر Motor Driver. يرسل Arduino إشارة التحكم.',
      examples: [
        ['20 mA', 'حد التصميم لكل منفذ Digital I/O. صمّم الدائرة بتيار أقل عندما تستطيع.'],
        ['50 mA', 'الحد المحدد لخرج 3.3V في Uno R3 الرسمي.'],
        ['5V', 'التيار المتاح يعتمد على مصدر التغذية واستهلاك اللوحة. إذا غُذّيت اللوحة عبر VIN أو DC Jack، تؤثر حرارة المنظم أيضًا.'],
      ],
    },
  ];

  const card = ({id, title, label, photo, alt, function: purpose, connection, examples = []}, index) => {
    const choice = 'power-choice-' + id;
    const examplesHTML = examples.map(([name, copy]) =>
      '<div><dt><bdi>' + name + '</bdi></dt><dd>' + copy + '</dd></div>').join('');
    return '<div class="power-choice">' +
      '<input type="radio" name="power-source" id="' + choice + '" aria-controls="' + choice + '-panel"' + (index === 0 ? ' checked' : '') + '>' +
      '<label for="' + choice + '"><bdi>' + title + '</bdi><span>' + label + '</span></label>' +
      '<article id="' + choice + '-panel" class="surface power-overview" aria-labelledby="' + choice + '-title">' +
      '<img src="assets/photos/' + photo + '.webp" alt="' + alt + '" loading="lazy">' +
      '<div class="power-overview-copy"><h2 id="' + choice + '-title"><bdi>' + title + '</bdi></h2>' +
      '<p class="power-purpose">' + purpose + '</p><p>' + connection + '</p>' +
      (examplesHTML ? '<dl class="power-examples">' + examplesHTML + '</dl>' : '') + '</div></article></div>';
  };

  globalThis.FinalPower = {
    render() {
      return '<section class="final-power"><h2 class="final-power-heading"><bdi>Power Bench</bdi></h2>' +
        '<div class="power-choice-grid" role="group" aria-label="اختر مصدر التغذية أو موضوع الطاقة">' +
        supplyCards.map(card).join('') + '</div>' +
        '<div class="power-reference-links"><button class="secondary-button" type="button" data-deck-action="power-explore">افتح تجارب التغذية</button>' +
        '<a href="https://docs.arduino.cc/resources/pinouts/A000066-full-pinout.pdf" rel="noopener" target="_blank">مخطط Uno R3 الرسمي</a></div></section>';
    },
  };
})();
