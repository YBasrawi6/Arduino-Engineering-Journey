(() => {
  'use strict';

  // Change a project's pinMap here. The wiring rows, Arduino sketch, and AI prompt use these values.
  const source = (label, url) => ({ label, url });
  const official = {
    uno: source('مخطط المنافذ الرسمي · Arduino Uno R3', 'https://docs.arduino.cc/static/c57a658e0f7afad334f6f73e82dfd83d/A000066-full-pinout.pdf'),
    pullup: source('INPUT_PULLUP · Arduino', 'https://docs.arduino.cc/built-in-examples/digital/InputPullupSerial/'),
    analogWrite: source('توثيق analogWrite · Arduino', 'https://docs.arduino.cc/language-reference/en/functions/analog-io/analogWrite/'),
    mosfet: source('خصائص IRLZ44N عند 4.5 V على Gate · Infineon', 'https://www.infineon.com/part/IRLZ44N'),
    servo: source('Servo مع مقاومة متغيرة · Arduino', 'https://docs.arduino.cc/learn/electronics/servo-motors/'),
    ultrasonic: source('ورقة HC-SR04 · ELECFREAKS', 'https://cdn.sparkfun.com/datasheets/Sensors/Proximity/HCSR04.pdf'),
    pulse: source('توثيق pulseIn · Arduino', 'https://docs.arduino.cc/language-reference/en/functions/advanced-io/pulseIn/'),
    tone: source('توثيق tone · Arduino', 'https://docs.arduino.cc/language-reference/en/functions/advanced-io/tone/'),
    pir: source('اختبار حساس الحركة PIR · Adafruit', 'https://learn.adafruit.com/pir-passive-infrared-proximity-motion-sensor/testing-a-pir'),
    lcd: source('توصيل LCD بأربعة أسلاك بيانات · Arduino', 'https://docs.arduino.cc/learn/electronics/lcd-displays/'),
    tmp: source('ورقة بيانات TMP36 · Analog Devices', 'https://www.analog.com/media/en/technical-documentation/data-sheets/TMP35_36_37.pdf'),
  };
  const common = [
    ['Arduino Uno R3', 'يشغّل الكود ويقرأ الحساسات ويتحكم بالقطع.'],
    ['Breadboard وأسلاك', 'نركّب الدائرة ونجربها من دون لحام.'],
  ];
  const row = (from, to, because) => ({ from, to, because });
  const test = (step, expected) => ({ step, expected });
  const led = (pin, ohms) => [
    row('Arduino ' + pin, 'مقاومة ' + ohms + ' Ω ثم LED (Anode)', 'تحمي المقاومة اللمبة بتقليل التيار. Anode هو طرف دخول التيار.'),
    row('LED (Cathode)', 'Arduino GND', 'Cathode هو طرف رجوع التيار إلى GND.'),
  ];
  const potInput = (pin, kiloOhms) => [
    row('طرفا Potentiometer ' + kiloOhms + ' kΩ الخارجيان', 'Arduino 5V وGND', 'تضبط هذه الوصلات مجال الجهد من 0 إلى 5V.'),
    row('Wiper · المنزلق الأوسط', 'Arduino ' + pin, 'يقرأ A0 الجهد عند لف المقبض.'),
  ];
  const code = (...lines) => lines.join('\n');
  const pin = label => label.replace(/^D(?=\d)/, '');
  const piezo = (label) => [
    row('Arduino ' + label, 'Piezo السلبي (+)', 'Arduino يرسل نبضات يحوّلها الجرس إلى صوت.'),
    row('Piezo السلبي (−)', 'Arduino GND', 'يرجع التيار إلى الأرضي GND.'),
  ];
  const piezoCare = 'استخدم Passive Piezo مناسبًا لإشارة 5V. إذا احتاج تيارًا أعلى من قدرة المنفذ، شغّله بدائرة قيادة مناسبة.';
  const noMatch = 'مخطط للتركيب. طابقه مع دائرتك في Tinkercad.';

  function mission(definition) {
    const { build, ...meta } = definition;
    const lesson = build(meta.pinMap, meta.values);
    const components = common.concat(lesson.components).map(([name, reason]) => ({ name, reason }));
    const wiring = lesson.wiring;
    const tests = lesson.tests;
    const prompt = [
      'اكتب برنامج Arduino كاملًا للوحة Uno R3 لمشروع ' + meta.title + '.',
      'الفكرة: ' + meta.brief,
      'استخدم هذه التوصيلات بنفس المنافذ والقيم:',
      ...wiring.map(({ from, to }) => '- ' + from + ' ← ' + to + '.'),
      'سلوك البرنامج: ' + lesson.behavior,
      'قبل توصيل القطع الحقيقية: ' + lesson.safety.join(' '),
      'حالات الاختبار:',
      ...tests.map(({ step, expected }) => '- ' + step + ' النتيجة المتوقعة: ' + expected),
      'اشرح وظيفة كل مدخل ومخرج وأي افتراض عن القطع. ثم اكتب ملف Arduino واحدًا قابلًا للتجميع بنفس المنافذ.',
    ].join('\n');
    return Object.freeze({
      ...meta, ...lesson, components, wiring, tests, prompt,
      pins: Array.from(new Set(Object.values(meta.pinMap))),
      test: tests.map(({ step, expected }) => step + ' ' + expected).join(' '),
      status: 'reference',
      statusLabel: noMatch,
      sources: [official.uno, ...meta.sources],
    });
  }

  globalThis.MissionData = [
    mission({
      id: 'blink', title: 'LED Basics', focus: 'Digital Output يتحكم في تشغيل اللمبة وإطفائها.', image: 'blink-circuit',
      brief: 'شغّل LED لمدة ثانية، ثم أطفئها لمدة ثانية. كرّر ذلك.',
      pinMap: { led: 'D8' }, values: { ledResistance: 220, interval: 1000 },
      url: '', sources: [],
      build: (p, v) => ({
        components: [['LED', 'تعرض متى يكون D8 في وضع التشغيل.'], ['مقاومة ' + v.ledResistance + ' Ω', 'تحمي اللمبة والمنفذ بتقليل التيار.']],
        wiring: led(p.led, v.ledResistance),
        safety: ['تأكد من طرفَي LED. افصل التغذية قبل تغيير الأسلاك.'],
        tests: [test('شغّل المحاكاة وراقب LED على Breadboard.', 'تضيء ثانية وتبقى مطفأة ثانية. تتكرر الدورة كل ثانيتين.')],
        behavior: 'اضبط ' + p.led + ' بوضع OUTPUT. شغّل LED على HIGH لمدة ' + v.interval + ' ms، ثم أطفئها على LOW لمدة ' + v.interval + ' ms. كرّر ذلك.',
        skill: 'شغّل اللمبة وأطفئها من الكود بتوقيت ثابت.',
        code: code('// Blink the external LED connected to ' + p.led + '.', 'const byte ledPin = ' + pin(p.led) + ';',
          'const unsigned long intervalMs = ' + v.interval + ';', '', 'void setup() {', '  pinMode(ledPin, OUTPUT);', '}', '',
          'void loop() {', '  digitalWrite(ledPin, HIGH);', '  delay(intervalMs);', '  digitalWrite(ledPin, LOW);',
          '  delay(intervalMs);', '}'),
      }),
    }),
    mission({
      id: 'button-led', title: 'Button Controlled LED', focus: 'Digital Input يقرأ حالة الزر باستخدام Pull-up Resistor داخلية.', image: 'button',
      brief: 'شغّل LED أثناء الضغط على الزر. أطفئها عند تركه.',
      pinMap: { button: 'D2', led: 'D8' }, values: { ledResistance: 220 },
      url: '', sources: [official.pullup],
      build: (p, v) => ({
        components: [['Push Button', 'يوصل الطرفين ما دمت ضاغطًا عليه.'], ['LED ومقاومة ' + v.ledResistance + ' Ω', 'تضيء اللمبة عند الضغط. تحميها المقاومة.']],
        wiring: [...led(p.led, v.ledResistance),
          row('طرف التلامس الأول في الزر', 'Arduino ' + p.button, 'تبقي Pull-up Resistor الداخلية قراءة D2 على HIGH عند ترك الزر.'),
          row('طرف التلامس المقابل', 'Arduino GND', 'عند الضغط يتصل D2 بالأرضي، فيقرأ Arduino القيمة LOW.')],
        safety: ['ركّب الزر فوق الشق في Breadboard. استخدم وضع الاستمرارية في الملتيميتر لمعرفة الأرجل المتصلة.'],
        tests: [test('شغّل المحاكاة من دون الضغط على الزر.', 'المدخل HIGH والمصباح مطفأ.'), test('اضغط الزر ثم اتركه.', 'يقرأ D2 القيمة LOW وتضيء اللمبة أثناء الضغط. تنطفئ بعد ترك الزر.')],
        behavior: 'اضبط مدخل الزر INPUT_PULLUP وأضئ المصباح عندما تكون القراءة LOW.',
        skill: 'اقرأ الزر من D2 وشغّل اللمبة على D8.',
        code: code('const byte buttonPin = ' + pin(p.button) + ';', 'const byte ledPin = ' + pin(p.led) + ';', '',
          'void setup() {', '  pinMode(buttonPin, INPUT_PULLUP);', '  pinMode(ledPin, OUTPUT);', '}', '',
          'void loop() {', '  bool pressed = digitalRead(buttonPin) == LOW;', '  digitalWrite(ledPin, pressed ? HIGH : LOW);', '}'),
      }),
    }),
    mission({
      id: 'brightness', title: 'LED Brightness Control', focus: 'Analog Input يقرأ A0، وPWM على D9 يغيّر سطوع LED.', image: 'pot',
      brief: 'لفّ Potentiometer لتغيّر سطوع LED.',
      pinMap: { input: 'A0', led: 'D9' }, values: { ledResistance: 220, potResistance: 10 },
      url: '', sources: [official.analogWrite],
      build: (p, v) => ({
        components: [['Potentiometer ' + v.potResistance + ' kΩ', 'مقاومة متغيرة. لف المقبض يغيّر جهد طرفها الأوسط.'], ['LED ومقاومة ' + v.ledResistance + ' Ω', 'تزداد الإضاءة كلما بقي الخرج HIGH مدة أطول في كل دورة.']],
        wiring: [...potInput(p.input, v.potResistance), ...led(p.led, v.ledResistance)],
        safety: ['استخدم D9 لأنه يدعم PWM. ضع المقاومة في المسار نفسه مع اللمبة.'],
        tests: [test('لفّ المقبض من البداية إلى النهاية. توقّف عند الربع والنصف وثلاثة الأرباع.', 'تبدأ اللمبة مطفأة ثم يزداد سطوعها.')],
        behavior: 'اقرأ A0 بالدالة analogRead. حوّل القراءة من 0–1023 إلى 0–255 وأرسلها إلى analogWrite على D9.',
        skill: 'استخدم قراءة المدخل لضبط وقت تشغيل اللمبة في كل دورة PWM.',
        code: code('const byte potPin = ' + pin(p.input) + ';', 'const byte ledPin = ' + pin(p.led) + ';', '',
          'void setup() { pinMode(ledPin, OUTPUT); }', '',
          'void loop() {', '  int reading = analogRead(potPin);', '  int duty = map(reading, 0, 1023, 0, 255);',
          '  analogWrite(ledPin, duty);', '}'),
      }),
    }),
    mission({
      id: 'motor', title: 'DC Motor Speed Control', focus: 'MOSFET هو مفتاح يتحكم في تيار المحرك من مصدر خارجي.', image: 'mosfet',
      brief: 'لفّ Potentiometer لتغيّر سرعة محرك DC.',
      pinMap: { input: 'A0', motor: 'D9' }, values: { gateResistance: 330, pulldown: 10, potResistance: 10 },
      url: '', sources: [official.analogWrite, official.mosfet],
      build: (p, v) => ({
        components: [['DC Motor منخفض الجهد', 'يدور بتيار من مصدر التغذية الخارجي.'],
          ['IRLZ44N أو MOSFET قناة N مناسب', 'تتحكم إشارة Gate في مرور تيار المحرك إلى الأرضي.'],
          ['مقاومة على Gate ' + v.gateResistance + ' Ω وPull-down Resistor ' + v.pulldown + ' kΩ', 'تخفف الأولى دفعة التيار عند تبديل Gate. تبقي الثانية المحرك مطفأ عند بدء Arduino.'],
          ['Flyback Diode', 'دايود حماية يعطي تيار المحرك مسارًا بعد الإطفاء.'],
          ['مصدر DC مناسب للمحرك', 'وفّر جهد المحرك وتيار لحظة بدء الدوران.'],
          ['Potentiometer ' + v.potResistance + ' kΩ', 'مقاومة متغيرة لضبط السرعة.']],
        wiring: [...potInput(p.input, v.potResistance),
          row('Arduino ' + p.motor, v.gateResistance + ' Ω ثم MOSFET Gate', 'يرسل Arduino نبضات PWM إلى طرف التحكم Gate.'),
          row('MOSFET Gate', v.pulldown + ' kΩ ثم GND المشترك', 'تبقي هذه المقاومة Gate عند 0V عندما يترك Arduino المنفذ عائمًا، أي بلا مستوى ثابت.'),
          row('MOSFET Source + سالب مصدر المحرك', 'Arduino GND', 'الأرضي المشترك يجعل Arduino وMOSFET يستخدمان نقطة الصفر نفسها.'),
          row('MOSFET Drain', 'طرف المحرك السالب', 'يمر التيار من المحرك إلى Drain عند التشغيل.'),
          row('طرف المحرك الموجب', 'موجب مصدر المحرك الخارجي', 'تيار الحمل يأتي من مصدره الخاص.'),
          row('دايود Flyback', 'Cathode المخطّط إلى موجب المحرك، وAnode إلى Drain', 'يمر فيه تيار الملف لفترة قصيرة بعد فصل المحرك. هذا يحمي MOSFET.')],
        safety: ['اربط سالب مصدر المحرك بـGND على Arduino. أبقِ الموجب الخارجي للمحرك وحده.', 'راجع ترتيب الأرجل ومقاومة MOSFET أثناء التشغيل RDS(on) عند جهد Gate المتاح. افحص الحرارة وتيار المحرك إذا توقف عموده، واختر دايودًا يناسب جهد المحرك وتياره.'],
        tests: [test('ابدأ بنسبة تشغيل 0% ثم ارفعها تدريجيًا.', 'يبدأ المحرك متوقفًا. قد يحتاج إلى نسبة تشغيل أعلى قبل أن يدور.'),
          test('قارن السرعة عند قيم PWM متوسطة وعالية. عند التجربة بقطع حقيقية، قِس الجهد وتيار بدء الدوران.', 'تزيد السرعة عادةً مع زيادة نسبة التشغيل. تيار المحرك يأتي من مصدره الخارجي.')],
        behavior: 'ابدأ والمحرك مطفأ. اقرأ A0 وحوّل 0–1023 إلى 0–255 لضبط PWM على ' + p.motor + '.',
        skill: 'ميّز إشارة التحكم عن تغذية المحرك، واشرح لماذا يحتاجان أرضيًا مشتركًا ودايود حماية.',
        code: code('const byte potPin = ' + pin(p.input) + ';', 'const byte motorPin = ' + pin(p.motor) + ';', '',
          'void setup() {', '  pinMode(motorPin, OUTPUT);', '  analogWrite(motorPin, 0);', '}', '',
          'void loop() {', '  int duty = map(analogRead(potPin), 0, 1023, 0, 255);', '  analogWrite(motorPin, duty);',
          '  delay(10);', '}'),
      }),
    }),
    mission({
      id: 'servo-lab', title: 'Servo Angle Control', focus: 'Servo يحرك ذراعه حسب مدة نبضة التحكم.', image: 'servo',
      brief: 'لفّ Potentiometer لتغيّر زاوية ذراع السيرفو.',
      pinMap: { input: 'A0', servo: 'D9' }, values: { potResistance: 10, minAngle: 0, maxAngle: 180, startAngle: 90 },
      url: '', sources: [official.servo],
      build: (p, v) => ({
        components: [['Servo صغير', 'مدة النبضة تحدد زاوية الذراع.'],
          ['Potentiometer ' + v.potResistance + ' kΩ', 'مقاومة متغيرة يقرأ Arduino جهدها ليختار الزاوية.'],
          ['مصدر مناسب للسيرفو عند التنفيذ العملي', 'يتحمل تيار السيرفو عند بدء الحركة وأثناءها.']],
        wiring: [...potInput(p.input, v.potResistance),
          row('Arduino ' + p.servo, 'Servo Signal', 'تولّد مكتبة Servo النبضات المطلوبة لضبط زاوية الذراع.'),
          row('Servo Power', '5V في المحاكاة أو موجب مصدر مستقل ملائم على العتاد', 'يحتاج السيرفو مصدرًا يتحمل تياره، خصوصًا عند بدء الحركة.'),
          row('Servo Ground وسالب مصدره عند استخدامه', 'Arduino GND', 'يستخدم الأردوينو والسيرفو المرجع نفسه للإشارة.')],
        safety: ['راجع ألوان أسلاك السيرفو حسب طرازه. اختبر حركة الذراع من دون حمل واضبط minAngle وmaxAngle حسب الحاجة. أبقِ موجب المصدر الخارجي منفصلًا عن 5V اللوحة.'],
        tests: [test('جرّب المقبض عند البداية والربع والمنتصف وثلاثة الأرباع والنهاية.',
          'في المحاكاة، تتوقع زوايا قريبة من 0° و45° و90° و135° و180° بالترتيب.')],
        behavior: 'استخدم مكتبة Servo واضبط زاوية أولية ' + v.startAngle + '°. حوّل قيمة المدخل إلى زاوية بين ' +
          v.minAngle + '° و' + v.maxAngle + '° ويمكن تضييق المجال بعد اختبار حدود الحركة الفعلية.',
        skill: 'اختر زاوية لذراع السيرفو وميّزها عن سرعة دوران محرك DC.',
        code: code('#include <Servo.h>', '', 'const byte potPin = ' + pin(p.input) + ';', 'const byte servoPin = ' + pin(p.servo) + ';',
          '// Simulation limits. Calibrate and narrow these before attaching a real load.',
          'const int minAngle = ' + v.minAngle + ';', 'const int maxAngle = ' + v.maxAngle + ';', 'Servo arm;', '',
          'void setup() {', '  arm.attach(servoPin);', '  arm.write(' + v.startAngle + ');', '}', '',
          'void loop() {', '  int angle = map(analogRead(potPin), 0, 1023, minAngle, maxAngle);', '  arm.write(angle);',
          '  delay(20);', '}'),
      }),
    }),
    mission({
      id: 'distance', title: 'Ultrasonic Distance Alarm', focus: 'HC-SR04 يقيس المسافة من زمن رجوع الصدى.', image: 'ultrasonic',
      brief: 'خلّ الصفارات تتقارب كلما اقترب جسم من حساس المسافة.',
      pinMap: { trig: 'D6', echo: 'D7', buzzer: 'D8' },
      values: { triggerUs: 10, timeoutUs: 30000, intervalMs: 65, minCm: 2, maxCm: 400, soundCmUs: 0.0343,
        closeCm: 10, mediumCm: 20, silentCm: 30, beepHz: 1200, beepMs: 55, nearMs: 130, midMs: 300, farMs: 650 },
      url: '', sources: [official.ultrasonic, official.pulse, official.tone],
      build: (p, v) => ({
        components: [['HC-SR04', 'حساس مسافة يرسل موجة ويقيس زمن رجوع صداها.'],
          ['Passive Piezo', 'جرس يحوّل نبضات Arduino إلى صفارات.']],
        wiring: [row('HC-SR04 VCC', 'Arduino 5V', 'يعمل الحساس بجهد 5V.'),
          row('HC-SR04 GND', 'Arduino GND', 'مرجع الجهد للحساس وArduino.'),
          row('Arduino ' + p.trig, 'HC-SR04 Trig', 'ترسل نبضة إلى Trig ليبدأ الحساس القياس.'),
          row('HC-SR04 Echo', 'Arduino ' + p.echo, 'مدة نبضة Echo تمثل زمن ذهاب الموجة وعودة صداها.'),
          ...piezo(p.buzzer)],
        safety: [piezoCare, 'خرج Echo عادة 5 V في هذا الطراز. استخدم محوّل مستويات جهد إذا كان مدخل اللوحة يعمل عند 3.3 V ولا يتحمل 5 V.'],
        tests: [test('جرّب جسمًا عند 5 و15 و25 و50 cm.', 'عند 5 cm صفارات سريعة، وعند 15 cm أبطأ، وعند 25 cm متباعدة، وعند 50 cm صمت.'),
          test('أزل الهدف أو افصل Echo في المحاكاة.', 'يصمت الجرس وتظهر «No valid echo» في Serial Monitor.')],
        behavior: 'أرسل نبضة ' + v.triggerUs + ' µs، وقِس مدة Echo بمهلة ' + (v.timeoutUs / 1000) +
          ' ms. المسافة بالسنتيمتر = زمن الصدى بالميكروثانية × ' + v.soundCmUs +
          ' ÷ 2. تعامل مع مهلة القياس والقراءة خارج النطاق كحالة غير صالحة. اجعل الصفارات سريعة تحت ' + v.closeCm +
          ' cm، ومتوسطة تحت ' + v.mediumCm + ' cm، ومتباعدة تحت ' + v.silentCm + ' cm، وصامتة من ذلك الحد فأكثر. اطبع المسافة على Serial.',
        skill: 'احسب المسافة من زمن الصدى واضبط سرعة التنبيه بحسبها.',
        code: code('const byte trigPin = ' + pin(p.trig) + ';', 'const byte echoPin = ' + pin(p.echo) + ';',
          'const byte piezoPin = ' + pin(p.buzzer) + ';', 'unsigned long lastBeep = 0;', 'bool wasNear = false;', '',
          'void setup() {', '  pinMode(trigPin, OUTPUT);', '  pinMode(echoPin, INPUT);', '  pinMode(piezoPin, OUTPUT);',
          '  Serial.begin(9600);', '}', '',
          'void loop() {', '  digitalWrite(trigPin, LOW);', '  delayMicroseconds(2);', '  digitalWrite(trigPin, HIGH);',
          '  delayMicroseconds(' + v.triggerUs + ');', '  digitalWrite(trigPin, LOW);',
          '  unsigned long duration = pulseIn(echoPin, HIGH, ' + v.timeoutUs + 'UL);',
          '  float cm = duration * ' + v.soundCmUs + 'f / 2.0f;', '  bool valid = duration > 0 && cm >= ' + v.minCm +
            ' && cm <= ' + v.maxCm + ';',
          '  if (valid) {', '    Serial.print(cm, 1);', '    Serial.println(F(" cm"));', '  } else {',
          '    Serial.println(F("No valid echo"));', '  }', '',
          '  if (valid && cm < ' + v.silentCm + ') {',
          '    unsigned long period = cm < ' + v.closeCm + ' ? ' + v.nearMs + 'UL : cm < ' + v.mediumCm +
            ' ? ' + v.midMs + 'UL : ' + v.farMs + 'UL;',
          '    unsigned long now = millis();', '    if (!wasNear || now - lastBeep >= period) {',
          '      tone(piezoPin, ' + v.beepHz + ', ' + v.beepMs + ');', '      lastBeep = now;', '    }',
          '    wasNear = true;', '  } else {', '    noTone(piezoPin);', '    wasNear = false;', '  }',
          '  delay(' + v.intervalMs + ');', '}'),
      }),
    }),
    mission({
      id: 'alarm', title: 'PIR Motion Alarm', focus: 'PIR يستشعر الحركة من تغير الحرارة التي تصل إليه.', image: 'pir',
      brief: 'شغّل LED والجرس عندما يرصد PIR حركة.',
      pinMap: { pir: 'D2', led: 'D9', buzzer: 'D8' }, values: { ledResistance: 220, beepHz: 1200 },
      url: '', sources: [official.pir, official.tone],
      build: (p, v) => ({
        components: [['PIR Motion Sensor متوافق', 'يلاحظ تغير الأشعة الحرارية عند مرور شخص أمامه.'],
          ['LED ومقاومة ' + v.ledResistance + ' Ω', 'تشير اللمبة إلى أن الإنذار يعمل.'], ['Passive Piezo', 'يصدر التنبيه المسموع.']],
        wiring: [row('PIR VCC', 'Arduino 5V إذا كان الطراز يقبلها', 'راجع جهد التغذية المسموح لطراز الحساس.'),
          row('PIR GND', 'Arduino GND', 'مرجع خرج الحساس.'),
          row('PIR OUT', 'Arduino ' + p.pir, 'يقرأ Arduino حالة الحساس من D2.'),
          ...led(p.led, v.ledResistance), ...piezo(p.buzzer)],
        safety: [piezoCare, 'راجع ترتيب الأرجل. انتظر استقرار الحساس بعد توصيل الكهرباء. اضبط مدة بقاء الإشارة على HIGH حسب طرازه.', 'يمكن تجربة المهمة في Tinkercad إذا لم يتوفر PIR.'],
        tests: [test('انتظر استقرار الحساس وأبقِ المكان أمامه ساكنًا.', 'يقرأ D2 القيمة LOW. اللمبة مطفأة والجرس صامت.'),
          test('حرّك جسمًا أمام الحساس، ثم أوقف الحركة وانتظر حتى يعود الخرج إلى LOW.', 'عند HIGH تضيء اللمبة ويعمل الجرس. يتوقفان عند LOW.')],
        behavior: 'اقرأ D2. في هذا الطراز يعني HIGH اكتشاف حركة. شغّل المصباح ونغمة ' + v.beepHz + ' Hz في هذه الحالة، وأوقفهما عند LOW.',
        skill: 'استخدم قراءة حساس الحركة لتشغيل اللمبة والجرس معًا.',
        code: code('const byte pirPin = ' + pin(p.pir) + ';', 'const byte ledPin = ' + pin(p.led) + ';',
          'const byte piezoPin = ' + pin(p.buzzer) + ';', 'bool previous = false;', '',
          'void setup() {', '  pinMode(pirPin, INPUT);', '  pinMode(ledPin, OUTPUT);', '  pinMode(piezoPin, OUTPUT);', '}', '',
          'void loop() {', '  bool motion = digitalRead(pirPin) == HIGH;',
          '  if (motion != previous) {', '    digitalWrite(ledPin, motion ? HIGH : LOW);',
          '    if (motion) {', '      tone(piezoPin, ' + v.beepHz + ');', '    } else {', '      noTone(piezoPin);', '    }',
          '    previous = motion;', '  }', '  delay(30);', '}'),
      }),
    }),
    mission({
      id: 'temperature', title: 'TMP36 + LCD', focus: 'TMP36 يقيس الحرارة وLCD تعرض قراءتها.', image: 'lcd',
      brief: 'اقرأ الحرارة من TMP36 واعرضها بالدرجة المئوية على LCD 16×2.',
      pinMap: { tmp: 'A0', rs: 'D12', enable: 'D11', db4: 'D5', db5: 'D4', db6: 'D3', db7: 'D2' },
      values: { potResistance: 10, backlightResistance: 220, adcReference: 5.0, offsetVoltage: 0.5, scale: 100.0, updateMs: 500 },
      url: '', sources: [official.tmp, official.lcd],
      build: (p, v) => ({
        components: [['TMP36', 'حساس يتغيّر جهد خرجه مع الحرارة.'],
          ['LCD 16×2', 'تعرض الحروف والأرقام في سطرين.'],
          ['Potentiometer ' + v.potResistance + ' kΩ', 'مقاومة متغيرة لتوضيح الحروف على الشاشة.'],
          ['مقاومة ' + v.backlightResistance + ' Ω', 'تحد تيار إضاءة الشاشة الخلفية.']],
        wiring: [row('TMP36 · +VS', 'Arduino 5V', 'يعمل TMP36 على تغذية 5V.'),
          row('TMP36 · VOUT', 'Arduino ' + p.tmp, 'يقيس Arduino الجهد المرتبط بالحرارة.'),
          row('TMP36 · GND', 'Arduino GND', 'يتخذ Arduino الأرضي مرجعًا لقراءة الجهد.'),
          row('LCD #1 VSS', 'Arduino GND', 'هذا طرف الأرضي في الشاشة.'),
          row('LCD #2 VDD', 'Arduino 5V', 'تغذية الشاشة المتوافقة مع 5 V.'),
          row('LCD #3 VO', 'المنزلق الأوسط للمقاومة المتغيّرة', 'يغير التباين ويجعل الحروف مقروءة.'),
          row('LCD #4 RS', 'Arduino ' + p.rs, 'يميز الأمر من الحرف.'),
          row('LCD #5 R/W', 'Arduino GND', 'عندما يكون R/W على الأرضي يستقبل LCD البيانات من Arduino.'),
          row('LCD #6 E', 'Arduino ' + p.enable, 'يخبر الشاشة أن البيانات جاهزة لتستقبلها.'),
          row('LCD #7–#10 DB0–DB3', 'تبقى مفتوحة', 'أربعة أسلاك تكفي لأن الشاشة تستقبل كل بايت على دفعتين.'),
          row('LCD #11 DB4', 'Arduino ' + p.db4, 'أول خط مستخدم من خطوط البيانات الأربعة.'),
          row('LCD #12 DB5', 'Arduino ' + p.db5, 'ثاني خط مستخدم من خطوط البيانات الأربعة.'),
          row('LCD #13 DB6', 'Arduino ' + p.db6, 'ثالث خط مستخدم من خطوط البيانات الأربعة.'),
          row('LCD #14 DB7', 'Arduino ' + p.db7, 'رابع خط مستخدم من خطوط البيانات الأربعة.'),
          row('LCD #15 A / LED+', 'Arduino 5V عبر ' + v.backlightResistance + ' Ω', 'الأنود للإضاءة الخلفية وتحدد المقاومة التيار.'),
          row('LCD #16 K / LED−', 'Arduino GND', 'يرجع تيار إضاءة الخلفية عبر هذا الطرف.'),
          row('طرفا Potentiometer ' + v.potResistance + ' kΩ الخارجيان', 'Arduino 5V وGND', 'يسمحان بتغيير VO بين الجهدين.')],
        safety: ['تحقّق من ترتيب أرجل TMP36 الخاص بالعبوة. مع عبوة TO‑92 والوجه المسطح نحوك والأرجل للأسفل، تكون +VS يسارًا وVOUT وسطًا وGND يمينًا.', 'طابق جهد الشاشة وتيار إضاءتها مع ورقة طرازك. جهد مرجع ADC في هذا الحساب تقريبي. قِس جهد المرجع الحقيقي لتحسّن دقة القراءة.'],
        tests: [test('غيّر درجة الحرارة الافتراضية إلى 10 و25 و40 و60 °C.', 'تظهر قراءة قريبة من الحرارة المحددة. قد يختلف الرقم قليلًا بسبب دقة قياس الجهد.'),
          test('لفّ مقبض التباين فقط.', 'يتغير وضوح الحروف، وتبقى قراءة الحرارة كما هي.')],
        behavior: 'استخدم LiquidCrystal في 4-bit. جهد TMP36 = analogRead × ' + v.adcReference +
          ' ÷ 1024. الحرارة = (الجهد − ' + v.offsetVoltage + ') × ' + v.scale + '. حدّث السطر الثاني كل ' +
          v.updateMs + ' ms من غير مسح الشاشة كلها.',
        skill: 'حوّل جهد TMP36 إلى درجة مئوية واعرضها على الشاشة.',
        code: code('#include <LiquidCrystal.h>', '', 'const byte temperaturePin = ' + pin(p.tmp) + ';',
          'LiquidCrystal lcd(' + [p.rs, p.enable, p.db4, p.db5, p.db6, p.db7].map(pin).join(', ') + ');', '',
          'void setup() {', '  lcd.begin(16, 2);', '  lcd.setCursor(0, 0);', '  lcd.print(F("Temperature:"));', '}', '',
          'void loop() {', '  float volts = analogRead(temperaturePin) * (' + v.adcReference.toFixed(1) + 'f / 1024.0f);',
          '  float celsius = (volts - ' + v.offsetVoltage + 'f) * ' + v.scale.toFixed(1) + 'f;',
          '  lcd.setCursor(0, 1);', '  size_t columns = lcd.print(celsius, 1);', '  columns += lcd.print(F(" C"));',
          "  while (columns++ < 16) lcd.write(' ');", '  delay(' + v.updateMs + ');', '}'),
      }),
    }),
  ];
})();
