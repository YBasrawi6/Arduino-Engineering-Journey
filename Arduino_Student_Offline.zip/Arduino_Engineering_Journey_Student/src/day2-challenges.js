(() => {
  'use strict';
  const challenges = globalThis.Day2ChallengeData;
  const {escape} = globalThis.Workshop;
  const lab = () => globalThis.Journey;
  const route = id => '#journey/final-challenge' + (id ? '/' + id : '');
  const lessonImage = task => '<img src="assets/photos/' + task.image + '.webp" alt="' + escape(task.title) + '" decoding="async">';
  const list = items => '<ul>' + items.map(item => '<li>' + escape(item) + '</li>').join('') + '</ul>';
  const button = (action,label) => '<button class="secondary-button" type="button" data-student-challenge="' + action + '">' + label + '</button>';
  const recall = new Map();
  const notesFields = [
    ['io','ما المدخل وما المخرج؟'],
    ['wiring','ما المنافذ التي اخترتها؟ وكيف ستوصل التغذية والأرضي؟'],
    ['testing','ما السلوك المطلوب؟ وكيف ستختبره؟'],
  ];

  function chooser() {
    return '<div class="challenge-grid student-challenge-list">' + challenges.map(task =>
      '<article class="surface challenge-choice">' + lessonImage(task) + '<h2>' + escape(task.title) +
      '</h2><p><bdi>' + escape(task.en) + '</bdi></p><p>' + escape(task.brief) + '</p><a class="primary-button" href="' +
      route(task.id) + '">ابدأ التحدي</a></article>').join('') + '</div>';
  }

  function prompt(task) {
    return ['اكتب Sketch متوافقًا مع Arduino Uno R3 لمشروع ' + task.title + '.',
      'القطع: ' + task.parts.join('، ') + '.',
      'التوصيلات: ' + task.wiring.map(([from,to]) => from + ' → ' + to).join('؛ ') + '.',
      'الهدف: ' + task.brief, 'شروط النجاح: ' + task.success,
      'اشرح افتراضات التغذية والمنافذ، ثم أعطني الكود وثلاث حالات اختبار. راجع الكود مع التوصيلات قبل تشغيله.'].join('\n');
  }
  function wiringDiagram(task) {
    const height = task.wiring.length * 38 + 18;
    return '<svg viewBox="0 0 850 ' + height + '" role="img" class="day2-solution-diagram" aria-label="مخطط خطوط التوصيل">' +
      task.wiring.map(([from,to],index) => {
        const y = 34 + index * 38;
        return '<g><path d="M382 ' + (y-5) + 'h82"/><circle cx="382" cy="' + (y-5) + '" r="4"/><circle cx="464" cy="' +
          (y-5) + '" r="4"/><text x="368" y="' + y + '" text-anchor="end" direction="ltr">' + escape(from) +
          '</text><text x="478" y="' + y + '" text-anchor="start" direction="ltr">' + escape(to) + '</text></g>';
      }).join('') + '</svg>';
  }
  function solution(task) {
    const simulator = globalThis.StudentLinks.circuit(task.id);
    return '<section class="surface student-solution" data-challenge-solution><h3>الحل المرجعي</h3>' +
      wiringDiagram(task) + '<div class="wiring-table-wrap"><table class="wiring-table"><thead><tr><th scope="col">من</th><th scope="col">إلى</th></tr></thead><tbody>' +
      task.wiring.map(([from,to]) => '<tr><td><bdi>' + escape(from) + '</bdi></td><td><bdi>' + escape(to) + '</bdi></td></tr>').join('') +
      '</tbody></table></div><p>' + escape(task.test) + '</p><details class="engineering-detail"><summary>الكود المرجعي</summary>' +
      '<div class="mission-tools">' + button('copy-code','انسخ الكود') + button('download','تنزيل .ino') +
      '</div><pre class="mission-code" dir="ltr"><code>' + escape(task.code) + '</code></pre></details>' +
      '<details class="engineering-detail"><summary>طلب الذكاء الاصطناعي</summary><textarea readonly rows="7" aria-label="طلب الذكاء الاصطناعي" class="mission-prompt">' +
      escape(prompt(task)) + '</textarea>' + button('copy-prompt','انسخ الطلب') + '</details><output role="status" data-student-challenge-status></output>' +
      '<div class="mission-tools"><a class="secondary-button" href="#journey/reality/' + task.id + '">من المحاكاة إلى الواقع</a>' +
      (simulator ? '<a class="secondary-button" href="' + escape(simulator) +
        '" target="_blank" rel="noopener noreferrer">افتح دائرة الحل في Tinkercad</a>' : '') + '</div>' +
      (simulator ? '<p class="fine-print">' + escape(globalThis.StudentLinks.circuitAccess(task.id)) + '</p>' : '') + '</section>';
  }

  function panel(task,state) {
    return '<article class="surface challenge-feature student-challenge"><header><div><h2>' + escape(task.title) +
      '</h2><p class="mission-lead">' + escape(task.brief) + '</p></div>' + lessonImage(task) + '</header>' +
      '<div class="student-challenge-grid"><section><h3>القطع المتاحة</h3>' + list(task.parts) + '<h3>شروط النجاح</h3><p>' +
      escape(task.success) + '</p></section><section class="student-attempt"><h3>جرّب تصميمك أولًا</h3>' +
      notesFields.map(([id,label]) => '<label>' + label + '<textarea rows="2" data-attempt="' + id + '">' +
        escape(state.notes[id] || '') + '</textarea></label>').join('') +
      '<p class="fine-print">مسودتك تبقى في هذا المتصفح.</p></section></div>' +
      '<div class="mission-tools"><a class="secondary-button" href="' + route() + '">كل التحديات</a>' +
      '<a class="secondary-button" href="https://www.tinkercad.com/dashboard/designs/circuits" target="_blank" rel="noopener noreferrer">محرّر Tinkercad</a>' +
      (state.hints < task.hints.length ? button('hint','اكشف التلميح ' + (state.hints+1)) : '') +
      button('reveal',state.revealed ? 'أخفِ الحل' : 'اكشف الحل عندما تنتهي') + '</div>' +
      (state.hints ? '<details class="engineering-detail" open><summary>التلميحات المكشوفة</summary><ol>' +
        task.hints.slice(0,state.hints).map(hint => '<li>' + escape(hint) + '</li>').join('') + '</ol></details>' : '') +
      (state.revealed ? solution(task) : '') + '</article>';
  }

  function mount(host,detail) {
    const task = challenges.find(item => item.id === detail);
    if (!task) {
      host.innerHTML = chooser();
      return;
    }
    const state = recall.get(task.id) ?? {hints:0,revealed:false,notes:lab().read('attempt-' + task.id,{})};
    recall.set(task.id,state);
    const render = () => {host.innerHTML = panel(task,state);};
    render();
    host.addEventListener('input',event => {
      const field = event.target.dataset.attempt;
      if (!field) return;
      state.notes[field] = event.target.value;
      lab().write('attempt-' + task.id,state.notes);
    });
    host.addEventListener('click',async event => {
      const action = event.target.closest('[data-student-challenge]')?.dataset.studentChallenge;
      if (action === 'hint' || action === 'reveal') {
        if (action === 'hint') state.hints = Math.min(task.hints.length,state.hints+1);
        else state.revealed = !state.revealed;
        render();
        const focus = host.querySelector('[data-student-challenge="' + action + '"]') ||
          host.querySelector('[data-student-challenge="reveal"]');
        focus?.focus({preventScroll:true});
      }
      if (action === 'download') {
        globalThis.JourneyMissions.downloadSketch('challenge-' + task.id,task.code);
      }
      if (action === 'copy-code' || action === 'copy-prompt') {
        const result = await globalThis.JourneyMissions.clipboard(action === 'copy-code' ? task.code : prompt(task));
        const feedback = host.querySelector('[data-student-challenge-status]');
        if (feedback) feedback.textContent = result ? 'نُسخ إلى الحافظة.' : 'حدّد النص وانسخه من المتصفح.';
      }
    });
  }
  function reality(detail) {
    const task = challenges.find(item => item.id === detail) ?? challenges[0];
    const photos = {
      lighting:[['ldr','LDR'],['led','LED'],['resistor','Resistor']],
      parking:[['ultrasonic','HC-SR04'],['servo','Servo Motor'],['lab-aa4','Power']],
      fan:[['lab-fan','DC Fan'],['temp','TMP36'],['mosfet','MOSFET']],
    };
    const steps = [
      'حدّد القطع المتوفرة وافحص جهد التغذية والقطبية.', 'وصّل الدائرة وهي مفصولة عن التغذية.',
      'ارفع البرنامج إلى Uno باستخدام Arduino IDE.', 'قارن حالات الاختبار على العتاد بنتائج المحاكاة.',
    ];
    return '<header class="scene-heading"><div><h1 id="scene-title">من المحاكاة إلى الواقع</h1><p><bdi>From Simulation to Reality</bdi></p></div></header>' +
      '<nav class="mission-tools">' + challenges.map(item => '<a class="secondary-button" href="#journey/reality/' + item.id +
        '"' + (item === task ? ' aria-current="page"' : '') + '>' + escape(item.title) + '</a>').join('') +
      '</nav><div class="surface day2-reality"><section><h2>' + escape(task.title) + '</h2>' + list(task.parts) +
      '<h3>اختبر تركيبك</h3><ol>' + steps.map(step=>'<li>' + escape(step) + '</li>').join('') + '</ol><p>' + escape(task.test) + '</p></section>' +
      '<div class="day2-reality-photos">' + photos[task.id].map(([image,label]) => '<figure><img src="assets/photos/' + image +
        '.webp" alt="' + escape(label) + '"><figcaption><bdi>' + escape(label) + '</bdi></figcaption></figure>').join('') + '</div></div>';
  }
  globalThis.Day2Challenges = {mount,reality};
})();
