globalThis.PhotoCredits = {
  "resistor": {
    "source": "oomlout",
    "page": "https://commons.wikimedia.org/wiki/File:220_ohms_5%25_axial_resistor.jpg",
    "rights": "[CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/)"
  },
  "pot": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/562"
  },
  "capacitor": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1589"
  },
  "diode": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/755"
  },
  "led": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/299"
  },
  "inductor": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://enigma-shop.com/products/leaded-inductors"
  },
  "transistor": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/756"
  },
  "mosfet": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.smartkits.com.br/transistor-mosfet"
  },
  "relay": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/relay-spdt-sealed.html"
  },
  "button": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/367"
  },
  "latch": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://hackspark.fr/en/switches-and-buttons/1084-self-locking-push-button-8x8mm-6-pin-switch-blue.html"
  },
  "buzzer": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1536"
  },
  "ldr": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/161"
  },
  "ir": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://sensorkit.joy-it.net/en/sensors/ky-032"
  },
  "ultrasonic": {
    "source": "SparkFun",
    "page": "https://commons.wikimedia.org/wiki/File:SparkFun_HC-SR04_Ultrasonic-Sensor_13959-01a.jpg",
    "rights": "[CC BY 2.0](https://creativecommons.org/licenses/by/2.0/)"
  },
  "temp": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/165"
  },
  "servo": {
    "source": "Luiz Augusto Souza de Mesquita",
    "page": "https://commons.wikimedia.org/wiki/File:Micro_Servo_Motor_TowerPro_SG90_e_Acess%C3%B3rios.png",
    "rights": "[CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)"
  },
  "driver": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/sparkfun-full-bridge-motor-driver-breakout-l298n.html"
  },
  "relay-module": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://sensorkit.joy-it.net/en/sensors/ky-019"
  },
  "seven": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sunfounder.com/products/30pcs-0-56-7-segment-led"
  },
  "lcd": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1447"
  },
  "oled": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SBC-OLED01"
  },
  "pir": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/189"
  },
  "jumper-mm": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/758"
  },
  "jumper-mf": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1954"
  },
  "jumper-ff": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1950"
  },
  "breadboard-top": {
    "source": "Evan-Amos",
    "page": "https://commons.wikimedia.org/wiki/File:Electronics-White-Breadboard.jpg",
    "rights": "[Public domain](https://commons.wikimedia.org/wiki/Template:PD-self)"
  },
  "breadboard-strip": {
    "source": "SparkFun Learn",
    "page": "https://learn.sparkfun.com/tutorials/how-to-use-a-breadboard/all",
    "rights": "[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)"
  },
  "breadboard-rails": {
    "source": "SparkFun Learn",
    "page": "https://learn.sparkfun.com/tutorials/how-to-use-a-breadboard/all",
    "rights": "[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)"
  },
  "relay-fan": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://projecthub.arduino.cc/placitech/smart-fan-using-the-plug-and-make-kit-d88a63"
  },
  "mpu6050": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3886"
  },
  "bluetooth": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://wiki.dfrobot.com/tel0026/"
  },
  "rfid": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SBC-RFID-RC522"
  },
  "blink-circuit": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.tinkercad.com/circuits"
  },
  "uno-r3": {
    "source": "MakeMagazinDE",
    "page": "https://commons.wikimedia.org/wiki/File:Arduino_uno_r3.jpg",
    "rights": "[CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)"
  },
  "lab-resistor-bands": {
    "source": "oomlout",
    "page": "https://commons.wikimedia.org/wiki/File:220_ohms_5%25_axial_resistor.jpg",
    "rights": "[CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/)"
  },
  "lab-trimmer-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.ebay.com/itm/305658909399"
  },
  "lab-trimmer": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://smdx.ru/trimmer-3296w-10k"
  },
  "lab-capacitor-rating": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1589"
  },
  "lab-ceramic": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/753"
  },
  "lab-film-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://synthcube.com/5-pack-wima-mks2-22uf-63v-5-metallized-polyester-capacitors-220nf/"
  },
  "lab-film": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.digikey.com/en/products/detail/wima/MKS2C042201K00KI00/19128173"
  },
  "lab-diode-stripe": {
    "source": "Wikimedia Commons",
    "page": "https://commons.wikimedia.org/wiki/File:Diode_1N4007.jpg",
    "rights": "[CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)"
  },
  "lab-zener-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/zener-diode-12v-300mw.html"
  },
  "lab-zener": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/zener-diode-12v-300mw.html"
  },
  "lab-schottky-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/schottky-diode.html"
  },
  "lab-schottky": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/schottky-diode.html"
  },
  "lab-rgb-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/302"
  },
  "lab-rgb": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/302"
  },
  "lab-toggle-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3218"
  },
  "lab-toggle": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3218"
  },
  "lab-slide-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/805"
  },
  "lab-slide": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/805"
  },
  "lab-rocker-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/rocker-switch-spst-round.html"
  },
  "lab-rocker": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/rocker-switch-spst-round.html"
  },
  "lab-dip-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/dip-switch-8-position.html"
  },
  "lab-dip": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/dip-switch-8-position.html"
  },
  "lab-limit": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.pololu.com/product/1528"
  },
  "lab-pnp": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3599"
  },
  "lab-mosfet-marking": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.ebay.com/itm/175351920833"
  },
  "lab-l293d-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/807"
  },
  "lab-l293d": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/807"
  },
  "lab-relay-contact-photo": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://projecthub.arduino.cc/placitech/smart-fan-using-the-plug-and-make-kit-d88a63"
  },
  "lab-dc-motor-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/711"
  },
  "lab-dc-motor": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/711"
  },
  "lab-geared-inside": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3777"
  },
  "lab-geared": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3777"
  },
  "lab-servo-wires": {
    "source": "Luiz Augusto Souza de Mesquita",
    "page": "https://commons.wikimedia.org/wiki/File:Micro_Servo_Motor_TowerPro_SG90_e_Acess%C3%B3rios.png",
    "rights": "[CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/)"
  },
  "lab-stepper-wires": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/324"
  },
  "lab-stepper": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/324"
  },
  "lab-stepper28": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SBC-Moto1"
  },
  "lab-uln2003-wiring": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SBC-Moto1"
  },
  "lab-uln2003": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SBC-Moto1"
  },
  "lab-vibration-motor-leads": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1201"
  },
  "lab-vibration-motor": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1201"
  },
  "lab-fan-rotor": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3368"
  },
  "lab-fan": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3368"
  },
  "lab-solenoid-plunger": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/412"
  },
  "lab-solenoid": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/412"
  },
  "lab-passive-buzzer-leads": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/160"
  },
  "lab-passive-buzzer": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/160"
  },
  "lab-ldr-surface": {
    "source": "Nevit Dilmen",
    "page": "https://commons.wikimedia.org/wiki/File:LDR_1480405_6_7_HDR_Enhancer_1.jpg",
    "rights": "[CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/)"
  },
  "lab-ultrasonic-main": {
    "source": "SparkFun",
    "page": "https://commons.wikimedia.org/wiki/File:SparkFun_HC-SR04_Ultrasonic-Sensor_13959-01a.jpg",
    "rights": "[CC BY 2.0](https://creativecommons.org/licenses/by/2.0/)"
  },
  "lab-pir-front": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/189"
  },
  "lab-ir-adjust": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://sensorkit.joy-it.net/en/sensors/ky-032"
  },
  "lab-tmp36-body": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/165"
  },
  "lab-dht11-back": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/386"
  },
  "lab-dht11": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/386"
  },
  "lab-dht22-back": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/385"
  },
  "lab-dht22": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/385"
  },
  "lab-fsr-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/166"
  },
  "lab-fsr": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/166"
  },
  "lab-tilt-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/173"
  },
  "lab-tilt": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/173"
  },
  "lab-gas-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/alcohol-gas-sensor-mq-3.html"
  },
  "lab-gas": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/alcohol-gas-sensor-mq-3.html"
  },
  "lab-photodiode-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/miniature-solar-cell-bpw34.html"
  },
  "lab-photodiode": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/miniature-solar-cell-bpw34.html"
  },
  "lab-phototransistor-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/2831"
  },
  "lab-phototransistor": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/2831"
  },
  "lab-ambient-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/6524"
  },
  "lab-ambient": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/6524"
  },
  "lab-flame": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://sensorkit.joy-it.net/en/sensors/ky-026"
  },
  "lab-soil-connector": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/4026"
  },
  "lab-soil": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/4026"
  },
  "lab-water-wires": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3397"
  },
  "lab-water": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3397"
  },
  "lab-rain": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.dfrobot.com/product-798.html"
  },
  "lab-hall-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/158"
  },
  "lab-hall": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/158"
  },
  "lab-vibration-spring": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1766"
  },
  "lab-vibration": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1766"
  },
  "lab-sound": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://sensorkit.joy-it.net/en/sensors/ky-038"
  },
  "lab-color-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1334"
  },
  "lab-color": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1334"
  },
  "lab-line": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SEN-KY033LT"
  },
  "lab-lcd-back-labels": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/181"
  },
  "lab-lcd-i2c-labels": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/292"
  },
  "lab-lcd-i2c": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/292"
  },
  "lab-oled-front": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SBC-OLED01"
  },
  "lab-seven-front": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.bitmi.ro/electronica/display-led-1-digit-7-segmente-catod-comun-10636.html"
  },
  "lab-seven-multi-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/7-segment-display-4-digit-red.html"
  },
  "lab-seven-multi": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.sparkfun.com/7-segment-display-4-digit-red.html"
  },
  "lab-tm1637": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.seeedstudio.com/Grove-4-Digit-Display.html"
  },
  "lab-tft-header": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/358"
  },
  "lab-tft": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/358"
  },
  "lab-usb-head": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/62"
  },
  "lab-usb-power": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/62"
  },
  "lab-adapter-rating": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/5130"
  },
  "lab-adapter": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/5130"
  },
  "lab-barrel-tip": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1329"
  },
  "lab-barrel": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.pololu.com/product/2191"
  },
  "lab-vin": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.pololu.com/product/2191"
  },
  "lab-pp3-terminals": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1321"
  },
  "lab-pp3": {
    "source": "Ashley Pomeroy",
    "page": "https://commons.wikimedia.org/wiki/File:Duracell_9_Volt_0849.jpg",
    "rights": "[CC BY 3.0](https://creativecommons.org/licenses/by/3.0/)"
  },
  "lab-aa-marking": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://lssproducts.com/aa-size-batteries-2-pack/"
  },
  "lab-aa": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.leroymerlin.ro/produse/baterii-si-acumulatori/878/baterii-alcaline-energizer-max-aa-set-2-buc/38467"
  },
  "lab-aa4-cover": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/830"
  },
  "lab-aa4": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/830"
  },
  "lab-aa6-contact": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/248"
  },
  "lab-aa6": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/248"
  },
  "lab-bench-terminals": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/JT-RD6006-C-B"
  },
  "lab-bench": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/JT-RD6006-C-B"
  },
  "lab-regulator-legs": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/2164"
  },
  "lab-regulator": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/2164"
  },
  "lab-buck-board": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1385"
  },
  "lab-buck": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/1385"
  },
  "lab-bread-power-installed": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SBC-POW-BB"
  },
  "lab-bread-power": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://joy-it.net/en/products/SBC-POW-BB"
  },
  "lab-terminal-pins": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/724"
  },
  "lab-terminals": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/724"
  },
  "lab-header-spacing": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/4154"
  },
  "lab-headers": {
    "source": "رسم تعليمي · صورة القطعة في صفحة المصدر",
    "page": "https://www.adafruit.com/product/3009"
  }
};
