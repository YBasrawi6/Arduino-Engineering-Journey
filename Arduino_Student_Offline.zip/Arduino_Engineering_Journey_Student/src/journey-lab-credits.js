globalThis.JourneyLabCredits = {};
