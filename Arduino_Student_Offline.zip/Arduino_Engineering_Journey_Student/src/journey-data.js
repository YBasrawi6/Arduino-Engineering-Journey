globalThis.JourneyData = [
  {
    "id": "welcome",
    "title": "مسارات الورشة",
    "en": "ARDUINO ENGINEERING JOURNEY",
    "chapter": "البداية",
    "goal": "اختر المسار."
  },
  {
    "id": "day1",
    "title": "اليوم الأول · الاكتشاف",
    "en": "DISCOVER & UNDERSTAND",
    "chapter": "افتتاحية",
    "goal": "ابدأ الرحلة أو افتح المستكشف مباشرة."
  },
  {
    "id": "day2",
    "title": "Today, We Build.",
    "en": "DESIGN, BUILD & TEST",
    "chapter": "اليوم الثاني",
    "goal": "اليوم نحوّل الأفكار إلى مشاريع."
  },
  {
    "id": "review",
    "title": "المراجعة السريعة",
    "en": "QUICK REVIEW",
    "chapter": "اليوم الثاني",
    "goal": "جرّب الإجابة قبل كشفها."
  },
  {
    "id": "quick",
    "title": "Quick Start",
    "en": "QUICK START",
    "chapter": "اليوم الثاني",
    "goal": "مختصر لمن فاته اليوم الأول."
  },
  {
    "id": "library",
    "title": "المكتبة الهندسية",
    "en": "ENGINEERING LIBRARY",
    "chapter": "اليوم الثاني",
    "goal": "افتح القطعة عند الحاجة إليها."
  },
  {
    "id": "practice",
    "title": "المشاريع التطبيقية",
    "en": "DESIGN, BUILD & TEST",
    "chapter": "اليوم الثاني",
    "goal": "اختر مشروعك."
  },
  {
    "id": "final-challenge",
    "title": "التحدي الهندسي النهائي",
    "en": "FINAL ENGINEERING CHALLENGE",
    "chapter": "اليوم الثاني",
    "goal": "اختر تحديًا وصمّم دائرتك واختبرها."
  },
  {
    "id": "reality",
    "title": "من المحاكاة إلى الواقع",
    "en": "FROM SIMULATION TO REALITY",
    "chapter": "اليوم الثاني",
    "goal": "راجع قطع الدائرة واختبرها قبل تنفيذها فعليًا."
  },
  {
    "id": "spark",
    "title": "هل تستطيع تشغيل هذه اللمبة؟",
    "en": "FIRST SPARK",
    "chapter": "افتتاحية",
    "goal": "جرّب الزر."
  },
  {
    "id": "automatic",
    "title": "خلّ اللوحة تتولّى التوقيت",
    "en": "FROM SWITCH TO CODE",
    "chapter": "افتتاحية",
    "goal": "شغّل الوميض."
  },
  {
    "id": "arduino",
    "title": "تعرّف على لوحة Uno R3",
    "en": "BOARD DISCOVERY",
    "chapter": "اكتشاف اللوحة",
    "goal": "اختر أي جزء من اللوحة."
  },
  {
    "id": "power",
    "title": "تغذية اللوحة",
    "en": "POWER",
    "chapter": "اكتشاف اللوحة",
    "goal": "ابدأ بخطّي 5V وGND، ثم قارن 3.3V معهما."
  },
  {
    "id": "digital",
    "title": "Digital Input / Output",
    "en": "DIGITAL I/O",
    "chapter": "اكتشاف اللوحة",
    "goal": "اختر منفذًا من الصورة."
  },
  {
    "id": "analog",
    "title": "Analog Input",
    "en": "ANALOG INPUT",
    "chapter": "اكتشاف اللوحة",
    "goal": "غيّر الجهد على A0 وراقب الرقم الذي يقرؤه البرنامج."
  },
  {
    "id": "explorer",
    "title": "افتح المستكشف الكامل",
    "en": "FREE BOARD EXPLORER",
    "chapter": "اكتشاف اللوحة",
    "goal": "جرّب أي منفذ واختبر معرفتك على الصورة."
  },
  {
    "id": "breadboard",
    "title": "وصّل الدائرة بدون لحام",
    "en": "BUILD YOUR LAB",
    "chapter": "المختبر",
    "goal": "اختر ثقبًا وتوقع الثقوب المتصلة به."
  },
  {
    "id": "supply",
    "title": "Power Bench",
    "en": "POWER BENCH",
    "chapter": "المختبر",
    "goal": "اختر مصدر التغذية أو راجع منافذ اللوحة."
  },
  {
    "id": "components",
    "title": "افتح صندوق المكونات",
    "en": "COMPONENT LAB",
    "chapter": "المختبر",
    "goal": "اختر أي قطعة من الصندوق."
  },
  {
    "id": "sensors",
    "title": "اقرأ الضوء والمسافة",
    "en": "SENSOR LAB",
    "chapter": "المختبر",
    "goal": "اختر الحساس."
  },
  {
    "id": "motors",
    "title": "من الإشارة إلى الحركة",
    "en": "ACTUATORS",
    "chapter": "المختبر",
    "goal": "اختر المحرك أو أداة التحكم."
  },
  {
    "id": "displays",
    "title": "اعرض ما تقيسه",
    "en": "DISPLAY LAB",
    "chapter": "المختبر",
    "goal": "اختر الشاشة."
  },
  {
    "id": "build",
    "title": "كيف تختار قطع مشروعك؟",
    "en": "BUILD YOUR PROJECT",
    "chapter": "اليوم الثاني",
    "goal": "اقترح قطعًا لمشروع البوابة ثم قارن اختيارك بالقطع المعروضة."
  },
  {
    "id": "build-reference",
    "title": "كيف تختار قطع مشروعك؟ · المرجع",
    "en": "BUILD YOUR PROJECT",
    "chapter": "التطبيق",
    "goal": "من فكرة بوابة المواقف إلى سلة القطع."
  },
  {
    "id": "projects",
    "title": "ابدأ مهمة هندسية",
    "en": "BUILD · ASK · TEST",
    "chapter": "التطبيق",
    "goal": "اختر دائرة، افهم توصيلاتها، ثم اطلب البرنامج واختبره."
  },
  {
    "id": "challenges",
    "title": "أي تحدٍّ تريد أن تبدأ به؟",
    "en": "FINAL CHALLENGE",
    "chapter": "التطبيق",
    "goal": "اقرأ المتطلبات وحاول تصميم الحل قبل كشفه."
  },
  {
    "id": "recordings",
    "title": "تسجيلات الورشة",
    "en": "WORKSHOP RECORDINGS",
    "chapter": "المراجع",
    "goal": "ارجع إلى تسجيل كل يوم عند توفره."
  }
];
