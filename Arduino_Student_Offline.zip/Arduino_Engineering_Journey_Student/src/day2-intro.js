(() => {
  'use strict';
  const {escape,format}=globalThis.Workshop;
  const view=(title,copy='')=>'<header class="day2-heading"><h1 id="scene-title">'+title+'</h1>'+(copy?'<p>'+copy+'</p>':'')+'</header>';
  const link=(id,label,primary=false)=>'<a class="'+(primary?'primary-button':'secondary-button')+'" href="#journey/'+id+'">'+label+'</a>';
  const image=(id,alt='')=>'<img src="'+(id==='uno'?'assets/uno-r3.jpg':'assets/photos/'+id+'.webp')+'" alt="'+escape(alt)+'" decoding="async">';
  const card=(title,copy,id,value)=>'<article class="surface day2-intro-card">'+image(id,title)+'<h2><bdi>'+title+'</bdi></h2><p>'+copy+'</p>'+value+'</article>';
  const home=()=>'<div class="day2-home">'+view('<bdi>Arduino Engineering Journey</bdi>','Student Edition · مرجع الطلاب')+
    '<div class="day2-paths">'+card('Day 2 — Design, Build & Test','صمّم، وصّل، اختبر ونفّذ.','lab-dc-motor',link('day2','ابدأ اليوم الثاني',true))+
    card('Day 1 — Discover & Understand','رحلة الاكتشاف الكاملة.','uno',link('day1','افتح اليوم الأول'))+
    card('Engineering Library','اللوحة والمكونات ومراجع التوصيل.','breadboard-top',link('library','ابحث في المكتبة'))+'</div><div class="mission-tools">'+link('projects','المشاريع الثمانية')+
    link('final-challenge','التحديات الثلاثة')+link('recordings','تسجيلات الورشة')+'</div></div>';
  const start=()=>view('<bdi>Today, We Build.</bdi>','اليوم نحوّل الأفكار إلى مشاريع.')+
    '<ol class="surface day2-pipeline" dir="ltr">'+['Idea','Components','Circuit','AI Code','Simulation','Real Project'].map(title=>'<li><bdi>'+title+'</bdi></li>').join('')+
    '</ol><div class="mission-tools">'+link('review','المراجعة السريعة',true)+link('quick','Quick Start')+
    link('build','Build Your Project')+link('practice','المشاريع مباشرة')+'</div>';
  const questions=[
    ['هل يحتاج Arduino إلى الكمبيوتر بعد رفع الكود؟','يكمل تشغيل البرنامج المحفوظ عند تغذيته من مصدر مناسب.','lab-adapter'],
    ['لماذا نستخدم مقاومة مع LED؟','تحدّ من تيار LED. ضعها على التوالي معها.','resistor'],
    ['ما الفرق بين Input وOutput؟','الزر يرسل حالة يقرأها Arduino. وتضيء LED استجابةً لإشارة يخرجها Arduino.','button'],
    ['هل نشغّل الموتور مباشرة من Digital Pin؟','ترسل اللوحة إشارة تحكم إلى Motor Driver. يأخذ الموتور طاقته من مصدر مناسب.','lab-dc-motor'],
    ['ما الوظيفة التي تتحكّم في سطوع LED؟','PWM يغيّر نسبة زمن التشغيل. اختر منفذًا يدعم PWM.','led'],
    ['لماذا نحتاج Common Ground؟','في التوصيل غير المعزول، من الأرضي المشترك تقيس الأجهزة جهد الإشارة بالنسبة إلى النقطة نفسها.','breadboard-rails'],
    ['كيف يعرف Arduino مقدار دوران Potentiometer؟','يتغيّر جهد الطرف الأوسط عند الدوران. اقرأه على A0 باستخدام analogRead.','pot'],
  ];
  function review(host){
    let index=0,revealed=false;
    const draw=()=>{
      const [question,answer,photo]=questions[index];
      host.innerHTML=view('<bdi>Quick Review</bdi>','')+
        '<article class="surface day2-review"><p><bdi>'+(index+1)+' / '+questions.length+'</bdi></p><h2>'+question+'</h2>'+
        (revealed?'<div class="day2-review-answer" data-review-answer>'+image(photo,answer)+'<p>'+answer+'</p></div>':'')+'</article>'+
        '<div class="mission-tools">'+(index?'<button class="secondary-button" type="button" data-review="prev" data-show-prev>السؤال السابق</button>':'')+
        (!revealed?'<button class="primary-button" type="button" data-review="reveal">اكشف الإجابة</button>':'')+
        (index<questions.length-1?'<button class="secondary-button" type="button" data-review="next" data-show-next>السؤال التالي</button>':link('build','اختيار قطع المشروع',true))+
        link('quick','Quick Start')+'</div>';
      globalThis.PresentationData.publish({kind:'review',phase:String(index),question,answer,next:questions[index+1]?.[0]||'اختيار قطع المشروع'});
    };
    host.addEventListener('click',event=>{
      const button=event.target.closest('[data-review]');
      if (!button) return;
      if(button.dataset.review==='reveal')revealed=true;
      else{index+=button.dataset.review==='next'?1:-1;revealed=false;}
      draw();
      host.querySelector('[data-review="'+button.dataset.review+'"]')?.focus({preventScroll:true});
    });
    draw();
  }
  const quick=()=>view('<bdi>Quick Start</bdi>','الأساسيات التي نحتاجها أثناء البناء.')+
    '<div class="day2-quick">'+[
      ['Arduino Uno','يحفظ برنامجًا ويتحكّم بالقطع عبر المنافذ.','uno'],
      ['Input / Output','الزر مدخل. والـLED مخرج. الكود يربط بينهما.','button'],
      ['Digital / Analog','Digital يقرأ HIGH أو LOW. Analog يقيس قيمة الجهد مثل جهد الطرف الأوسط للمقاومة المتغيرة.','pot'],
      ['PWM','تتحكّم في سطوع LED بتغيير نسبة تشغيل النبضات.','led'],
      ['Power / GND','اختر جهد التغذية المناسب ووحّد مرجع الأرضي للتوصيل غير المعزول.','lab-adapter'],
      ['Breadboard','يجمع ثقوبًا محددة من الداخل. افحص خطوط التغذية قبل التوصيل.','breadboard-top'],
      ['Upload / Simulation','في Arduino IDE اختر Uno والمنفذ واضغط Upload. في Tinkercad الصق الكود ثم Start Simulation.','lab-usb-head'],
    ].map(([title,copy,photo])=>card(title,copy,photo,'')).join('')+'</div><div class="mission-tools">'+link('review','المراجعة')+link('practice','المشاريع',true)+'</div>';
  function library(detail){
    const data=globalThis.JourneyLabData;
    if(['sensors','displays'].includes(detail)){
      const group=data.groups.find(row=>row.id===detail);
      return view(escape(group.title),'اختر قطعة لفتح أطرافها وتوصيلاتها.')+'<div class="day2-gallery">'+group.items.map(id=>{
        const item=data.items[id];
        const [,role,use]=globalThis.PresentationData.component(item);
        return card(escape(item.title),format(role)+(use?'<br>'+format(use):''),item.image,link('library/'+id,'التفاصيل'));
      }).join('')+'</div><div class="mission-tools">'+link('library','المكتبة الهندسية')+'</div>';
    }
    return view('<bdi>Engineering Library</bdi>','اختر المرجع الذي يحتاجه مشروعك.')+'<div class="day2-quick">'+[
      ['Arduino Explorer','منافذ Uno R3 ووظائفها.','uno','explorer'],['Component Box','المكونات وأطرافها.','relay','components/box'],
      ['Sensors','كيف نقيس الضوء والمسافة والحركة.','ultrasonic','library/sensors'],['Displays','أمثلة على الشاشات وقراءة المخرجات.','lcd','library/displays'],
      ['Power Bench','المصادر والجهد والأرضي.','lab-bench','supply'],['Breadboard','ثقوب اللوحة والأسلاك.','breadboard-top','breadboard'],
      ['Explore Mode','تجارب التغذية ومرجع التوصيل.','breadboard-rails','supply/explore'],
    ].map(([title,copy,photo,route])=>card(title,copy,photo,link(route,'افتح المرجع'))).join('')+'</div>';
  }
  const gate=[
    ['Input','HC-SR04','ultrasonic','يقيس المسافة.'],['Processing','Arduino Uno','uno','يقرر متى تفتح البوابة.'],
    ['Output','Servo Motor','servo','يحرّك ذراع البوابة.'],['Power','مصدر مناسب','lab-bench','يغذّي السيرفو.'],
    ['Wiring','Breadboard وأسلاك','breadboard-top','تربط الإشارات والتغذية.'],
  ];
  const buildTabs=['idea','needs','choose','shop'];
  function build(host,detail) {
    let visible=0;
    const stage=buildTabs.includes(detail)?detail:'idea';
    function draw(){
      if(stage==='choose'||stage==='shop'){
        host.innerHTML=globalThis.HotfixBuild.render(stage).replace('href="#journey/projects"','href="#journey/practice"');
      } else {
        const tabs=['الفكرة','الاحتياجات','المواصفات','الشراء'];
        const nav='<nav class="mission-tools" aria-label="مشاهد اختيار القطع">'+buildTabs.map((id,i)=>link('build/'+id,tabs[i],id===stage)).join('')+'</nav>';
        const content=stage==='idea'?'<h2>كيف نفتح بوابة المواقف تلقائيًا عند اقتراب سيارة؟</h2><p>اقترح القطع قبل الكشف.</p>':
          '<h2>ما الذي تحتاجه البوابة؟</h2><div class="day2-gate" data-gate-count="'+visible+'">'+gate.slice(0,visible).map(([role,name,photo,copy])=>
            card(name,copy,photo,'<bdi class="eyebrow">'+role+'</bdi>')).join('')+'</div>';
        host.innerHTML=view('<bdi>Build Your Project</bdi>','كيف تختار قطع مشروعك؟')+nav+'<article class="surface day2-review">'+content+
          '</article><div class="mission-tools">'+(stage==='idea'?'<a class="primary-button" href="#journey/build/needs" data-show-next>حدّد الاحتياجات</a>':
            visible<gate.length?'<button class="primary-button" type="button" data-gate-reveal data-show-next>اكشف القطعة التالية</button>':
            '<a class="primary-button" href="#journey/build/choose" data-show-next>قارن المواصفات</a>')+'</div>';
      }
      globalThis.PresentationData.publish({kind:'build',phase:stage,next:({
        idea:'احتياجات المشروع',needs:'اختيار القطعة',choose:'شراء القطع',shop:'المشاريع التطبيقية',
      })[stage]});
    }
    host.addEventListener('click',event=>{
      if (event.target.closest('[data-gate-reveal]')) {visible=Math.min(visible+1,gate.length);draw();}
    });
    draw();
  }
  globalThis.Day2Intro={home,start,review,quick,library,build};
})();
