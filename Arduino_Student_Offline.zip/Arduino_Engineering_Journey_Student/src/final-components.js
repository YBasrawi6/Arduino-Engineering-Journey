(() => {
  'use strict';
  const {escape,format} = globalThis.Workshop;
  const photoPins = {
    resistor:['resistor',[['Terminal 1',18,53,20,24],['Terminal 2',81,53,79,24]]],
    pot:['pot',[['End 1',20,14,12,34],['Wiper',30,14,30,2.8],['End 2',42,14,56,36]]],
    capacitor:['capacitor',[['− Stripe',33,36,16,14],['Leads',69,66,77,89]]],
    ceramic:['lab-ceramic',[['Terminal 1',45,72,26,86],['Terminal 2',53,72,72,86]]],
    film:['lab-film',[['Terminal 1',25,85,14,65],['Terminal 2',78,80,87,57]]],
    diode:['diode',[['Cathode',33,50,18,23],['Anode',84,50,79,23]]],
    led:['led',[['Cathode',22,61,11,83],['Anode',26,62,46,87]]],
    button:['button',[['Contacts',31,67,15,85],['Contacts',68,71,80,88]]],
    transistor:['transistor',[['3 Leads',51,73,72,78]]],
    mosfet:['lab-mosfet-marking',[['Gate',40,77,19,85],['Drain',49,76,50,92],['Source',59,77,81,86]]],
    relay:['relay',[['Pins',55,11,29,9]]],
    'dc-motor':['lab-dc-motor',[['Motor wires',26,31,23,13],['Shaft',81,75,89,85]]],
    servo:['servo',[['Signal · V+ · GND',35,31,66,12],['Shaft',45,47,63,63]]],
    ldr:['ldr',[['Sensor',26,59,16,80],['Leads',63,37,69,15]]],
    ultrasonic:['ultrasonic',[['VCC',45,66,18,84],['Trig',49,69,37,90],['Echo',53,69,62,90],['GND',57,66,82,84]]],
    pir:['pir',[['Lens',18,48,18,23],['VCC · OUT · GND',77,57,65,81]]],
    lcd:['lcd',[['Pins 1–16',53,34,61,16]]],
    oled:['oled',[['GND · VCC · SCL · SDA',50,10,50,22]]],
  };
  const circuits = {
    resistor:['LED + 220 Ω','blink'],
    pot:['Potentiometer',['5V','Potentiometer','GND'],['Wiper','A0']],
    trimmer:['Trimmer',['5V','Trimmer','GND'],['Wiper','VO']],
    capacitor:['Capacitor',['DC +','+ Capacitor −','GND']],
    ceramic:['Supply Filter',['5V','Ceramic Capacitor','GND']],
    film:['RC Filter',['Signal','Resistor','Output'],['Output','Film Capacitor','GND']],
    inductor:['LC Filter',['DC +','Inductor','Output'],['Output','Capacitor','GND']],
    diode:['Forward Diode',['DC +','Resistor','Anode →| Cathode','GND']],
    zener:['Zener Clamp',['DC +','Resistor','Output'],['Output','Zener (K → A)','GND']],
    schottky:['Schottky Diode',['DC +','Schottky A → K','Load','GND']],
    led:['LED + 220 Ω','blink'],
    rgb:['Common Cathode RGB',['PWM ×3','Resistor ×3','R / G / B'],['Common Cathode','GND']],
    button:['Button + Internal Pull-up','button-led'],
    latch:['Latching Button',['DC +','Switch','LED + R','GND']],
    transistor:['NPN BJT',['Arduino D8','Base Resistor','Base'],['DC +','Load','Collector → Emitter','GND']],
    pnp:['PNP High-Side Switch',['DC +','Emitter → Collector','Load','GND'],['Control','Base Resistor','Base']],
    mosfet:['MOSFET Motor Circuit','motor'],
    'dc-motor':['DC Motor + MOSFET','motor'],
    fan:['DC Fan + MOSFET','motor'],
    dc:['DC Motor Driver',['Arduino PWM','Motor Driver','DC Motor'],['Motor supply','Motor Driver V+']],
    relay:['Switch an LED with NO',['5V','COM → NO','220 Ω','LED','GND']],
    'relay-module':['Switch an LED with NO',['5V','COM → NO','220 Ω','LED','GND']],
    l293d:['H-Bridge Driver',['Arduino','L293D','DC Motor'],['Motor supply','VCC2']],
    servo:['Servo Wiring','servo-lab'],
    stepper:['Stepper Motor',['Arduino','Stepper Driver','Stepper Motor'],['Motor supply','Driver V+']],
    stepper28:['28BYJ-48',['Arduino','ULN2003','28BYJ-48']],
    uln2003:['Stepper Driver',['Arduino','ULN2003','28BYJ-48']],
    ldr:['Light Sensor Divider',['5V','LDR','A0','10 kΩ','GND']],
    ultrasonic:['Distance Sensor','distance'],
    pir:['PIR Alarm','alarm'],
    temp:['TMP36','temperature'],
    lcd:['LCD 16×2','temperature'],
    'lcd-i2c':['I²C LCD',['Arduino SDA / SCL','LCD SDA / SCL'],['Compatible VCC / GND','LCD VCC / GND']],
    oled:['I²C OLED Example',['Arduino SDA / SCL','OLED SDA / SCL'],['Compatible VCC / GND','OLED VCC / GND']],
    buzzer:['Buzzer',['Digital Output','Active Buzzer','GND']],
    'passive-buzzer':['Passive Buzzer',['Arduino tone()','Piezo','GND']],
    'usb-power':['USB Power',['Computer USB','USB Type-B','Arduino Uno']],
    adapter:['DC Adapter',['DC Adapter','DC Jack','Arduino Uno']],
    barrel:['Barrel Jack',['DC Adapter','DC Jack','Arduino Uno']],
    vin:['VIN',['DC Supply +','VIN'],['DC Supply −','GND']],
    'bread-power':['Breadboard Power Module',['DC Adapter','Power Module','5V / 3.3V Rail'],['Module GND','GND Rail']],
    'common-ground':['Common Ground',['Arduino GND','Motor Supply GND']],
  };
  const image = (name,alt) => '<img src="assets/photos/' + escape(name) + '.webp" alt="' + escape(alt) + '" decoding="async">';
  function photo(item) {
    const enhanced = globalThis.HotfixPins.photo(item);
    if (enhanced) return enhanced;
    const [key,labels] = photoPins[item.id] ?? [item.image,[]];
    const illustration = globalThis.StudentPublicMedia(key,item.title,escape);
    if (illustration) return illustration;
    return '<figure class="final-part-photo">' + image(key,item.title) +
      (labels.length ? '<svg viewBox="0 0 100 100" preserveAspectRatio="none" class="final-photo-arrows" aria-hidden="true">' +
        '<defs><marker id="photo-arrow" markerWidth="4" markerHeight="4" refX="3" refY="2" orient="auto"><path d="M0 0 L4 2 L0 4 Z"/></marker></defs>' +
        labels.map(([,x,y,lx,ly]) => '<path d="M' + lx + ' ' + ly + ' L' + x + ' ' + y + '" marker-end="url(#photo-arrow)"/>').join('') + '</svg>' +
        labels.map(([name,,,x,y]) => '<bdi class="final-photo-label" style="--x:' + x + '%;--y:' + y + '%">' + escape(name) + '</bdi>').join('') : '') + '</figure>';
  }
  function example(item,group) {
    const enhanced = globalThis.HotfixPins.details(item);
    if (enhanced) return enhanced;
    if (item.id === 'pot') return '<figure class="final-part-circuit"><figcaption><bdi>Potentiometer → A0</bdi></figcaption>' +
      '<svg class="final-pot-circuit" viewBox="0 0 470 125" role="img" aria-label="الطرفان الخارجيان إلى خمسة فولت والأرضي. الطرف الأوسط إلى A0.">' +
      '<path d="M55 78H170m130 0H415 M235 30v39m-7-8 7 8 7-8"/><rect x="170" y="64" width="130" height="28" rx="4"/>' +
      '<circle cx="55" cy="78" r="4"/><circle cx="415" cy="78" r="4"/><text x="55" y="58">5V</text><text x="415" y="58">GND</text><text x="235" y="23">A0 / Wiper</text></svg></figure>';
    const family = {
      switches:['Switch Circuit',['Digital Input (Pull-up)','Switch','GND']],
      sensors:['Connecting a Sensor',['Compatible VCC / GND','Sensor'],['Sensor Signal','Matching Arduino Pin']],
      motors:['Motor Power',['Arduino Signal','Motor Driver','Load'],['External Supply','Driver V+ / GND']],
      displays:['Connecting a Display',['Data / Clock or Control','Display'],['Compatible VCC / GND','Display Power']],
      power:['Power Path',['Power Source','Compatible Load'],['Source GND','Load GND']],
    };
    const [name,...rows] = circuits[item.id] || family[group] || ['Circuit Path',['Power / Signal','Component','Load / GND']];
    if (typeof rows[0] === 'string') {
      return '<figure class="final-part-circuit"><a href="assets/circuits/' + rows[0] + '.svg" target="_blank" rel="noopener">' +
        '<img src="assets/circuits/' + rows[0] + '.svg" alt="' + escape(name) + '"></a><figcaption><bdi>' + escape(name) + '</bdi></figcaption></figure>';
    }
    return '<figure class="final-part-circuit"><figcaption><bdi>' + escape(name) + '</bdi></figcaption>' +
      rows.map(row => '<div class="final-circuit-path" dir="ltr">' + row.map(label => '<bdi>' + escape(label) + '</bdi>').join('<i aria-hidden="true">─</i>') + '</div>').join('') +
      (['relay','relay-module'].includes(item.id) ? '' : '<p>' + format(globalThis.PresentationData.first(item.wiring)) + '</p>') + '</figure>';
  }
  function terminals(item) {
    if (globalThis.HotfixPins.has(item)) return '';
    if (item.id === 'lcd') {
      return '<p class="final-pin-row"><bdi>VSS / VDD</bdi> التغذية · <bdi>VO</bdi> التباين · <bdi>RS / R/W / E</bdi> التحكم · <bdi>D0–D7</bdi> البيانات · <bdi>A / K</bdi> إضاءة الخلفية</p>';
    }
    if (item.id === 'relay') {
      return '<p class="final-pin-row"><bdi>COM</bdi> المشترك · <bdi>NC</bdi> متصل قبل تشغيل الملف · <bdi>NO</bdi> يتصل عند تشغيل الملف</p>';
    }
    if (!item.terminals?.length) return '';
    return '<dl class="final-part-pins">' + item.terminals.map(([name,meaning]) => '<div><dt><bdi>' +
      escape(name) + '</bdi></dt><dd>' + format(globalThis.PresentationData.first(meaning)) + '</dd></div>').join('') + '</dl>';
  }
  globalThis.FinalComponents = { photo,example,terminals };
})();

