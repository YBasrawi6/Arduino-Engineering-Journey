(() => {
  'use strict';
  globalThis.Day2ChallengeData = [
    {
      id:'lighting', en:'Smart Lighting', title:'إنارة تلقائية', image:'ldr',
      brief:'تضيء LED في الظلام وتنطفئ عند عودة الضوء.',
      parts:['Arduino Uno R3','حساس LDR','مقاومة 10 kΩ','LED ومقاومة 220 Ω','Breadboard وأسلاك'],
      success:'اختبر الضوء والظلام، ثم جرّب قرب الحد. حافظ على ثبات اللمبة عند تغيّر الإضاءة قليلًا.',
      hints:['ابدأ بتحويل الضوء إلى قراءة يستطيع Arduino مقارنتها.','جرّب مقسّم جهد من LDR ومقاومة. اقرأ نقطة المنتصف على Analog Input.','احتفظ بحالة اللمبة. استخدم حدًا أقل للتشغيل وحدًا أعلى للإطفاء.'],
      wiring:[['Arduino 5V','LDR · الطرف الأول'],['LDR · الطرف الثاني','A0 + 10 kΩ إلى GND'],['Arduino D9','220 Ω ثم LED Anode'],['LED Cathode','Arduino GND']],
      test:'غطِّ LDR ثم أعد الإضاءة. عدّل حدود الكود بين قراءتي الضوء والظلام في مكان التجربة.',
      code:`const byte sensorPin = A0;
const byte ledPin = 9;
// Sample thresholds for this divider. Adjust after measuring your room.
const int turnOnBelow = 400;
const int turnOffAbove = 480;
bool lightOn = false;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  const int light = analogRead(sensorPin);
  if (light < turnOnBelow) lightOn = true;
  if (light > turnOffAbove) lightOn = false;
  digitalWrite(ledPin, lightOn ? HIGH : LOW);
  delay(40);
}`,
    },
    {
      id:'parking', en:'Smart Parking Gate', title:'بوابة المواقف', image:'servo',
      brief:'في نموذج طاولة، تفتح البوابة عند اقتراب السيارة وتبقى مفتوحة حتى تبتعد.',
      parts:['Arduino Uno R3','HC-SR04','Servo Motor','مصدر مناسب للسيرفو','Breadboard وأسلاك','مؤشرات LED اختيارية مع مقاومة لكل LED'],
      success:'تفتح عند مسافة من 2 إلى 15 cm ضمن مدى الحساس. تغلق بعد ثانيتين متواصلتين عند 20 cm أو أكثر. غياب الصدى يوقف عدّ زمن الإغلاق.',
      hints:['فكّر في حالتين للبوابة: مفتوحة ومغلقة.','افصل وظيفة Trig عن Echo، وأعطِ إشارة السيرفو منفذًا ثالثًا. غذِّه من مصدر مناسب ووحّد الأرضي.','قِس الزمن بـ millis(). صفّر عدّ فترة الابتعاد عند رجوع الجسم أو ضياع القراءة.'],
      wiring:[['Arduino 5V / GND','HC-SR04 VCC / GND'],['Arduino D6','HC-SR04 Trig'],['HC-SR04 Echo','Arduino D7'],['Arduino D9','Servo Signal'],['مصدر السيرفو + / −','Servo V+ / GND'],['سالب مصدر السيرفو','Arduino GND']],
      test:'اضبط زاويتي السيرفو دون ذراع البوابة أولًا، ثم اختبر الحركة دون ضغط على المحرك. ابدأ بجسم قريب. أبعده لأقل من ثانيتين وأعِده. جرّب فترة ابتعاد أطول وتعطّل الصدى. هذا تمرين لنموذج طاولة.',
      code:`#include <Servo.h>

const byte trigPin = 6;
const byte echoPin = 7;
const byte servoPin = 9;
const int openAngle = 95;
const int closedAngle = 15;
Servo gate;
bool open = false;
bool timingFar = false;
unsigned long farSince = 0;

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  gate.attach(servoPin);
  gate.write(closedAngle);
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  const unsigned long duration = pulseIn(echoPin, HIGH, 26000UL);
  const float cm = duration * 0.0343f / 2;
  const bool valid = duration && cm >= 2 && cm <= 400;
  if (valid && cm <= 15 && !open) {
    gate.write(openAngle);
    open = true;
  }
  if (open && valid && cm >= 20) {
    const unsigned long now = millis();
    if (!timingFar) {
      farSince = now;
      timingFar = true;
    } else if (now - farSince >= 2000UL) {
      gate.write(closedAngle);
      open = false;
      timingFar = false;
    }
  } else {
    timingFar = false;
  }
  delay(65);
}`,
    },
    {
      id:'fan', en:'Automatic Cooling Fan', title:'مروحة تبريد تلقائية', image:'lab-fan',
      brief:'تعمل المروحة عند ارتفاع الحرارة وتتوقف بعد انخفاضها.',
      parts:['Arduino Uno R3','TMP36','مروحة DC بسلكين','Logic-level MOSFET مناسب','330 Ω و10 kΩ','دايود حماية','مصدر مناسب للمروحة','Breadboard وأسلاك'],
      success:'تعمل عندما تقرأ 30 °C أو أعلى، وتتوقف عند قراءة 28 °C أو أقل. بين الحدين تبقى على حالتها السابقة.',
      hints:['قِس الحرارة وحافظ على حالة المروحة بين درجتين.','استخدم Analog Input للحساس وMOSFET مناسبًا لتيار المروحة. وحّد أرضي المصدرين.','حوّل جهد TMP36 باستخدام (V − 0.5) × 100، ثم قارن الحدين حسب حالة المروحة.'],
      wiring:[['Arduino 5V / GND','TMP36 +VS / GND'],['TMP36 VOUT','Arduino A0'],['Arduino D9','330 Ω ثم MOSFET Gate'],['MOSFET Gate','10 kΩ إلى GND'],['مصدر المروحة +','Fan + وCathode الدايود'],['Fan −','MOSFET Drain وAnode الدايود'],['MOSFET Source','مصدر المروحة − وArduino GND']],
      test:'اختبر 27 ← 31 ← 29 ← 27 °C بالترتيب. الحالة المتوقعة إطفاء، تشغيل، تشغيل، إطفاء. تحقّق من ترتيب TMP36، وطابق جهد المصدر مع المروحة. اختر MOSFET يعمل بإشارة 5V ودايود حماية يتحملان تيار المروحة، ووحّد الأرضي.',
      code:`const byte tempPin = A0;
const byte fanPin = 9;
bool fanOn = false;

void setup() {
  pinMode(fanPin, OUTPUT);
  digitalWrite(fanPin, LOW);
}

void loop() {
  unsigned long sum = 0;
  for (byte sample = 0; sample < 16; ++sample) {
    sum += analogRead(tempPin);
    delay(5);
  }
  const float adcReference = 5.0f;  // Use the measured Uno 5V reference if needed.
  const float volts = (sum / 16.0f) * adcReference / 1024.0f;
  const float celsius = (volts - 0.5f) * 100.0f;
  if (celsius >= 30.0f) fanOn = true;
  if (celsius <= 28.0f) fanOn = false;
  digitalWrite(fanPin, fanOn ? HIGH : LOW);
  delay(125);
}`,
    },
  ];
})();
