(() => {
  'use strict';
  const missions = globalThis.MissionData;
  const { format, escape, openPin } = globalThis.Workshop;
  const presentation = globalThis.PresentationData;
  const phases = [
    ['brief','الفكرة'],['components','القطع'],['circuit','شكل الدائرة'],['wiring','التوصيل'],['tinkercad','Tinkercad'],
    ['ask','اطلب الكود'],['test','جرّب الدائرة'],['complete','النتيجة'],
  ];
  const local = () => globalThis.Journey;
  const btn = (key,label,cls='secondary-button',attrs='') =>
    '<button type="button" class="' + cls + '" data-mission-action="' + key + '"' + attrs + '>' + label + '</button>';
  const ref = (href,label,cls='') => '<a href="' + escape(href) + '" target="_blank" rel="noopener noreferrer"' + (cls ? ' class="' + cls + '"' : '') + '>' + label + '</a>';
  const image = (id,alt='') => '<img src="assets/photos/' + id + '.webp" alt="' + escape(alt) + '" loading="lazy">';
  const diagram = mission => '<figure class="mission-diagram"><img src="assets/circuits/' + mission.id +
    '.svg" alt="مخطط توصيل ' + escape(mission.title) + '"><figcaption>مخطط مرجعي لشرح التوصيل</figcaption></figure>';
  const tinkercadUrl = mission => globalThis.StudentLinks.circuit(mission.id);
  function statusLabel(mission) {
    return '<span class="verification">' +
      (tinkercadUrl(mission) ? 'رابط دائرة Tinkercad' : 'مخطط التوصيل والبرنامج المرجعي') + '</span>';
  }

  function phaseContent(mission, phase, state) {
    if (phase === 'brief') return '<h3>المطلوب</h3><p class="mission-lead">' + format(mission.brief) + '</p><p>' + format(mission.focus) + '</p>';
    if (phase === 'components') return '<h3>ماذا نحتاج؟</h3><dl class="terminal-list">' + mission.components.map(part =>
      '<div><dt><bdi>' + escape(part.name) + '</bdi></dt><dd>' + format(part.reason) + '</dd></div>').join('') + '</dl>';
    if (phase === 'circuit') return diagram(mission);
    if (phase === 'wiring') return '<h3>خريطة التوصيل</h3><div class="wiring-table-wrap"><table class="wiring-table"><thead><tr><th>من</th><th>إلى</th><th>السبب</th></tr></thead><tbody>' +
      mission.wiring.map(row => '<tr><td><bdi>' + escape(row.from) + '</bdi></td><td><bdi>' + escape(row.to) + '</bdi></td><td>' + format(row.because) + '</td></tr>').join('') +
      '</tbody></table></div><div class="pin-list">' + mission.pins.map(pin => '<button type="button" data-mission-pin="' + pin + '"><bdi>' + pin + '</bdi></button>').join('') +
      '</div><details class="engineering-detail" data-advanced><summary>احتياطات العتاد والمراجع</summary><ul>' + mission.safety.map(line => '<li>' + format(line) + '</li>').join('') +
      '</ul><ul>' + mission.sources.map(source => '<li>' + ref(source.url,escape(source.label)) + '</li>').join('') + '</ul></details>';
    if (phase === 'tinkercad') {
      const url = tinkercadUrl(mission);
      return '<h3>محاكاة الدائرة</h3><div class="mission-tools">' +
        (url ? ref(url,'افتح دائرة الورشة','primary-button') : '') +
        ref('https://www.tinkercad.com/dashboard/designs/circuits','افتح محرّر الدوائر','secondary-button') +
        '</div>' + (url ? '<p class="fine-print">' + escape(globalThis.StudentLinks.circuitAccess(mission.id)) + '</p>' : '') +
        '<p>يمكنك إعادة بناء المشروع في المحرّر من مخطط الدائرة وجدول التوصيل.</p>';
    }
    if (phase === 'ask') return '<h3>اطلب الكود</h3><p>بعد الحصول على الكود، تأكد أن المنافذ فيه تطابق دائرتك.</p>' +
      '<textarea class="mission-prompt" aria-label="طلب الكود" rows="8" data-mission-prompt>' + escape(mission.prompt) + '</textarea><div class="mission-tools">' +
      btn('copy-prompt','نسخ الطلب','primary-button') + ref('https://chatgpt.com/','فتح ChatGPT','secondary-button') + '</div>';
    if (phase === 'test') return '<h3>اختبر قبل تثبيت الدائرة</h3><ol class="mission-tests">' + mission.tests.map(test =>
      '<li><strong>' + format(test.step) + '</strong><p>' + format(test.expected) + '</p></li>').join('') + '</ol>' +
      '<p>إذا ظهر سلوك مختلف، افحص مصدر التغذية والأرضي، ثم قارن المنافذ الفعلية بتعريفاتها في البرنامج.</p>' +
      (state.showCode ? '<div class="mission-tools">' + btn('copy-code','نسخ البرنامج') + btn('download','تنزيل .ino') + btn('hide-code','إخفاء البرنامج') +
      '</div><pre class="mission-code" dir="ltr"><code>' + escape(mission.code) + '</code></pre>' :
      btn('show-code','اكشف البرنامج المرجعي','secondary-button'));
    return '<h3>ماذا أنجزنا؟</h3><p class="mission-lead">' + format(mission.skill) + '</p><p>قارن سلوك مشروعك بحالات الاختبار، ثم جرّب تغيير شرط أو قيمة واحدة وراقب الأثر.</p>' +
      btn('complete','تمت مراجعة المهمة','primary-button',' aria-pressed="' + String(state.complete.has(mission.id)) + '"');
  }
  function renderMission(state) {
    const mission = missions.find(m => m.id === state.id);
    const index = phases.findIndex(([id]) => id === state.phase);
    state.host.innerHTML = '<div class="mission-layout"><aside class="surface mission-tray"><h2>المهام العملية</h2><div role="group" aria-label="المشاريع الثمانية">' +
      missions.map((m,i) => '<button type="button" data-select-mission="' + m.id + '" aria-pressed="' + String(m.id === mission.id) +
        '"><bdi class="mission-number">' + String(i+1).padStart(2,'0') + '</bdi><span><bdi>' + escape(m.title) + '</bdi>' +
        (state.complete.has(m.id) ? '<small>تمت المراجعة</small>' : '') + '</span></button>').join('') + '</div></aside>' +
      '<article class="surface mission-body"><header class="mission-heading"><div><p class="eyebrow">ENGINEERING MISSION</p><h2><bdi>' +
      escape(mission.title) + '</bdi></h2>' + statusLabel(mission) + '</div>' + image(mission.image,mission.title) +
      '</header><nav class="mission-phases" aria-label="مراحل المهمة">' + phases.map(([id,label]) =>
        '<button type="button" data-mission-phase="' + id + '" aria-pressed="' + String(state.phase === id) + '">' + label + '</button>').join('') +
      '</nav><div class="mission-content">' + phaseContent(mission,state.phase,state) + '</div>' +
      '<footer class="mission-next">' + (index > 0 ? btn('previous','السابق') : '<span></span>') +
      '<output data-mission-result aria-live="polite"></output>' + (index < phases.length - 1 ? btn('next','التالي','primary-button') : '') + '</footer></article></div>';
    presentation.publish({kind:'mission',id:mission.id,phase:state.phase});
  }
  async function clipboard(text) {
    try {
      if (navigator.clipboard) { await navigator.clipboard.writeText(text); return true; }
    } catch { /* File URL browsers differ in clipboard permission. */ }
    const pane = document.createElement('textarea');
    pane.className = 'copy-helper';
    pane.value = text;
    document.body.append(pane);
    pane.select();
    let worked = false;
    try { worked = document.execCommand('copy'); } catch { /* Keep native selection available. */ }
    pane.remove();
    return worked;
  }
  function downloadSketch(id,code) {
    const url = URL.createObjectURL(new Blob([code + '\n'],{type:'text/plain'}));
    const link = document.createElement('a');
    link.href = url;
    link.download = id + '.ino';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url),800);
  }
  function mountMissions(host,detail = '') {
    const mission = missions.find(item => item.id === detail) || missions[0];
    const state = { host,id:mission.id,phase:'brief',showCode:false,complete:new Set(local().read('reviewed-missions',[])),
    };
    renderMission(state);
    host.addEventListener('click',async event => {
      const target = event.target.closest('button');
      if (!target) return;
      const id = target.dataset.selectMission;
      const phase = target.dataset.missionPhase;
      if (id || phase) {
        if (id) { state.id = id; state.phase = 'brief'; }
        if (phase) state.phase = phase;
        state.showCode = false;
        renderMission(state);
        host.querySelector(id ? '[data-select-mission="' + id + '"]' : '[data-mission-phase="' + phase + '"]')?.focus({preventScroll:true});
        return;
      }
      if (target.dataset.missionPin) { openPin(target.dataset.missionPin); return; }
      const key = target.dataset.missionAction;
      const current = missions.find(item => item.id === state.id);
      if (key === 'copy-prompt' || key === 'copy-code') {
        const prompt = host.querySelector('[data-mission-prompt]');
        const worked = await clipboard(key === 'copy-code' ? current.code : prompt?.value ?? current.prompt);
        if (worked) target.focus({preventScroll:true});
        else prompt?.select();
        host.querySelector('[data-mission-result]').textContent = worked ? 'نُسخ إلى الحافظة.' :
          'حدّد النص ثم اضغط Ctrl+C.';
        return;
      }
      if (key === 'download') {
        downloadSketch(current.id,current.code);
        return;
      }
      if (key === 'next' || key === 'previous') {
        const sequence = phases;
        const i = sequence.findIndex(([id]) => id === state.phase) + (key === 'next' ? 1 : -1);
        state.phase = sequence[i][0];
        state.showCode = false;
      } else if (key === 'show-code' || key === 'hide-code') state.showCode = key === 'show-code';
      else if (key === 'complete') {
        state.complete.add(state.id);
        local().write('reviewed-missions',[...state.complete]);
      } else return;
      renderMission(state);
      host.querySelector('[data-mission-phase="' + state.phase + '"]')?.focus({preventScroll:true});
    });
  }

  globalThis.JourneyMissions = {mountMissions,tinkercadUrl,clipboard,downloadSketch};
})();
