# اعتمادات المواد المرئية

أُعد هذا الموقع كمرجع تعليمي مستقل للورشة. وردت أسماء Arduino وTinkercad وغيرها للدلالة على المنتجات والخدمات المستخدمة في الدروس.

| الملف | النسبة | الترخيص | التعديل |
| --- | --- | --- | --- |
| `assets/photos/breadboard-rails.webp` | [SparkFun Learn](https://learn.sparkfun.com/tutorials/how-to-use-a-breadboard/all) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) | Existing resized WebP |
| `assets/photos/breadboard-strip.webp` | [SparkFun Learn](https://learn.sparkfun.com/tutorials/how-to-use-a-breadboard/all) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) | Existing resized WebP |
| `assets/photos/breadboard-top.webp` | [Evan-Amos](https://commons.wikimedia.org/wiki/File:Electronics-White-Breadboard.jpg) | [Public domain](https://commons.wikimedia.org/wiki/Template:PD-self) | Resized to WebP, metadata removed |
| `assets/photos/lab-diode-stripe.webp` | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Diode_1N4007.jpg) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) | Existing resized WebP |
| `assets/photos/lab-ldr-surface.webp` | [Nevit Dilmen](https://commons.wikimedia.org/wiki/File:LDR_1480405_6_7_HDR_Enhancer_1.jpg) | [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) | Existing resized WebP |
| `assets/photos/lab-pp3.webp` | [Ashley Pomeroy](https://commons.wikimedia.org/wiki/File:Duracell_9_Volt_0849.jpg) | [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/) | Existing resized WebP |
| `assets/photos/lab-resistor-bands.webp` | [oomlout](https://commons.wikimedia.org/wiki/File:220_ohms_5%25_axial_resistor.jpg) | [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/) | Resized to WebP, metadata removed |
| `assets/photos/lab-servo-wires.webp` | [Luiz Augusto Souza de Mesquita](https://commons.wikimedia.org/wiki/File:Micro_Servo_Motor_TowerPro_SG90_e_Acess%C3%B3rios.png) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) | Resized to WebP, metadata removed |
| `assets/photos/lab-ultrasonic-main.webp` | [SparkFun](https://commons.wikimedia.org/wiki/File:SparkFun_HC-SR04_Ultrasonic-Sensor_13959-01a.jpg) | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/) | Resized to WebP, metadata removed |
| `assets/photos/resistor.webp` | [oomlout](https://commons.wikimedia.org/wiki/File:220_ohms_5%25_axial_resistor.jpg) | [CC BY-SA 2.0](https://creativecommons.org/licenses/by-sa/2.0/) | Resized to WebP, metadata removed |
| `assets/photos/servo.webp` | [Luiz Augusto Souza de Mesquita](https://commons.wikimedia.org/wiki/File:Micro_Servo_Motor_TowerPro_SG90_e_Acess%C3%B3rios.png) | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) | Resized to WebP, metadata removed |
| `assets/photos/ultrasonic.webp` | [SparkFun](https://commons.wikimedia.org/wiki/File:SparkFun_HC-SR04_Ultrasonic-Sensor_13959-01a.jpg) | [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/) | Resized to WebP, metadata removed |
| `assets/uno-r3.jpg` | [MakeMagazinDE](https://commons.wikimedia.org/wiki/File:Arduino_uno_r3.jpg) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) | Resized, JPEG and stripped metadata |
| `assets/uno-r3-pinout.pdf` | [Arduino](https://docs.arduino.cc/hardware/uno-rev3/) | [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) | نسخة من مستند منافذ Uno R3 |

تجد نص ترخيص الخط المحلي في `assets/noto-sans-arabic-OFL.txt`.

الأشكال التعليمية ومخططات التوصيل المعدّة للورشة تبقى ضمن الموقع. تستخدم خريطة Uno R3 مواضع المنافذ من مرجع Arduino. صور المورّدين التي لم يثبت حق توزيعها ترتبط بصفحاتها من المكتبة، وتظهر في مكانها رسوم تعليمية تعمل محليًا.

[مرجع منافذ Uno R3 الرسمي](https://docs.arduino.cc/static/c57a658e0f7afad334f6f73e82dfd83d/A000066-full-pinout.pdf)
