(() => {
  'use strict';
  const missions = globalThis.MissionData;
  const { format, escape, openPin } = globalThis.Workshop;
  const presentation = globalThis.PresentationData;
  const phases = [
    ['brief','الفكرة'],['components','القطع'],['circuit','شكل الدائرة'],['wiring','التوصيل'],['tinkercad','Tinkercad'],
    ['ask','اطلب الكود'],['test','جرّب الدائرة'],['complete','النتيجة'],
  ];
  const challenges = [
    {id:'lighting',title:'إنارة تلقائية',en:'SMART LIGHTING',image:'ldr',brief:'شغّل LED عند الظلام وأطفئها عند عودة الضوء.',
      parts:'Arduino Uno R3، حساس ضوء LDR، مقاومة 10 kΩ، LED ومقاومة 220 Ω، Breadboard وأسلاك.',
      constraints:'قِس القراءة في الضوء وفي الظلام. اختر قيمة بين القراءتين تبدأ عندها الإضاءة.',
      fields:[['مدخل الحساس',['D2','A0','VIN'],'A0'],['مخرج المصباح',['D9','5V','AREF'],'D9']],
      model:'صل [5V] إلى [LDR]. صل طرفه الآخر إلى [A0] وإلى مقاومة [10 kΩ] ترجع إلى [GND]. صل [D9] إلى [Anode] في [LED] عبر [220 Ω]، و[Cathode] إلى الأرضي. شغّل اللمبة عندما تقل قراءة [A0] عن القيمة التي اخترتها.',
      test:'غطّ الحساس فتضيء LED. ارفع يدك فتطفأ. جرّب قرب حد التشغيل. يمكن اختيار قيمتين مختلفتين للتشغيل والإطفاء حتى لا تومض اللمبة قرب الحد.'},
    {id:'parking',title:'بوابة موقف',en:'SMART PARKING GATE',image:'servo',brief:'افتح البوابة عند اقتراب السيارة وأغلقها بعد ابتعادها.',
      parts:'Arduino Uno R3، حساس المسافة HC-SR04، Servo، ولمبتا LED مع مقاومة لكل لمبة (اختياري).',
      constraints:'افتح عند مسافة 15 cm أو أقل. أغلق بعد بقاء السيارة على مسافة 20 cm أو أكثر لمدة ثانيتين متواصلتين.',
      fields:[['إرسال Trig',['D6','D7','D9'],'D6'],['استقبال Echo',['D6','D7','D9'],'D7'],['إشارة السيرفو',['D6','D9','3.3V'],'D9']],
      model:'صل [D6] إلى [Trig] لبدء القياس. يرجع [Echo] إلى [D7] لقراءة الصدى. يصل [D9] إلى إشارة السيرفو. غذّ السيرفو من مصدر مناسب واربط الأرضي بـ[GND] على Arduino. يمكن إضافة لمبتين على [D4] و[D5] بمقاومة لكل لمبة.',
      test:'جرّب جسمًا قريبًا فتفتح البوابة. أبقِ الجسم قريبًا فتظل مفتوحة. أبعده ثانيتين فتغلق. عند غياب الصدى، أبقِ البوابة مفتوحة حتى تحصل على قراءة صالحة.'},
    {id:'fan',title:'مروحة تبريد تلقائية',en:'AUTOMATIC COOLING FAN',image:'temp',brief:'شغّل المروحة عندما ترتفع الحرارة، وأوقفها بعد أن يبرد المكان.',
      parts:'Arduino Uno R3، حساس الحرارة TMP36، مروحة DC، MOSFET أو Motor Driver، ودايود حماية حسب التوصيل.',
      constraints:'شغّل المروحة عند 30°C أو أكثر وأطفئها عند 28°C أو أقل. بين الدرجتين تظل على حالتها.',
      fields:[['خرج حساس الحرارة',['A0','D9','5V'],'A0'],['إشارة الدرايفر',['D2','D9','AREF'],'D9'],['تغذية المحرك',['مخرج Arduino','مصدر مناسب عبر درايفر','خرج 3.3V'],'مصدر مناسب عبر درايفر']],
      model:'خرج [TMP36] إلى [A0] لقياس الحرارة. يرسل [D9] إشارة التحكم للمفتاح أو [Motor Driver]. غذّ المروحة من مصدرها واربط الأرضي بـ[GND] على Arduino. مع مفتاح [MOSFET] جهة الأرضي، ضع طرف الدايود المخطّط على موجب المروحة والطرف الآخر على سالبها.',
      test:'اختبر [27 → 31 → 29 → 27°C]: إطفاء، تشغيل، استمرار تشغيل، إطفاء.'},
  ];
  const local = () => globalThis.Journey;
  const btn = (key,label,cls='secondary-button',attrs='') =>
    '<button type="button" class="' + cls + '" data-mission-action="' + key + '"' + attrs + '>' + label + '</button>';
  const ref = (href,label,cls='') => '<a href="' + escape(href) + '" target="_blank" rel="noopener noreferrer"' + (cls ? ' class="' + cls + '"' : '') + '>' + label + '</a>';
  const image = (id,alt='') => '<img src="assets/photos/' + id + '.webp" alt="' + escape(alt) + '" loading="lazy">';
  const diagram = mission => '<figure class="mission-diagram"><img src="assets/circuits/' + mission.id +
    '.svg" alt="مخطط توصيل ' + escape(mission.title) + '"><figcaption>مخطط مرجعي لشرح التوصيل</figcaption></figure>';
  const tinkercadUrl = mission => globalThis.StudentLinks.circuit(mission.id);
  function statusLabel(mission) {
    return '<span class="verification" data-verified="false">' +
      escape(tinkercadUrl(mission) ? 'رابط دائرة Tinkercad' : mission.statusLabel) + '</span>';
  }

  function phaseContent(mission, phase, state) {
    if (phase === 'brief') return '<h3>المطلوب</h3><p class="mission-lead">' + format(mission.brief) + '</p><p>' + format(mission.focus) + '</p>';
    if (phase === 'components') return '<h3>ماذا نحتاج؟</h3><dl class="terminal-list">' + mission.components.map(part =>
      '<div><dt><bdi>' + escape(part.name) + '</bdi></dt><dd>' + format(part.reason) + '</dd></div>').join('') + '</dl>';
    if (phase === 'circuit') return diagram(mission);
    if (phase === 'wiring') return '<h3>خريطة التوصيل</h3><div class="wiring-table-wrap"><table class="wiring-table"><thead><tr><th>من</th><th>إلى</th><th>السبب</th></tr></thead><tbody>' +
      mission.wiring.map(row => '<tr><td><bdi>' + escape(row.from) + '</bdi></td><td><bdi>' + escape(row.to) + '</bdi></td><td>' + format(row.because) + '</td></tr>').join('') +
      '</tbody></table></div><div class="pin-list">' + mission.pins.map(pin => '<button type="button" data-mission-pin="' + pin + '"><bdi>' + pin + '</bdi></button>').join('') +
      '</div><details class="engineering-detail" data-advanced><summary>احتياطات العتاد والمراجع</summary><ul>' + mission.safety.map(line => '<li>' + format(line) + '</li>').join('') +
      '</ul><ul>' + mission.sources.map(source => '<li>' + ref(source.url,escape(source.label)) + '</li>').join('') + '</ul></details>';
    if (phase === 'tinkercad') {
      const url = tinkercadUrl(mission);
      return '<h3>افتح دائرة المهمة</h3>' + (url ? ref(url,'فتح الدائرة في Tinkercad','primary-button') :
        '<p>افتح محرر الدوائر وابنها من جدول التوصيل.</p>') +
        '<div class="mission-tools">' + ref('https://www.tinkercad.com/dashboard/designs/circuits','لوحة دوائر Tinkercad','secondary-button') +
        '</div><p class="fine-print">' + escape(globalThis.StudentLinks.circuitAccess(mission.id)) + '</p>';
    }
    if (phase === 'ask') return '<h3>اطلب الكود</h3><p>بعد الحصول على الكود، تأكد أن المنافذ فيه تطابق دائرتك.</p>' +
      '<textarea class="mission-prompt" aria-label="طلب الكود" rows="8" data-mission-prompt>' + escape(mission.prompt) + '</textarea><div class="mission-tools">' +
      btn('copy-prompt','نسخ الطلب','primary-button') + ref('https://chatgpt.com/','فتح ChatGPT','secondary-button') + '</div>';
    if (phase === 'test') return '<h3>اختبر قبل تثبيت الدائرة</h3><ol class="mission-tests">' + mission.tests.map(test =>
      '<li><strong>' + format(test.step) + '</strong><p>' + format(test.expected) + '</p></li>').join('') + '</ol>' +
      '<p>إذا ظهر سلوك مختلف، افحص مصدر التغذية والأرضي، ثم قارن المنافذ الفعلية بتعريفاتها في البرنامج.</p>' +
      (state.showCode ? '<div class="mission-tools">' + btn('copy-code','نسخ البرنامج') + btn('download','تنزيل .ino') + btn('hide-code','إخفاء البرنامج') +
      '</div><pre class="mission-code" dir="ltr"><code>' + escape(mission.code) + '</code></pre>' :
      btn('show-code','اكشف البرنامج المرجعي','secondary-button'));
    return '<h3>ماذا أنجزنا؟</h3><p class="mission-lead">' + format(mission.skill) + '</p><p>قارن سلوك مشروعك بحالات الاختبار، ثم جرّب تغيير شرط أو قيمة واحدة وراقب الأثر.</p>' +
      btn('complete','تمت مراجعة المهمة','primary-button',' aria-pressed="' + String(state.complete.has(mission.id)) + '"');
  }
  function renderMission(state) {
    const mission = missions.find(m => m.id === state.id);
    const index = phases.findIndex(([id]) => id === state.phase);
    state.host.innerHTML = '<div class="mission-layout"><aside class="surface mission-tray"><h2>المهام العملية</h2><div role="group" aria-label="المشاريع الثمانية">' +
      missions.map((m,i) => '<button type="button" data-select-mission="' + m.id + '" aria-pressed="' + String(m.id === mission.id) +
        '"><bdi class="mission-number">' + String(i+1).padStart(2,'0') + '</bdi><span><bdi>' + escape(m.title) + '</bdi>' +
        (state.complete.has(m.id) ? '<small>تمت المراجعة</small>' : '') + '</span></button>').join('') + '</div></aside>' +
      '<article class="surface mission-body"><header class="mission-heading"><div><p class="eyebrow">ENGINEERING MISSION</p><h2><bdi>' +
      escape(mission.title) + '</bdi></h2>' + statusLabel(mission) + '</div>' + image(mission.image,mission.title) +
      '</header><nav class="mission-phases" aria-label="مراحل المهمة">' + phases.map(([id,label]) =>
        '<button type="button" data-mission-phase="' + id + '" aria-pressed="' + String(state.phase === id) + '">' + label + '</button>').join('') +
      '</nav><div class="mission-content">' + phaseContent(mission,state.phase,state) + '</div>' +
      '<footer class="mission-next">' + (index > 0 ? btn('previous','السابق') : '<span></span>') +
      '<output data-mission-result aria-live="polite"></output>' + (index < phases.length - 1 ? btn('next','التالي','primary-button') : '') + '</footer></article></div>';
    presentation.publish({kind:'mission',id:mission.id,phase:state.phase});
  }
  async function clipboard(text) {
    try {
      if (navigator.clipboard) { await navigator.clipboard.writeText(text); return true; }
    } catch { /* File URL browsers differ in clipboard permission. */ }
    const pane = document.createElement('textarea');
    pane.className = 'copy-helper';
    pane.value = text;
    document.body.append(pane);
    pane.select();
    let worked = false;
    try { worked = document.execCommand('copy'); } catch { /* Keep native selection available. */ }
    pane.remove();
    return worked;
  }
  function mountMissions(host,detail = '') {
    const mission = missions.find(item => item.id === detail) || missions[0];
    const state = { host,id:mission.id,phase:'brief',showCode:false,complete:new Set(local().read('reviewed-missions',[])),
    };
    renderMission(state);
    host.addEventListener('click',async event => {
      const target = event.target.closest('button');
      if (!target) return;
      const id = target.dataset.selectMission;
      const phase = target.dataset.missionPhase;
      if (id || phase) {
        if (id) { state.id = id; state.phase = 'brief'; }
        if (phase) state.phase = phase;
        state.showCode = false;
        renderMission(state);
        host.querySelector(id ? '[data-select-mission="' + id + '"]' : '[data-mission-phase="' + phase + '"]')?.focus({preventScroll:true});
        return;
      }
      if (target.dataset.missionPin) { openPin(target.dataset.missionPin); return; }
      const key = target.dataset.missionAction;
      const current = missions.find(item => item.id === state.id);
      if (key === 'copy-prompt' || key === 'copy-code') {
        const prompt = host.querySelector('[data-mission-prompt]');
        const worked = await clipboard(key === 'copy-code' ? current.code : prompt?.value ?? current.prompt);
        if (worked) target.focus({preventScroll:true});
        else prompt?.select();
        host.querySelector('[data-mission-result]').textContent = worked ? 'نُسخ إلى الحافظة.' :
          'حدّد النص ثم اضغط Ctrl+C.';
        return;
      }
      if (key === 'download') {
        downloadSketch(current.id,current.code);
        return;
      }
      if (key === 'next' || key === 'previous') {
        const sequence = phases;
        const i = sequence.findIndex(([id]) => id === state.phase) + (key === 'next' ? 1 : -1);
        state.phase = sequence[i][0];
        state.showCode = false;
      } else if (key === 'show-code' || key === 'hide-code') state.showCode = key === 'show-code';
      else if (key === 'complete') {
        state.complete.add(state.id);
        local().write('reviewed-missions',[...state.complete]);
      } else return;
      renderMission(state);
      host.querySelector('[data-mission-phase="' + state.phase + '"]')?.focus({preventScroll:true});
    });
  }

  function downloadSketch(id,code) {
    const url = URL.createObjectURL(new Blob([code + '\n'],{type:'text/plain'}));
    const link = document.createElement('a');
    link.href = url;
    link.download = id + '.ino';
    link.click();
    setTimeout(() => URL.revokeObjectURL(url),800);
  }

  function renderChallenge(state) {
    const { host,selected,votes,reveal,showVotes } = state;
    if (selected) {
      const item = challenges.find(challenge => challenge.id === selected);
      host.innerHTML = '<article class="surface challenge-feature"><header><div><p class="eyebrow"><bdi>' + item.en +
        '</bdi></p><h2>' + item.title + '</h2><p class="mission-lead">' + item.brief + '</p></div>' + image(item.image,item.title) +
        '</header><div class="challenge-brief"><h3>القطع</h3><p>' + item.parts + '</p><h3>شروط التصميم</h3><p>' + item.constraints +
        '</p><p>ارسم الدائرة في Tinkercad. حدّد مصدر التغذية والمنافذ، ثم اختبرها.</p></div>' +
        '<div class="mission-tools">' + ref('https://www.tinkercad.com/dashboard/designs/circuits','فتح Tinkercad','secondary-button') +
        btn('challenge-back','العودة إلى التحديات') + btn('challenge-reveal',reveal ? 'إخفاء الحل' : 'كشف الحل · Reveal Solution','primary-button',
          ' aria-expanded="' + reveal + '"') + '</div>' +
        (reveal ? '<section class="challenge-reveal"><h3>الحل النموذجي وحالات الاختبار</h3><p>' + format(item.model) + '</p><p>' + format(item.test) +
          '</p><form data-challenge-practice><h3>راجع منافذك</h3>' + item.fields.map(([label,options]) => '<label>' + label + '<select required><option value="">اختر</option>' +
            options.map(value => '<option value="' + escape(value) + '">' + escape(value) + '</option>').join('') + '</select></label>').join('') +
          '<button class="secondary-button">تحقّق من الاختيارات</button><output role="status"></output></form></section>' : '') + '</article>';
      return;
    }
    host.innerHTML = '<div class="challenge-grid journey-challenges">' + challenges.map(item =>
      '<article class="surface challenge-choice">' + image(item.image,item.title) + '<p class="eyebrow"><bdi>' + item.en + '</bdi></p><h2>' +
      item.title + '</h2><p>' + item.brief + '</p>' + btn('choose-challenge','عرض المتطلبات','secondary-button',' data-challenge-id="' + item.id + '"') +
      (showVotes ? '<div class="vote-row"><button type="button" data-vote="' + item.id + '" data-delta="-1" aria-label="إنقاص صوت">−</button>' +
        '<label>الأصوات<input type="number" min="0" max="9999" value="' + votes[item.id] + '" data-vote-value="' + item.id + '"></label>' +
        '<button type="button" data-vote="' + item.id + '" data-delta="1" aria-label="إضافة صوت">+</button></div>' : '') + '</article>').join('') +
      '</div><div class="vote-toolbar"><span>التصويت محلي. يسجّل المقدم الأصوات التي يجمعها من القاعة.</span>' +
      btn('vote-ui',showVotes ? 'إخفاء التصويت' : 'سجّل التصويت','secondary-button',' aria-expanded="' + showVotes + '"') +
      (showVotes ? btn('winner','اعرض الأعلى تصويتًا','primary-button') + '<output role="status" data-vote-result></output>' : '') + '</div>';
  }
  function mountChallenges(host) {
    const state = {host,selected:'',reveal:false,showVotes:false,votes:{lighting:0,parking:0,fan:0,...local().read('votes',{})}};
    const updateVote = (id,value) => {
      state.votes[id] = Math.max(0,Math.min(9999,Math.trunc(value) || 0));
      local().write('votes',state.votes);
    };
    host.addEventListener('change',event => {
      const id = event.target.dataset.voteValue;
      if (id) { updateVote(id,Number(event.target.value)); event.target.value = state.votes[id]; }
    });
    host.addEventListener('click',event => {
      const target = event.target.closest('button');
      if (!target) return;
      if (target.dataset.vote) {
        const id = target.dataset.vote;
        updateVote(id,state.votes[id] + Number(target.dataset.delta));
        host.querySelector('[data-vote-value="' + id + '"]').value = state.votes[id];
        return;
      }
      const key = target.dataset.missionAction;
      if (key === 'vote-ui') state.showVotes = !state.showVotes;
      else if (key === 'choose-challenge') { state.selected = target.dataset.challengeId; state.reveal = false; }
      else if (key === 'challenge-back') { state.selected = ''; state.reveal = false; }
      else if (key === 'challenge-reveal') state.reveal = !state.reveal;
      else if (key === 'winner') {
        const rank = Object.entries(state.votes).sort((a,b) => b[1] - a[1]);
        if (!rank[0][1] || rank[0][1] === rank[1][1]) {
          host.querySelector('[data-vote-result]').textContent = rank[0][1] ? 'يوجد تعادل. اختر أيًّا من البطاقات يدويًا.' : 'أدخل الأصوات أولًا.';
          return;
        }
        state.selected = rank[0][0]; state.reveal = false;
      } else return;
      renderChallenge(state);
      const next = host.querySelector(state.selected ? '[data-mission-action="challenge-reveal"]' : '[data-mission-action="vote-ui"]');
      next.focus({preventScroll:true});
    });
    host.addEventListener('submit',event => {
      if (!event.target.matches('[data-challenge-practice]')) return;
      event.preventDefault();
      const item = challenges.find(challenge => challenge.id === state.selected);
      const choices = [...event.target.querySelectorAll('select')];
      const correct = choices.filter((select,n) => select.value === item.fields[n][2]).length;
      event.target.querySelector('output').textContent = correct + ' من ' + choices.length + ' اختيارات صحيحة.';
    });
    renderChallenge(state);
  }

  globalThis.JourneyMissions = { mountMissions,mountChallenges,tinkercadUrl,downloadSketch };
})();
