(() => {
  'use strict';
  const { escape, format } = globalThis.Workshop;
  const presentation = globalThis.PresentationData;
  let activeLab;
  const visits = new Map();
  const primaryDrivers = ['transistor','mosfet','relay'];
  const tabs = [['discover','تعرّف'],['understand','افهم'],['connect','وصّل'],['experiment','جرّب']];
  const picture = (id,alt='') => '<img src="assets/photos/' + escape(id) + '.webp" alt="' + escape(alt) + '" loading="lazy">';
  const text = (copy,cls='') => copy ? '<p' + (cls ? ' class="' + cls + '"' : '') + '>' + format(copy) + '</p>' : '';
  const btn = (cmd,label,pressed) => '<button type="button" class="secondary-button" data-lab-action="' + cmd + '"' +
    (pressed === undefined ? '' : ' aria-pressed="' + pressed + '"') + '>' + label + '</button>';
  const control = (name,label,min,max,value,step=1) => '<label class="lab-range">' + label + '<input type="range" data-lab-control="' +
    name + '" min="' + min + '" max="' + max + '" step="' + step + '" value="' + value + '"></label>';
  const result = (copy = '') => '<output class="experiment-output" data-lab-output aria-live="polite">' + copy + '</output>';
  const model = '<p class="model-label">تجربة توضيحية بقيم تقريبية.</p>';
  const engines = {
    resistor:'مقاومة أكبر، تيار أقل', pot:'المنزلق يغيّر الجهد', analog:'من الجهد إلى قراءة',
    capacitor:'اشحن وفرّغ', relay:'اتصال COM بين NO وNC', latch:'جرّب التثبيت',
    switch:'جرّب فتح المسار وإغلاقه', led:'جرّب القطبية', bjt:'جرّب تيار Base', mosfet:'جرّب إشارة Gate',
    motor:'السرعة والاتجاه', servo:'اختر زاوية الذراع', stepper:'حرّك المحرك خطوة خطوة',
    lcd:'استكشف أرجل LCD', ultrasonic:'من نبضة Trig إلى مسافة', ldr:'حوّل الضوء إلى جهد',
    pir:'التغير الحراري والحركة', ground:'مرجع الإشارة',
  };
  function panel(copy, visual, inputs, initial) {
    return '<div class="experiment"><p>' + format(copy) + '</p>' + visual + '<div class="experiment-controls">' + inputs +
      '</div>' + result(initial) + model + '</div>';
  }
  const led = '<div class="demo-visual"><div class="demo-bulb" data-demo-led aria-hidden="true"></div></div>';
  const knob = '<div class="demo-visual"><div class="demo-knob" data-demo-knob aria-hidden="true"></div></div>';
  const fan = '<div class="demo-visual"><div class="demo-fan" data-demo-fan aria-hidden="true"><i></i><i></i><i></i></div></div>';
  const dial = '<div class="demo-visual"><svg class="dial" viewBox="0 0 240 135" aria-hidden="true"><path d="M34 110A86 86 0 0 1 206 110"/>' +
    '<circle cx="120" cy="110" r="19"/><path class="dial-arm" d="M120 110V40"/><text x="23" y="131">0°</text><text x="109" y="20">90°</text><text x="195" y="131">180°</text></svg></div>';
  const relay = '<div class="demo-visual"><svg class="relay-model" viewBox="0 0 310 148" aria-label="التلامس بين الطرف المشترك وموقعي NO وNC">' +
    '<path d="M30 75h64m108-32h77m-77 64h77"/><circle cx="94" cy="75" r="5"/><circle cx="202" cy="43" r="5"/><circle cx="202" cy="107" r="5"/>' +
    '<path class="relay-arm" d="M94 75h112"/><text x="23" y="104">COM</text><text x="241" y="34">NC</text><text x="241" y="129">NO</text></svg></div>';
  const scope = '<div class="demo-visual"><svg class="rc-scope" viewBox="0 0 320 125" role="img" aria-label="استجابة الجهد في دائرة الشحن والتفريغ"><path class="rc-grid" d="M20 20v85h280m-280-42h280m-224-43v85m56-85v85m56-85v85m56-85v85"/><path class="rc-curve"/><circle class="rc-point" r="6" cx="20" cy="105"/></svg></div>';

  function lcdBody(state) {
    const pinList = globalThis.JourneyLabData.lcdPins;
    const pin = pinList[state.lcd.pin - 1];
    const mapping = globalThis.MissionData.find(m => m.id === 'temperature')?.wiring ?? [];
    const dataTable = mapping.filter(row => /DB[4-7]$/.test(row.from)).map(row => row.from.replace(/ #\d+ DB/,' D') + ' ← ' + row.to).join(' · ');
    const actual = mapping.find(row => row.from.startsWith('LCD #' + pin.number + ' ')) ??
      (pin.number >= 7 && pin.number <= 10 ? mapping.find(row => row.from.includes('DB0–DB3')) : null);
    const rw = state.lcd.read ? 'قراءة' : 'كتابة';
    return '<div class="experiment lcd-explorer"><p>اختر رجلًا على شريط التوصيل، ثم جرّب كيف تؤثر الإشارات على شاشة HD44780.</p>' +
      '<div class="lcd-device"><div class="lcd-pin-bank" role="group" aria-label="أرجل LCD الست عشرة">' +
      pinList.map(entry => '<button type="button" data-lcd-pin="' + entry.number + '" aria-pressed="' + String(pin.number === entry.number) +
        '" aria-label="' + entry.number + ' ' + escape(entry.label) + '"><small>' + entry.number + '</small><bdi>' + escape(entry.label) + '</bdi></button>').join('') +
      '</div><div class="lcd-screen" data-backlight="' + state.lcd.light + '"><div style="opacity:' + (state.lcd.contrast / 100) + '"><span data-lcd-line>' +
      escape(state.lcd.value) + '</span><span data-lcd-second>' + escape(state.lcd.second) + '</span></div></div></div>' +
      '<section class="lcd-pin-info"><h3><bdi>' + escape(pin.label) + ' · ' + pin.number + '</bdi></h3>' + text(pin.summary) + text(pin.wiring) +
      (actual ? '<p class="signal-type">في مهمة الورشة · <bdi>' + escape(actual.to) + '</bdi></p>' : '') + '</section>' +
      '<div class="lcd-controls">' + control('contrast','تباين VO',5,100,state.lcd.contrast) +
      btn('lcd-light',state.lcd.light ? 'أطفئ إضاءة A/K' : 'شغّل إضاءة A/K',state.lcd.light) +
      btn('lcd-register',state.lcd.rs ? 'RS = HIGH · إرسال حرف' : 'RS = LOW · أمر',state.lcd.rs) +
      btn('lcd-rw','R/W · ' + rw,state.lcd.read) + btn('lcd-enable','نبضة E') + '</div>' +
      result(escape(state.lcd.message)) +
      '<details class="engineering-detail" data-advanced><summary>وضع 4-bit وخريطة المشروع</summary><p>نرسل البايت على دفعتين، الأربع الأعلى ثم الأربع الأدنى. تعمل خطوط الشاشة الأربعة ' +
      'مع RS وE، وتبقى D0–D3 فارغة. يُوصل R/W بالأرضي عند الكتابة فقط.</p><p><bdi>' +
      escape(dataTable) + '</bdi></p>' +
      text('اسم [LCD D4] يحدد خط بيانات الشاشة، ورقم [Arduino D5] يحدد الطرف الذي يوصل إليه في المهمة.') + '</details>' + model + '</div>';
  }
  const stageButton = (command,label,disabled=false) =>
    '<button type="button" class="secondary-button" data-lab-audience="' + command + '"' +
    (disabled ? ' disabled' : '') + '>' + label + '</button>';
  const sectionButton = '<button type="button" class="secondary-button" data-deck-action="map">انتقل إلى قسم</button>';
  const selectedGroup = state => globalThis.JourneyLabData.groups.find(group => group.id === state.group);
  const extraDrivers = group => group.items.filter(id => !primaryDrivers.includes(id));
  function groupParts(state,group) {
    if (group.id !== 'drivers') return group.items;
    return state.optionalOpen || extraDrivers(group).includes(state.item) ? [...primaryDrivers,...extraDrivers(group)] : primaryDrivers;
  }
  function browseToolbar(state,group) {
    const ids = groupParts(state,group);
    const index = ids.indexOf(state.item);
    return '<nav class="final-component-nav hotfix-component-nav" aria-label="التنقل بين المكونات">' +
      stageButton('previous-item','القطعة السابقة',index <= 0) + stageButton('next-item','القطعة التالية',index < 0 || index === ids.length-1) +
      stageButton('tray','العودة إلى المجموعة') + stageButton('catalog','صندوق المكونات') + sectionButton +
      (state.audience ? stageButton('reference','Explore Mode') : stageButton('simple','عرض القطعة')) + '</nav>';
  }
  function storeScroll(state) {
    if (state.view === 'tray' && state.audience) {
      state.groupScroll.set(state.group,window.scrollY);
      const optional = state.host.querySelector('.final-optional');
      if (optional) state.optionalOpen = optional.open;
    }
    if (state.view === 'catalog' && state.audience) state.catalogScroll = window.scrollY;
  }
  function scrollToView(state) {
    const top = state.view === 'catalog' ? state.catalogScroll :
      state.view === 'tray' ? state.groupScroll.get(state.group) :
      Math.max(0,state.host.getBoundingClientRect().top + window.scrollY - 8);
    window.scrollTo({top:top ?? 0,left:0,behavior:'instant'});
  }
  function audienceCard(state,host) {
    const {groups,items} = globalThis.JourneyLabData;
    const group = selectedGroup(state);
    if (state.view === 'closed') {
      host.innerHTML = '<div class="hotfix-catalog-nav">' + sectionButton + '</div>' +
        '<section class="show-stage final-box-home"><button type="button" class="final-box-button" data-lab-audience="open">' +
        '<span class="final-box" aria-hidden="true"><i></i><i></i><i></i></span><strong>افتح صندوق المكونات</strong></button></section>';
      presentation.publish(null);
      return;
    }
    if (state.view === 'catalog' || state.view === 'tray') {
      const catalog = state.view === 'catalog';
      const groupCards = groups.map(row => ['group',row.id,row.title,items[row.items[0]].image]);
      const pieceCards = (list) => list.map(id => ['item',id,items[id].title,items[id].image,presentation.component(items[id])[0]]);
      const tile = ([kind,id,label,photo,subtitle]) => '<button type="button" data-lab-' + kind + '="' + id + '">' + picture(photo) +
        '<span><bdi>' + escape(label) + '</bdi>' + (subtitle ? '<small>' + escape(subtitle) + '</small>' : '') + '</span></button>';
      const ids = group.id === 'drivers' ? primaryDrivers : group.items;
      const optional = group.id === 'drivers' ? extraDrivers(group) : [];
      host.innerHTML = '<section class="show-stage final-catalog"><header class="show-heading"><h2 tabindex="-1">' +
        (catalog ? '<bdi>Component Box</bdi>' : escape(group.title)) + '</h2><div class="hotfix-catalog-nav">' +
        (catalog ? stageButton('close','أغلق الصندوق') : stageButton('catalog','صندوق المكونات')) + sectionButton + '</div></header>' +
        '<div class="show-gallery">' + (catalog ? groupCards : pieceCards(ids)).map(tile).join('') + '</div>' +
        (!catalog && optional.length ? '<details class="final-optional"' + (state.optionalOpen ? ' open' : '') +
          '><summary>شرائح ودرايفرات إضافية</summary><div class="show-gallery">' + pieceCards(optional).map(tile).join('') + '</div></details>' : '') + '</section>';
      presentation.publish(null);
      return;
    }
    const item = items[state.item];
    const [arabic,role,use1,use2] = presentation.component(item);
    const { photo,example,terminals } = globalThis.FinalComponents;
    const usage = [use1,use2].filter(Boolean).map(value => '<li>' + format(value) + '</li>').join('');
    const isRelay = ['relay','relay-module'].includes(item.id);
    host.innerHTML = '<section class="show-stage final-component" data-audience-component="' + item.id + '" data-audience-phase="discover">' +
      browseToolbar(state,group) +
      '<div class="final-component-grid">' + photo(item) + '<div class="final-component-copy"><h2 tabindex="-1"><bdi>' + escape(item.title) + '</bdi></h2>' +
      '<p class="final-component-arabic">' + escape(arabic) + '</p><p class="stage-lead">' + format(role) + '</p>' + '<ul class="show-uses">' + usage + '</ul>' +
      terminals(item) + '</div><div class="final-component-wiring">' + (isRelay ? renderExperiment(state,item) : '') + example(item,group.id) +
      '</div></div></section>';
    publishLab(state);
  }
  function publishLab(state) {
    if (state.audience && state.view !== 'focus') return;
    if (state.item === 'lcd' && (state.audience || state.tab === 'experiment')) {
      presentation.publish({kind:'lcd',id:'lcd',phase:state.audience ? 'overview' : 'data',pin:state.audience ? null : state.lcd.pin});
    } else presentation.publish({kind:'lab',id:state.item,phase:state.audience ? 'discover' :
      ({connect:'pins',understand:'discover'}[state.tab] ?? state.tab)});
  }
  function renderExperiment(state,item) {
    const key = item.experiment;
    if (key === 'resistor') return panel(state.audience ? 'غيّر المقاومة وشاهد سطوع اللمبة.' :
      'غيّر المقاومة. مصدر [5 V] وجهد اللمبة الأمامي [2 V] في هذا المثال.',led,control('resistor','المقاومة Ω',220,10000,220,10),'≈ 13.6 mA');
    if (key === 'pot' || key === 'analog') return panel('حرّك المنزلق لتغيير الجهد الذي يصل إلى [A0].',knob,control('pot','موضع المنزلق',0,100,50),'2.50 V · analogRead = 512');
    if (key === 'capacitor') return panel('الجهد يرتفع تدريجيًا في الشحن وينخفض في التفريغ. جرّب بعد توصيل المقاومة.',scope,
      btn('charge','شحن',!state.discharging) + btn('discharge','تفريغ',state.discharging) +
      control('rc',state.audience ? 'مرّر الوقت' : 'الزمن بوحدات ثابت الزمن RC',0,5,0,.05),'0.00 V');
    if (key === 'relay') return panel('المفتاح داخل الـRelay',relay,btn('relay','شغّل الملف',false),'COM ↔ NC');
    if (key === 'latch' || key === 'switch' || key === 'button') return panel(key === 'latch' ?
      'التثبيت يبقي المسار في حالته بعد رفع الإصبع. لا يمكن استنتاج أطراف الزر الأزرق من شكله؛ قِس كل زوج في الحالتين.' :
      'جرّب فتح الاتصال وإغلاقه. في القراءة مع [INPUT_PULLUP] تعني الحالة المنخفضة أن المسار إلى الأرضي مغلق.',
      led,btn('switch',key === 'latch' ? 'اضغط الزر المثبّت' : 'بدّل وضع المفتاح',false),'المسار مفتوح');
    if (key === 'led') return panel('الأنود يستقبل التيار من خلال مقاومة، والكاثود يعود إلى الأرضي.',led,btn('switch','جرّب الاتجاه الأمامي',false),'الاتجاه العكسي في هذا النموذج. المصباح مطفأ.');
    if (key === 'bjt' || key === 'mosfet' || key === 'motor') return panel(
      key === 'bjt' ? 'الإشارة إلى القاعدة عبر مقاومة تفتح المسار إلى الحمل.' :
      key === 'mosfet' ? 'إشارة [Gate] تتحكم في وقت تشغيل المحرك. المحرك يأخذ طاقته من مصدر خارجي.' :
      'يزيد الدرايفر متوسط الجهد عند رفع نسبة تشغيل [PWM]. اعكس الاتجاه بدرايفر مناسب.',
      fan,control('motor','نسبة التشغيل %',0,100,0) + (key === 'motor'?btn('reverse','اعكس الاتجاه',false):''),'0% · متوقف');
    if (key === 'servo') return panel('حرّك خط الإشارة لتختار موضع الذراع. في العتاد الحقيقي ابدأ حول المنتصف وتجنب إجبار الذراع عند الحدود.',dial,
      control('servo','زاوية الذراع',0,180,90),'90°');
    if (key === 'stepper') return panel('تُشغّل الملفات بتسلسل. كل نقرة هنا تمثل خطوة تعليمية.',dial,btn('step-back','خطوة عكسية') + btn('step','خطوة للأمام'),'0 خطوة');
    if (key === 'lcd') return lcdBody(state);
    if (key === 'ultrasonic') return panel('حرّك الجسم. أرسل نبضة [Trig] ثم شاهد ذهاب الموجة وارتدادها قبل حساب المسافة.',
      '<div class="sonar" data-sonar="idle"><span class="sonar-head"><i></i><i></i></span><span class="sonar-pulse"></span><span class="sonar-object"></span></div>' +
      '<ol class="sonar-steps"><li>Trig</li><li>إرسال</li><li>اصطدام</li><li>Echo</li><li>حساب</li></ol>',
      control('distance','موقع الجسم cm',5,120,40) + btn('sonar','أرسل النبضة') + '<label><input type="checkbox" data-lab-control="noecho"> محاكاة غياب الصدى</label>','الجسم على 40 cm');
    if (key === 'ldr') return panel('زيادة الضوء تقلل مقاومة [LDR]. في هذا التوصيل: [5V] ← [LDR] ← [A0] ← [10 kΩ] ← [GND].',led,
      control('ldr','شدة الإضاءة في النموذج',0,100,35),'');
    if (key === 'pir') return panel('يرصد الحساس تغير الأشعة الحرارية عبر مجال الرؤية. قارن مرور شخص ببقائه ساكنًا.',
      '<div class="demo-visual pir-visual"><span class="pir-eye"></span><span class="pir-person"></span></div>',
      btn('pir-move','مرور شخص',false) + btn('pir-still','يبقى ساكنًا',true),'LOW · المشهد مستقر');
    if (key === 'ground' || key === 'battery') return '<div class="experiment"><p>افتح اختبار التغذية لتجربة تغير الجهد أو ربط مرجع الإشارة.</p><a href="#journey/supply" class="primary-button">اختبار مصادر التغذية</a></div>';
    return '<div class="experiment"><h3>راجع قبل التوصيل</h3>' + text(item.project) +
      btn('self-check','اكشف خطوة التحقق',false) + '<div hidden data-self-check>' + text(item.check) + '</div></div>';
  }

  function renderCard(state,host) {
    if (state.audience) { audienceCard(state,host); return; }
    const {groups,items,sourceReferences} = globalThis.JourneyLabData;
    const group = groups.find(group => group.id === state.group);
    const item = items[state.item];
    const credits = {...globalThis.PhotoCredits,...globalThis.JourneyLabCredits};
    const references = (item.references ?? []).map(id => sourceReferences[id]).filter(Boolean);
    const source = credits[item.image];
    const pins = item.terminals?.length ? '<dl class="terminal-list">' + item.terminals.map(([name,meaning]) =>
      '<div><dt><bdi>' + escape(name) + '</bdi></dt><dd>' + format(meaning) + '</dd></div>').join('') + '</dl>' : '';
    const supporting = '<details class="engineering-detail" data-advanced><summary>اعرف أكثر</summary>' +
      text(item.details || item.understand || item.functionText) + text(item.check) + (references.length ? '<ul>' +
      references.map(([label,url]) => '<li><a href="' + escape(url) + '" target="_blank" rel="noopener">' + escape(label) + '</a></li>').join('') + '</ul>' : '') + '</details>';
    const label = state.tab === 'connect' && item.detailImage ? item.detailImage : item.image;
    const credited = credits[label] || source;
    let content;
    if (state.tab === 'discover') content = text(item.functionText,'lab-lead') + (item.output ? text(item.output,'signal-type') : '') + text(item.project);
    if (state.tab === 'understand') content = text(item.understand || item.functionText,'lab-lead') + '<h3>وين نستخدمها؟</h3>' + text(item.project);
    if (state.tab === 'connect') content = globalThis.HotfixPins.details(item) ||
      text(item.wiring) + pins + '<div class="callout"><strong>قبل التوصيل</strong>' + text(item.check) + '</div>';
    if (state.tab === 'experiment') content = '<h3>' + (engines[item.experiment] || 'طبّق الفكرة') + '</h3>' + renderExperiment(state,item);
    host.innerHTML = (state.scene === 'supply' ? '' : browseToolbar(state,group)) + '<div class="lab-groupbar" role="group" aria-label="أقسام صندوق المكونات">' +
      groups.map(entry => '<button type="button" data-lab-group="' + entry.id + '" aria-pressed="' + String(entry.id === group.id) + '">' +
      escape(entry.title) + '</button>').join('') + '</div><div class="lab-layout"><div class="surface parts-tray">' +
      '<h2>' + escape(group.title) + '</h2><p>' + escape(group.short) + '</p><div class="parts-list" role="group" aria-label="اختيار القطعة">' +
      group.items.map(id => '<button type="button" data-lab-item="' + id + '" aria-pressed="' + String(id === item.id) + '">' +
      picture(items[id].image) + '<span><bdi>' + escape(items[id].title) + '</bdi></span></button>').join('') + '</div></div>' +
      '<article class="surface lab-station" data-component="' + escape(item.id) + '"><header class="lab-header"><figure>' +
      picture(label,'صورة ' + item.title) + (credited ? '<figcaption><a href="' + escape(credited.page) +
      '" target="_blank" rel="noopener">الصورة · <bdi>' + escape(credited.source) + '</bdi></a></figcaption>' : '') +
      '</figure><div><p class="eyebrow">COMPONENT LAB</p><h2><bdi>' + escape(item.title) + '</bdi></h2><p>' + escape(item.type) +
      '</p></div></header><div class="lab-tabs" role="group" aria-label="مراحل شرح القطعة">' + tabs.map(([id,title]) =>
      '<button type="button" data-lab-tab="' + id + '" aria-pressed="' + String(id === state.tab) + '">' + title + '</button>').join('') +
      '</div><div class="lab-readout">' + content + supporting + '</div></article></div>';
    if (state.tab === 'experiment') refresh(host,state,item.experiment);
    publishLab(state);
  }

  function refresh(host,state,engine) {
    const value = name => Number(host.querySelector('[data-lab-control="' + name + '"]')?.value);
    const result = copy => {
      const out = host.querySelector('[data-lab-output]');
      if (out) out.textContent = copy;
    };
    const glow = level => host.querySelector('[data-demo-led]')?.style.setProperty('--glow',String(level));
    if (engine === 'resistor') {
      const ohms = value('resistor'), ma = 3000 / ohms;
      result(ohms + ' Ω · ≈ ' + ma.toFixed(1) + ' mA');
      glow(ma / 14);
    }
    if (engine === 'pot' || engine === 'analog') {
      const percent = value('pot');
      const voltage = percent / 20;
      host.querySelector('[data-demo-knob]').style.rotate = (-135 + 270 * percent / 100) + 'deg';
      result(voltage.toFixed(2) + ' V · analogRead = ' + Math.min(1023,Math.floor(voltage / 5 * 1024)));
    }
    if (engine === 'capacitor') {
      const calc = t => state.discharging ? Math.exp(-t) : 1 - Math.exp(-t);
      const t = value('rc');
      const curve = Array.from({length:26},(_,i) => [20 + i * 11.2,105 - 85 * calc(i / 5)]);
      host.querySelector('.rc-curve').setAttribute('d','M' + curve.map(point => point.join(' ')).join(' L'));
      host.querySelector('.rc-point').setAttribute('cx',20 + 56 * t);
      host.querySelector('.rc-point').setAttribute('cy',105 - 85 * calc(t));
      result((5 * calc(t)).toFixed(2) + ' V' + (state.audience ? '' : ' · t = ' + t.toFixed(2) + ' RC'));
    }
    if (engine === 'motor' || engine === 'bjt' || engine === 'mosfet') {
      const duty = value('motor'), visual = host.querySelector('[data-demo-fan]');
      visual.dataset.active = String(duty > 0);
      visual.style.setProperty('--speed',1.85 / (.21 + duty / 100) + 's');
      visual.style.animationDirection = state.reversed ? 'reverse' : 'normal';
      result(duty + '% · ' + (!duty ? 'متوقف' : state.reversed ? 'اتجاه معاكس' : 'أمام'));
    }
    if (engine === 'servo' || engine === 'stepper') {
      const position = engine === 'servo' ? value('servo') : 90 + ((state.steps % 8) * 22.5);
      host.querySelector('.dial-arm').style.rotate = (position - 90) + 'deg';
      result(engine === 'servo' ? position + '°' : state.steps + ' خطوة');
    }
    if (engine === 'ldr') {
      const light = value('ldr'), resistance = 80000 * Math.pow(0.003,light / 100);
      const voltage = 5 * 10000 / (10000 + resistance);
      glow(voltage / 5);
      result((resistance / 1000).toFixed(1) + ' kΩ · ' + voltage.toFixed(2) + ' V · A0 = ' + Math.min(1023,Math.floor(voltage / 5 * 1024)));
    }
    if (engine === 'ultrasonic') {
      const distance = value('distance');
      host.querySelector('.sonar').style.setProperty('--distance',(20 + 72 * distance / 120) + '%');
      result('الجسم على ' + distance + ' cm');
    }
    if (engine === 'lcd') {
      const screen = host.querySelector('.lcd-screen>div');
      if (screen) screen.style.opacity = state.lcd.contrast / 100;
    }
  }

  function sonar(host,state) {
    clearTimeout(state.timer);
    const surface = host.querySelector('.sonar');
    const out = host.querySelector('[data-lab-output]');
    const markers = [...host.querySelectorAll('.sonar-steps li')];
    const distance = Number(host.querySelector('[data-lab-control=distance]').value);
    const noEcho = host.querySelector('[data-lab-control=noecho]').checked;
    const stage = phase => {
      markers.forEach((li,i) => li.classList.toggle('current',i === phase));
      surface.dataset.sonar = ['trigger','send','hit','echo','result'][phase];
      if (phase === 4 || (noEcho && phase === 2)) {
        out.textContent = noEcho ? 'انتهت المهلة دون صدى. استبعد القراءة.' :
          'Echo ≈ ' + Math.round(distance * 2 / .0343) + ' µs · ' + distance + ' cm';
      } else {
        out.textContent = ['Trig · 10 µs','ترسل الوحدة دفعة فوق صوتية','تصل الموجة إلى الجسم','Echo · فترة الذهاب والعودة'][phase];
        state.timer = setTimeout(() => { if (host.isConnected && surface.isConnected) stage(phase + 1); },globalThis.Journey.isReduced() ? 135 : 330);
      }
    };
    stage(0);
  }

  function mount(host,options) {
    const { groups,items } = globalThis.JourneyLabData;
    const detail = items[options.detail];
    const visit = options.scene === 'supply' ? null : visits.get(options.scene);
    const remembered = detail || options.detail === 'box' ? null : visit;
    const preferred = (detail && groups.find(group => group.items.includes(detail.id))) ||
      groups.find(group => group.id === (remembered?.group ?? options.group)) || groups[0];
    const state = {group:preferred.id, item:detail?.id || remembered?.item || preferred.items[0],
      tab:remembered?.tab ?? 'discover', discharging:false, reversed:false, steps:0,
      audience:remembered?.audience ?? (options.scene !== 'supply'),
      view:detail ? 'focus' : (remembered?.view ?? (options.scene === 'components' ? 'closed' : 'tray')),
      groupScroll:visit?.groupScroll ?? new Map(), catalogScroll:visit?.catalogScroll ?? 0,
      optionalOpen:visit?.optionalOpen ?? false, host, scene:options.scene,
      lcd:{pin:1,light:true,powered:true,rs:true,read:false,contrast:80,nibble:0,value:'TEMP 24.0 C',second:'SYSTEM READY',message:'اختر أمرًا أو حرفًا.'}};
    activeLab = state;
    if (options.scene === 'supply' && !options.detail) state.item = 'pp3';
    const render = () => renderCard(state,host);
    async function openBox(button) {
      const box = button.querySelector('.final-box');
      button.disabled = true;
      if (!globalThis.Journey.isReduced() && box) {
        box.classList.add('day2-box-unlatching');
        const animation = box.getAnimations?.({subtree:true}) ?? [];
        await Promise.allSettled(animation.map(item => item.finished));
      }
      if (activeLab !== state || !host.isConnected) return;
      state.view = 'catalog';
      render();
      scrollToView(state);
      host.querySelector('h2[tabindex]')?.focus({preventScroll:true});
    }
    host.addEventListener('input',event => {
      const name = event.target.dataset.labControl;
      if (!name) return;
      if (name === 'contrast') state.lcd.contrast = Number(event.target.value);
      if (name === 'distance' || name === 'noecho') {
        clearTimeout(state.timer);
        host.querySelector('.sonar').dataset.sonar = 'idle';
        host.querySelectorAll('.sonar-steps .current').forEach(node => node.classList.remove('current'));
      }
      refresh(host,state,items[state.item].experiment);
    });
    host.addEventListener('click',event => {
      const button = event.target.closest('button');
      if (!button) return;
      const show = button.dataset.labAudience;
      if (show) {
        clearTimeout(state.timer);
        if (show === 'open') { openBox(button); return; }
        storeScroll(state);
        if (['catalog','tray','close'].includes(show)) {
          state.audience = true;
          state.view = ({catalog:'catalog',tray:'tray',close:'closed'})[show];
        } else if (show === 'reference' || show === 'simple') {
          state.audience = show === 'simple';
          state.view = 'focus';
          state.tab = state.item === 'lcd' ? 'experiment' : 'discover';
        } else {
          const ids = groupParts(state,selectedGroup(state));
          const adjacent = ids[ids.indexOf(state.item) + (show === 'next-item' ? 1 : -1)];
          if (!adjacent) return;
          state.item = adjacent;
          state.tab = 'discover';
        }
        render();
        scrollToView(state);
        const repeat = host.querySelector('[data-lab-audience="' + show + '"]:not(:disabled)');
        (repeat || host.querySelector('h2[tabindex]'))?.focus({preventScroll:true});
        return;
      }
      if (button.dataset.labGroup || button.dataset.labItem || button.dataset.labTab) {
        clearTimeout(state.timer);
        if (state.audience && (button.dataset.labGroup || button.dataset.labItem)) storeScroll(state);
        if (button.dataset.labGroup) {
          state.group = button.dataset.labGroup;
          state.item = groups.find(group => group.id === state.group).items[0];
          state.tab = 'discover';
          state.view = 'tray';
        } else if (button.dataset.labItem) {
          state.item = button.dataset.labItem; state.tab = 'discover';
          state.view = 'focus';
        } else state.tab = button.dataset.labTab;
        render();
        ['lab-group','lab-item','lab-tab'].forEach(attr => {
          const key = button.getAttribute('data-' + attr);
          if (key) host.querySelector('[data-' + attr + '="' + key + '"]')?.focus({preventScroll:true});
        });
        if (state.audience) {
          scrollToView(state);
          host.querySelector('h2[tabindex]')?.focus({preventScroll:true});
        }
        return;
      }
      const engine = items[state.item].experiment;
      const output = host.querySelector('[data-lab-output]');
      const command = button.dataset.labAction;
      if (button.dataset.lcdPin || command?.startsWith('lcd-')) {
        if (button.dataset.lcdPin) state.lcd.pin = Number(button.dataset.lcdPin);
        if (command === 'lcd-light') state.lcd.light = !state.lcd.light;
        if (command === 'lcd-power') state.lcd.powered = !state.lcd.powered;
        if (command === 'lcd-nibble') {
          state.lcd.nibble = state.lcd.nibble % 2 + 1;
          if (state.lcd.nibble === 2) state.lcd.value = 'A';
        }
        if (command === 'lcd-register') state.lcd.rs = !state.lcd.rs;
        if (command === 'lcd-rw') state.lcd.read = !state.lcd.read;
        if (command === 'lcd-enable') {
          if (state.lcd.read) state.lcd.message = 'وضع القراءة: المحاكاة تعرض حالة الشاشة، ويظل النص كما هو.';
          else if (state.lcd.rs) {
            state.lcd.value = (state.lcd.value + ' A').slice(-16);
            state.lcd.message = 'أُرسلت البيانات وثبتت عند هبوط نبضة E.';
          } else { state.lcd.value = ''; state.lcd.second = ''; state.lcd.message = 'نفّذت الشاشة أمر مسح العرض.'; }
        }
        const open = Boolean(host.querySelector('.lcd-explorer details[open]'));
        host.querySelector('.lcd-explorer').outerHTML = lcdBody(state);
        const replacement = host.querySelector(button.dataset.lcdPin ? '[data-lcd-pin="' + state.lcd.pin + '"]' : '[data-lab-action="' + command + '"]');
        if (open) host.querySelector('.lcd-explorer details').open = true;
        publishLab(state);
        replacement?.focus({preventScroll:true});
      } else if (command === 'switch' || command === 'relay') {
        const on = button.getAttribute('aria-pressed') !== 'true';
        button.setAttribute('aria-pressed',String(on));
        if (command === 'relay') {
          host.querySelector('.relay-model').dataset.relayOn = String(on);
          button.textContent = on ? 'أطفئ الملف' : 'شغّل الملف';
          output.textContent = on ? 'COM ↔ NO' : 'COM ↔ NC';
        } else {
          host.querySelector('[data-demo-led]').style.setProperty('--glow',on ? '1' : '0');
          output.textContent = on ? 'المسار موصول · المصباح يضيء' : 'المسار مفتوح · المصباح مطفأ';
        }
      } else if (command === 'charge' || command === 'discharge') {
        state.discharging = command === 'discharge';
        host.querySelector('[data-lab-action=charge]').setAttribute('aria-pressed',String(!state.discharging));
        host.querySelector('[data-lab-action=discharge]').setAttribute('aria-pressed',String(state.discharging));
        refresh(host,state,engine);
      } else if (command === 'reverse' || command === 'step' || command === 'step-back') {
        if (command === 'reverse') { state.reversed = !state.reversed; button.setAttribute('aria-pressed',String(state.reversed)); }
        else state.steps += command === 'step' ? 1 : -1;
        refresh(host,state,engine);
      } else if (command === 'sonar') sonar(host,state);
      else if (command === 'pir-move' || command === 'pir-still') {
        const moves = command === 'pir-move';
        host.querySelector('.pir-visual').dataset.moves = String(moves);
        host.querySelector('[data-lab-action=pir-move]').setAttribute('aria-pressed',String(moves));
        host.querySelector('[data-lab-action=pir-still]').setAttribute('aria-pressed',String(!moves));
        output.textContent = moves ? 'HIGH · تغيّر حراري عبر مجال الرؤية' : 'LOW · بعد انتهاء مدة الخرج في مشهد مستقر';
      } else if (command === 'self-check') {
        const detail = host.querySelector('[data-self-check]');
        detail.hidden = !detail.hidden;
        button.setAttribute('aria-pressed',String(!detail.hidden));
      }
    });
    render();
    if (remembered) requestAnimationFrame(() => {
      if (activeLab === state && host.isConnected) {
        window.scrollTo({top:remembered.pageScroll,left:0,behavior:'instant'});
      }
    });
  }
  document.addEventListener('journey:presenting',event => {
    if (!event.detail || !activeLab?.host.isConnected || activeLab.scene === 'supply' || activeLab.audience) return;
    activeLab.audience = true;
    renderCard(activeLab,activeLab.host);
  });
  globalThis.JourneyLab = {
    mount,
    leave() {
      if (!activeLab?.host.isConnected) return;
      const state = activeLab;
      clearTimeout(state.timer);
      if (state.scene !== 'supply') {
        storeScroll(state);
        const {group,item,tab,audience,view,groupScroll,catalogScroll,optionalOpen} = state;
        visits.set(state.scene,{group,item,tab,audience,view,groupScroll,catalogScroll,optionalOpen,pageScroll:window.scrollY});
      }
      activeLab = null;
    },
    refreshContext() {
      if (activeLab?.host.isConnected) publishLab(activeLab);
    },
  };
})();
