(() => {
  'use strict';
  const { pins, parts, groups, quizzes } = globalThis.BoardData;
  const presentation = globalThis.PresentationData;
  const items = new Map([...pins, ...parts].map(item => [item.id, item]));
  const groupMap = new Map(groups.map(group => [group.id, group]));
  const get = id => document.getElementById(id);
  const escape = value => String(value).replace(/[&<>"']/g, char =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
  const format = value => escape(value).replace(/\[([^\]]+)\]/g, '<bdi class="term" dir="ltr">$1</bdi>');
  const state = {
    mode: 'function', group: 'pwm', item: null,
    zoom: 1, panX: 0, panY: 0, presenting: false,
    quizIndex: 0, picked: new Set(), checked: false, duty: 50, interrupts:0, topicReturn:null,
  };
  const guidedParts = ['mcu','usb','jack','reset-button'];
  let guide = '';
  let guideDetails = false;
  let freeState;
  const viewport = get('board-viewport');
  const frame = viewport.querySelector('.board-frame');
  const board = get('board');
  const inspector = get('inspector');
  const functionBar = get('function-bar');
  const audienceTools = get('audience-board-tools');
  const status = get('board-status');
  const pinName = id => items.get(id).name;
  const activeGroupData = () => {
    const group = groupMap.get(state.group);
    return guide === 'digital' && group?.id === 'digital'
      ? { ...group, ids:group.ids.filter(id => /^D\d+$/.test(id)),
          why:'هذه المقابس من [D0] إلى [D13]. يمكنك ضبطها لقراءة [HIGH/LOW] أو إخراج إحدى الحالتين.' }
      : group;
  };

  const icons = {
    cursor: '<path d="m4 4 5 15 3.2-6.8L19 9 4 4Z"/>',
    stack: '<path d="m3 8 9-5 9 5-9 5-9-5Zm1 5 8 4 8-4m-16 5 8 4 8-4"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.2 9a2.9 2.9 0 1 1 5.4 1.4c-1.4 1.5-2.6 1.6-2.6 3.6m0 3h.01"/>',
    wave: '<path d="M2 14h5V6h5v12h5v-8h5"/>',
    light: '<circle cx="12" cy="9" r="5"/><path d="M9 17h6m-5 4h4m-4-7-.5-1m4.5 1 .5-1"/>',
    chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 3v3m6-3v3m-6 12v3m6-3v3M3 9h3m-3 6h3m12-6h3m-3 6h3"/>',
    check: '<path d="m4 12 5 5L20 6"/>',
  };
  const icon = name => '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round">' + icons[name] + '</svg>';
  const writeStatus = value => { if (status.textContent !== value) status.textContent = value; };
  const labelOf = pin => pin.id.startsWith('GND-') ? 'GND' : pin.id === '3V3' ? '3.3V' : pin.id;
  const groupStatus = group => {
    const n = group.ids.length;
    const count = n === 2 ? 'منفذان مميّزان' : n > 10 ? n + ' منفذًا مميّزًا' : n + ' منافذ مميّزة';
    return count + ' · ' + group.label;
  };

  function drawBoard() {
    get('board-pins').innerHTML = pins.map(pin => {
      const top = pin.y < 300;
      const label = labelOf(pin);
      const tagY = top ? -40 : 40;
      const tagWidth = Math.min(32, Math.max(25, 9 + 6.1 * label.length));
      return '<g class="hotspot pin" data-id="' + pin.id + '" role="button" tabindex="0" focusable="true" aria-pressed="false" aria-label="' +
        escape(pin.name + '، ' + pin.type) + '" transform="translate(' + pin.x + ' ' + pin.y + ')">' +
        '<rect class="pin-hit" x="-15" y="' + (top ? '-51' : '-16') + '" width="30" height="67" rx="3"></rect>' +
        '<circle class="pin-ring" r="10.6"></circle><circle class="pin-core" r="4.2"></circle>' +
        '<path class="pin-trace" d="M0 ' + (top ? '-14V-29' : '14V29') + '"></path>' +
        '<rect class="pin-tag-bg" x="' + (-tagWidth / 2) + '" y="' + (tagY - 10) + '" width="' + tagWidth + '" height="20" rx="5"></rect>' +
        '<text class="pin-tag' + (label.length > 4 ? ' long-tag' : '') + '" y="' + (tagY + 0.1) + '" dominant-baseline="central" text-anchor="middle">' + label + '</text>' +
        '</g>';
    }).join('');
    get('board-parts').innerHTML = parts.map(part => {
      const [x, y, width, height] = part.bounds;
      const badgeX = x + width / 2 - Math.min(12, width * .22);
      const badgeY = y - height / 2 + Math.min(11, height * .25);
      return '<g class="hotspot component" data-id="' + part.id + '" role="button" tabindex="0" focusable="true" aria-pressed="false" aria-label="' + escape(part.name + '، ' + part.type) + '">' +
        '<rect class="part-ring" x="' + (x - width / 2) + '" y="' + (y - height / 2) + '" width="' + width + '" height="' + height + '" rx="7"></rect>' +
        '<circle class="part-spot" cx="' + badgeX + '" cy="' + badgeY + '" r="5.8"></circle></g>';
    }).join('');
    functionBar.innerHTML = groups.map(group => '<button type="button" data-group="' + group.id + '" aria-pressed="false"><bdi>' + escape(group.label) + '</bdi></button>').join('');
    const sections = [
      ['Digital I/O', pins.filter(pin => /^D\d/.test(pin.id))],
      ['Analog Input', pins.filter(pin => /^A[0-5]$/.test(pin.id))],
      ['التغذية والأطراف الأخرى', pins.slice(20)],
      ['أجزاء اللوحة', parts],
    ];
    get('pin-index').innerHTML = sections.map(([label, entries]) =>
      '<div class="index-row"><strong>' + label + '</strong><div class="pin-list">' + entries.map(item =>
        '<button type="button" data-item="' + item.id + '"><bdi>' + escape(item.name) + '</bdi></button>').join('') + '</div></div>').join('');
    const modeLabels = { explore:'cursor', function:'stack', quiz:'help' };
    get('mode-bar').querySelectorAll('button').forEach(button => {
      button.insertAdjacentHTML('afterbegin', icon(modeLabels[button.dataset.mode]));
    });
  }

  function waveform(duty) {
    if (duty <= 0 || duty >= 100) return 'M0 ' + (duty <= 0 ? 40 : 8) + 'H240';
    const pulse = 80 * duty / 100;
    return 'M0 40 ' + [0,80,160].map(start => 'V8H' + (start + pulse) + 'V40H' + (start + 80)).join(' ');
  }

  function pwmGraph() {
    const duty = state.duty;
    return '<div class="pwm-demo"><div class="pwm-graph">' +
      '<div class="pwm-labels"><bdi>HIGH</bdi><bdi>LOW</bdi></div>' +
      '<svg viewBox="0 0 240 48" preserveAspectRatio="none" aria-hidden="true"><path class="guide" d="M0 8H240M0 40H240M40 2v44m40-44v44m40-44v44m40-44v44m40-44v44"/><path class="wave" d="' +
      waveform(duty) + '"/></svg><output for="pwm-duty"><bdi dir="ltr">' + duty + '%</bdi></output></div>' +
      '<label class="pwm-control">نسبة التشغيل<input type="range" id="pwm-duty" min="0" max="100" value="' + duty +
      '"><bdi class="pwm-write">' + Math.round(duty * 255 / 100) + ' / 255</bdi></label></div>';
  }
  const inAudience = () => document.body.classList.contains('presenting');
  function groundPath() {
    return '<div class="return-model"><svg viewBox="0 0 290 93" role="img" aria-label="مسار تيار يعود إلى سالب مصدر التغذية"><path d="M37 35H252V77H129M91 77H37V48"/>' +
      '<path class="loop-switch" d="M91 77h38"/><text x="13" y="28">5 V</text><text x="227" y="27">LED + R</text><text x="14" y="69">GND</text></svg>' +
      '<button type="button" class="secondary-button" data-action="ground-loop" aria-pressed="false">أغلق المسار إلى الأرضي</button><output role="status"></output></div>';
  }
  const topicButton = (id,label) => '<button type="button" class="secondary-button" data-board-topic="' + id + '"><bdi>' + escape(label) + '</bdi></button>';
  const overviewButton = '<button type="button" class="text-button" data-action="audience-overview">نظرة على اللوحة</button>';
  const groundWire = ['GND','both-grounds','أرضي مشترك'];
  const programmingWires = [
    ['MOSI','left','بيانات من المبرمج إلى Arduino'],
    ['MISO','right','بيانات من Arduino إلى المبرمج'],
    ['SCK','left','نبضات التوقيت من المبرمج'],
    ['RESET','left','المبرمج يعيد ضبط المتحكم'],
    ['VCC','power','جهد التغذية حسب إعداد المبرمج'],
    groundWire,
  ];
  const boardDiagrams = {
    spi:['Uno R3','SD Module',[
      ['MOSI · D11','right','يرسل Arduino البيانات إلى القطعة'],
      ['MISO · D12','left','يستقبل Arduino البيانات من القطعة'],
      ['SCK · D13','right','ينظّم توقيت نقل البيانات'],
      ['CS · D10','right','يختار القطعة التي يتواصل معها Arduino'],
      groundWire,
    ]],
    uart:['Uno R3','UART Module',[
      ['D1 / TX — RX','right','من طرف الإرسال في Arduino إلى طرف الاستقبال في القطعة'],
      ['D0 / RX — TX','left','من طرف الإرسال في القطعة إلى طرف الاستقبال في Arduino'],
      groundWire,
    ]],
    i2c:['Uno R3','OLED',[
      ['SDA · A4 / D18','both','البيانات في الاتجاهين'],
      ['SCL · A5 / D19','right','ساعة الاتصال من Arduino في هذا المثال'],
      groundWire,
    ]],
    interrupt:['Uno R3','Rotation Sensor',[
      ['D2 / D3','left','نبضة الحساس تصل إلى المنفذ المختار'],
      groundWire,
    ]],
    'icsp-main':['ATmega328P','Programmer',programmingWires],
    'icsp-usb':['ATmega16U2','Programmer',programmingWires],
    AREF:['Uno R3','Voltage Reference',[
      ['AREF · 3.3 V','left','المرجع الخارجي يحدّد مدى قراءة الجهد'],
      groundWire,
    ]],
    IOREF:['Uno R3','Shield',[
      ['IOREF · 5 V','right','لوحة التوسعة تقرأ جهد الإشارات'],
      groundWire,
    ]],
  };
  function wireDiagram(id) {
    const diagram = boardDiagrams[id];
    if (!diagram) return '';
    const [left, right, wires] = diagram;
    const height = 25 + wires.length * 28;
    const wiresMarkup = wires.map(([label,direction], index) => {
      const y = 32 + index * 28;
      const fromRight = direction === 'left' || direction === 'both';
      const fromLeft = direction === 'right' || direction === 'both';
      return '<g class="diagram-wire" data-direction="' + direction + '"><path d="M126 ' + y + 'H304"/>' +
        (fromLeft ? '<path d="M295 ' + (y-5) + 'L304 ' + y + 'L295 ' + (y+5) + '"/>' : '') +
        (fromRight ? '<path d="M135 ' + (y-5) + 'L126 ' + y + 'L135 ' + (y+5) + '"/>' : '') +
        '<text x="215" y="' + (y-7) + '">' + escape(label) + '</text></g>';
    }).join('');
    return '<figure class="board-link-diagram" data-diagram="' + escape(id) + '"><svg viewBox="0 0 430 ' + height +
      '" role="img" aria-label="رسم يوضح التوصيلات واتجاه الإشارات بين ' + escape(left) + ' و' + escape(right) + '">' +
      '<rect x="5" y="9" width="121" height="' + (height-18) + '" rx="9"/><rect x="304" y="9" width="121" height="' +
      (height-18) + '" rx="9"/><text x="65.5" y="' + (height/2+5) + '">' + escape(left) + '</text><text x="364.5" y="' +
      (height/2+5) + '">' + escape(right) + '</text>' + wiresMarkup + '</svg><figcaption><ul>' +
      wires.filter(([,direction])=>direction !== 'both-grounds').map(([name,,role])=>'<li><bdi>' +
        escape(name.split(' · ')[0]) + '</bdi> ' + escape(role) + '</li>').join('') + '</ul></figcaption></figure>';
  }
  function pinTopics(item) {
    const relevant = groups.filter(group => group.ids.includes(item.id) && !['digital','analog','power','ground'].includes(group.id));
    return relevant.length ? '<div class="audience-topic-buttons" role="group" aria-label="وظائف إضافية">' +
      relevant.map(entry => topicButton(entry.id,entry.label)).join('') + '</div>' : '';
  }
  function practicalExample(entry) {
    return '<dl class="pin-example"><div><dt>الاستخدام</dt><dd>' + format(entry.use) + '</dd></div>' +
      '<div><dt>مثال</dt><dd>' + format(entry.example) + '</dd></div></dl>';
  }
  function topicPicker() {
    const ids = { arduino:[],power:['power','ground'],digital:['digital','pwm','uart','interrupt','spi'],analog:['analog','i2c'] }[guide] ??
      groups.map(group => group.id);
    if (!ids.length) return '';
    return '<details class="audience-board-picker"><summary>اختر وظيفة</summary><div class="pin-list">' +
      ids.map(id => topicButton(id,groupMap.get(id).label)).join('') + '</div></details>';
  }
  function showTopic(entry) {
    const [,lead,labels] = presentation.topics[entry.id];
    let demo = '';
    if (entry.id === 'pwm') demo = '<div class="show-pwm"><div class="show-pwm-led"><div class="demo-bulb" aria-hidden="true" style="--glow:' +
      state.duty / 100 + '"></div></div>' + pwmGraph() + '</div>';
    if (entry.id === 'interrupt') demo = '<div class="interrupt-demo"><svg viewBox="0 0 300 72" aria-hidden="true"><path d="M12 53h88V15h48v38h140"/></svg>' +
      '<button type="button" class="primary-button" data-action="interrupt-pulse">أرسل نبضة</button><output data-interrupt-output aria-live="polite">' +
      (state.interrupts ? state.interrupts + ' حدث' : 'في انتظار إشارة') + '</output></div>';
    if (entry.id === 'ground' && guide === 'power') demo = groundPath();
    return '<div class="audience-board-topic" data-topic="' + entry.id + '"><h2><bdi>' + escape(entry.name) + '</bdi></h2>' +
      '<p class="stage-lead">' + (entry.id === 'pwm' ? escape(lead) : format(entry.why)) + '</p>' +
      (boardDiagrams[entry.id] ? wireDiagram(entry.id) : '<div class="topic-pins"><bdi>' + escape(labels) + '</bdi></div>') +
      demo + practicalExample(entry) +
      (state.topicReturn ? '<button type="button" class="secondary-button" data-action="topic-back">ارجع إلى <bdi>' +
        escape(pinName(state.topicReturn.item)) + '</bdi></button>' : overviewButton) + topicPicker() + '</div>';
  }
  function showPin(item) {
    const ground = guide === 'power' && item.id.startsWith('GND') ? groundPath() : '';
    return '<div class="audience-pin" data-focus-pin="' + item.id + '"><h2><bdi>' + escape(item.name) + '</bdi></h2>' +
      '<p class="pin-role"><bdi>' + escape(item.type) + '</bdi></p><p class="stage-lead">' + format(item.why) + '</p>' +
      wireDiagram(item.id) + ground + practicalExample(item) + pinTopics(item) +
      overviewButton + topicPicker() + '</div>';
  }

  function infoCard(entry, isGroup) {
    const activeGroup = activeGroupData();
    const features = entry.features?.length
      ? '<div class="detail-tags">' + entry.features.map(feature => '<span><bdi>' + escape(feature) + '</bdi></span>').join('') + '</div>' : '';
    const links = isGroup
      ? (state.topicReturn ? '<button class="text-button" data-action="topic-back" type="button">ارجع إلى <bdi>' +
          escape(pinName(state.topicReturn.item)) + '</bdi></button>' : '') +
        '<div class="related"><h3>المنافذ المرتبطة <span>' + entry.ids.length + '</span></h3><div class="pin-list">' +
        entry.ids.map(id => '<button type="button" data-item="' + id + '"><bdi>' + escape(pinName(id)) + '</bdi></button>').join('') + '</div></div>'
      : activeGroup
        ? '<button class="text-button back-to-group" data-action="group-info" type="button">' + icon('stack') + 'شرح مجموعة <bdi>' + escape(activeGroup.label) + '</bdi></button>'
        : '';
    const advanced = '<details class="engineering-detail" data-advanced><summary>اعرف أكثر</summary>' +
      features +
      (entry.caution ? '<div class="callout"><strong>انتبه</strong><p>' + format(entry.caution) + '</p></div>' : '') +
      '<p><a href="assets/uno-r3-pinout.pdf" target="_blank" rel="noopener">مخطط Arduino الرسمي</a></p></details>';
    const ground = guide === 'power' && entry.id.startsWith('GND') ? groundPath() : '';
    return '<div class="inspector-kicker">' + icon(isGroup && entry.id === 'pwm' ? 'wave' : isGroup ? 'stack' : 'chip') +
      (isGroup ? 'مجموعة وظيفية' : entry.kind === 'pin' ? 'منفذ على اللوحة' : 'جزء من اللوحة') + '</div>' +
      '<h2><bdi dir="ltr">' + escape(entry.name) + '</bdi></h2>' +
      '<p class="inspector-type"><bdi>' + escape(entry.type) + '</bdi></p>' +
      '<p class="inspector-copy">' + format(entry.why) + '</p>' + wireDiagram(entry.id) +
      (isGroup && entry.id === 'pwm' ? pwmGraph() : '') + ground + practicalExample(entry) +
      (isGroup ? '' : pinTopics(entry)) + advanced + links;
  }

  function quizCard() {
    const quiz = quizzes[state.quizIndex];
    const correct = quiz.ids.every(id => state.picked.has(id)) && state.picked.size === quiz.ids.length;
    const choices = Array.from(state.picked, id => '<bdi>' + escape(pinName(id)) + '</bdi>').join('، ');
    const feedback = state.checked
      ? '<div class="quiz-feedback ' + (correct ? 'correct' : 'retry') + '" role="status"><strong>' +
        (correct ? 'إجابة صحيحة' : 'راجع المنافذ الملوّنة') + '</strong><p>' + format(quiz.explanation) + '</p><p>' +
        quiz.ids.map(id => '<bdi class="term">' + escape(id) + '</bdi>').join('، ') + '</p></div>' : '';
    return '<div class="inspector-kicker">' + icon('help') + 'اختبر نفسك</div><h2 class="quiz-question">' + format(quiz.title) + '</h2>' +
      '<p class="inspector-copy">اختر المنافذ على اللوحة بالنقر أو من قائمة المنافذ. اضغط المنفذ مرة أخرى للتراجع عن اختياره.</p>' +
      '<div class="quiz-selection"><strong>اختيارك</strong><p>' + (choices || 'لم تختر أي منفذ بعد.') + '</p></div>' + feedback +
      '<div class="quiz-actions">' +
      (state.checked ? '<button class="primary-button" data-action="quiz-next">السؤال التالي</button><button class="secondary-button" data-action="quiz-clear">حاول مرة أخرى</button>'
        : '<button class="primary-button" data-action="quiz-check"' + (!state.picked.size ? ' disabled' : '') + '>تحقّق من الإجابة</button><button class="secondary-button" data-action="quiz-clear"' +
          (!state.picked.size ? ' disabled' : '') + '>مسح</button>') +
      '</div><p class="quiz-progress">السؤال ' + (state.quizIndex + 1) + ' من ' + quizzes.length + '</p>';
  }

  function renderInspector() {
    if (state.mode === 'quiz') {
      inspector.innerHTML = quizCard();
    } else if (state.item) {
      inspector.innerHTML = inAudience() ? showPin(items.get(state.item)) : infoCard(items.get(state.item), false);
    } else if (state.group) {
      inspector.innerHTML = inAudience() ? showTopic(activeGroupData()) : infoCard(activeGroupData(), true);
    } else {
      if (guide) {
        const captions = {
          arduino:['وين يخزّن البرنامج؟','اختر المتحكم الكبير أو موصلًا من الصورة لنعرف وظيفة كل جزء.',guidedParts],
          power:['Power','اختر منفذ تغذية على اللوحة.',['5V','GND-1','3V3']],
          digital:['Digital Input / Output','اختر منفذًا رقميًا.',['D2','D8']],
          analog:['Analog Input','اختر منفذًا لقياس الجهد.',['A0','A4','A5']],
        };
        const [title,copy,ids] = captions[guide];
        inspector.innerHTML = '<div class="inspector-kicker">' + icon('chip') + 'اكتشاف اللوحة</div>' +
          '<h2>' + title + '</h2><p class="inspector-copy">' + copy + '</p><div class="pin-list">' +
          ids.map(id => '<button type="button" data-item="' + id + '"><bdi>' + escape(pinName(id)) + '</bdi></button>').join('') + '</div>' +
          (inAudience() ? topicPicker() : '');
        return;
      }
      inspector.innerHTML = '<div class="inspector-kicker">' + icon('chip') + 'استكشاف اللوحة</div>' +
        '<h2>اختر جزءًا من اللوحة</h2><p class="inspector-copy">اضغط على أحد المقابس لرؤية وظيفته ومثال لتوصيله. تضيء الأجزاء عند المرور عليها.</p>' +
        '<div class="explore-starts"><button type="button" data-item="D3"><bdi>D3</bdi> · <bdi>Digital I/O</bdi></button>' +
        '<button type="button" data-item="A0"><bdi>A0</bdi> · <bdi>Analog Input</bdi></button><button type="button" data-item="mcu"><bdi>ATmega328P</bdi> · المتحكم</button></div>' +
        (inAudience() ? topicPicker() : '');
    }
  }
  function refreshContext() {
    if (!board.getClientRects().length) return;
    const id = state.mode === 'quiz' ? 'quiz' : state.item || state.group;
    presentation.publish(id ? {kind:'board',id,phase:state.item ? 'pin' : 'topic'} : null);
  }

  function render() {
    const active = activeGroupData();
    const answers = state.mode === 'quiz' && state.checked ? quizzes[state.quizIndex].ids : [];
    board.dataset.mode = state.mode;
    audienceTools.hidden = !inAudience() || Boolean(guide);
    get('mode-bar').toggleAttribute('data-audience-hidden',inAudience() && audienceTools.getAttribute('aria-expanded') !== 'true');
    const basicPower = ['5V','3V3','GND-top','GND-1','GND-2'];
    const activeZone = id => {
      if (guide === 'arduino') return guidedParts.includes(id);
      if (guide === 'power') return basicPower.includes(id) || (guideDetails && ['VIN','RESET','IOREF','usb','jack'].includes(id));
      if (guide === 'digital') return /^D\d+$/.test(id) || id === 'led-l';
      if (guide === 'analog') return /^A[0-5]$/.test(id) || (guideDetails && ['SDA','SCL','AREF'].includes(id));
      return true;
    };
    board.querySelectorAll('.hotspot').forEach(zone => {
      const id = zone.dataset.id;
      const visible = activeZone(id);
      zone.toggleAttribute('data-guide-hidden', !visible);
      zone.setAttribute('aria-hidden', String(!visible));
      const hit = active?.ids.includes(id);
      const selected = state.item === id || state.picked.has(id);
      zone.dataset.state = answers.includes(id) ? 'answer' :
        (state.checked && selected ? 'wrong' : selected ? 'selected' : (hit || (!active && guide && guide !== 'arduino')) ? 'active' : active ? 'muted' : 'idle');
      zone.setAttribute('aria-pressed', String(selected || Boolean(hit)));
      zone.setAttribute('tabindex', !visible || (state.mode === 'quiz' && items.get(id).kind === 'part') ? '-1' : '0');
    });
    get('mode-bar').querySelectorAll('button').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.mode === state.mode)));
    functionBar.hidden = guide ? !guideDetails || !['digital','analog'].includes(guide) : state.mode !== 'function';
    functionBar.querySelectorAll('button').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.group === state.group)));
    functionBar.querySelectorAll('button').forEach(button => {
      button.hidden = guide === 'digital' ? !['digital','pwm','uart','spi','interrupt'].includes(button.dataset.group) :
        guide === 'analog' ? !['analog','i2c'].includes(button.dataset.group) : false;
    });
    get('pin-index').querySelectorAll('[data-item]').forEach(button => {
      const id = button.dataset.item;
      button.setAttribute('aria-pressed', String(state.item === id || state.picked.has(id)));
      button.disabled = state.mode === 'quiz' && items.get(id).kind === 'part';
    });
    writeStatus(guide === 'arduino' && !state.item ? 'أربعة أجزاء للتعرّف على اللوحة' : active ? groupStatus(active) :
      state.mode === 'quiz' ? 'حدّد المنافذ التي تجيب عن السؤال.' : state.item ? pinName(state.item) + ' · العنصر المحدد' : 'اختر منفذًا أو جزءًا من الصورة.');
    renderInspector();
    refreshContext();
  }

  function selectItem(id) {
    if (state.mode === 'quiz') {
      if (state.checked || items.get(id).kind !== 'pin') return;
      if (state.picked.has(id)) state.picked.delete(id);
      else state.picked.add(id);
    } else {
      state.item = id;
      state.topicReturn = null;
      if (guide === 'arduino' && items.get(id).bounds) {
        const [x,y] = items.get(id).bounds;
        state.zoom = 1.46;
        state.panX = (.5 - x / 1000) * frame.offsetWidth * state.zoom;
        state.panY = (.5 - y / 750) * frame.offsetHeight * state.zoom;
        updateTransform();
      }
    }
    const cameFromInspector = inspector.contains(document.activeElement);
    render();
    if (cameFromInspector) {
      const heading = inspector.querySelector('h2');
      heading.tabIndex = -1;
      heading.focus({ preventScroll: true });
    }
  }

  function chooseMode(mode) {
    state.mode = mode;
    state.group = mode === 'function' ? state.group || 'pwm' : null;
    state.item = null;
    state.topicReturn = null;
    state.picked.clear();
    state.checked = false;
    render();
  }

  function activateGroup(id) {
    state.mode = 'function';
    state.group = id;
    state.item = null;
    state.picked.clear();
    state.checked = false;
    render();
  }

  get('mode-bar').addEventListener('click', event => {
    const button = event.target.closest('[data-mode]');
    if (button && state.mode !== button.dataset.mode) chooseMode(button.dataset.mode);
  });
  audienceTools.addEventListener('click',() => {
    audienceTools.setAttribute('aria-expanded',String(audienceTools.getAttribute('aria-expanded') !== 'true'));
    render();
  });
  functionBar.addEventListener('click', event => {
    const button = event.target.closest('[data-group]');
    if (button) activateGroup(button.dataset.group);
  });
  get('pin-index').addEventListener('click', event => {
    const button = event.target.closest('[data-item]');
    if (button) selectItem(button.dataset.item);
  });
  inspector.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.dataset.action === 'audience-overview') {
      chooseMode('explore');
      zoom(1);
      return;
    }
    if (button.dataset.boardTopic) {
      state.topicReturn = state.item ? {item:state.item,group:state.group,mode:state.mode} : state.topicReturn;
      guideDetails = Boolean(guide) || guideDetails;
      activateGroup(button.dataset.boardTopic);
      const heading = inspector.querySelector('h2');
      heading.tabIndex = -1;
      heading.focus({preventScroll:true});
      return;
    }
    if (button.dataset.action === 'topic-back' && state.topicReturn) {
      Object.assign(state,state.topicReturn,{topicReturn:null});
      render();
      return;
    }
    if (button.dataset.action === 'interrupt-pulse') {
      state.interrupts += 1;
      inspector.querySelector('[data-interrupt-output]').textContent = state.interrupts + ' حدث';
      const diagram = button.closest('.interrupt-demo');
      diagram.classList.remove('pulse');
      requestAnimationFrame(() => diagram.classList.add('pulse'));
      return;
    }
    if (button.dataset.item) {
      selectItem(button.dataset.item);
      return;
    }
    if (button.dataset.action === 'ground-loop') {
      const connected = button.getAttribute('aria-pressed') !== 'true';
      const model = button.closest('.return-model');
      model.dataset.closed = String(connected);
      button.setAttribute('aria-pressed',String(connected));
      button.textContent = connected ? 'افتح مسار الرجوع' : 'أغلق مسار الرجوع';
      model.querySelector('output').textContent = connected ? 'اكتمل المسار عبر GND.' : 'المسار مفتوح.';
      return;
    }
    if (button.dataset.action === 'group-info') state.item = null;
    if (button.dataset.action === 'quiz-check') state.checked = true;
    if (button.dataset.action === 'quiz-clear' || button.dataset.action === 'quiz-next') {
      state.picked.clear();
      state.checked = false;
    }
    if (button.dataset.action === 'quiz-next') state.quizIndex = (state.quizIndex + 1) % quizzes.length;
    render();
    const target = state.checked ? inspector.querySelector('[data-action="quiz-next"]') : inspector.querySelector('h2');
    target.tabIndex = target.tagName === 'H2' ? -1 : 0;
    target.focus({ preventScroll: true });
  });
  inspector.addEventListener('input', event => {
    if (event.target.id !== 'pwm-duty') return;
    const duty = Number(event.target.value);
    state.duty = duty;
    inspector.querySelector('.show-pwm-led .demo-bulb')?.style.setProperty('--glow',duty / 100);
    inspector.querySelector('.wave').setAttribute('d', waveform(duty));
    inspector.querySelector('.pwm-graph output bdi').textContent = duty + '%';
    inspector.querySelector('.pwm-write').textContent = Math.round(duty * 255 / 100) + ' / 255';
  });

  board.addEventListener('click', event => {
    const zone = event.target.closest('.hotspot');
    if (zone && !zone.hasAttribute('data-guide-hidden')) selectItem(zone.dataset.id);
  });
  board.addEventListener('keydown', event => {
    const zone = event.target.closest('.hotspot');
    if (!zone || (event.key !== 'Enter' && event.key !== ' ')) return;
    event.preventDefault();
    selectItem(zone.dataset.id);
  });
  board.addEventListener('pointerover', event => {
    const zone = event.target.closest('.hotspot');
    if (zone && event.pointerType === 'mouse') {
      status.dataset.preview = 'true';
      writeStatus(pinName(zone.dataset.id) + ' · ' + items.get(zone.dataset.id).type);
    }
  });
  board.addEventListener('pointerout', event => {
    if (!event.target.closest('.hotspot') || event.relatedTarget?.closest?.('.hotspot')) return;
    delete status.dataset.preview;
    const active = activeGroupData();
    writeStatus(active ? groupStatus(active) :
      state.mode === 'quiz' ? 'حدّد المنافذ التي تجيب عن السؤال.' : state.item ? pinName(state.item) + ' · العنصر المحدد' : 'اختر منفذًا أو جزءًا من الصورة.');
  });

  const clamp = (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value));
  function updateTransform() {
    const roomX = Math.max(0, (frame.offsetWidth * state.zoom - viewport.clientWidth) / 2);
    const roomY = Math.max(0, (frame.offsetHeight * state.zoom - viewport.clientHeight) / 2);
    state.panX = clamp(state.panX, -roomX, roomX);
    state.panY = clamp(state.panY, -roomY, roomY);
    frame.style.transform = 'translate(' + state.panX + 'px,' + state.panY + 'px) scale(' + state.zoom + ')';
    viewport.dataset.zoomed = String(state.zoom > 1);
    get('zoom-value').textContent = Math.round(state.zoom * 100) + '%';
    get('zoom-control').querySelector('[data-zoom="out"]').disabled = state.zoom <= 1;
    get('zoom-control').querySelector('[data-zoom="in"]').disabled = state.zoom >= 3.5;
  }

  function zoom(next, pointX, pointY) {
    const previous = state.zoom;
    state.zoom = clamp(next, 1, 3.5);
    if (state.zoom <= 1) {
      state.panX = state.panY = 0;
    } else if (pointX !== undefined) {
      const bounds = viewport.getBoundingClientRect();
      const relativeX = pointX - bounds.left - bounds.width / 2;
      const relativeY = pointY - bounds.top - bounds.height / 2;
      const scale = state.zoom / previous;
      state.panX = relativeX - (relativeX - state.panX) * scale;
      state.panY = relativeY - (relativeY - state.panY) * scale;
    }
    updateTransform();
  }
  get('zoom-control').addEventListener('click', event => {
    const button = event.target.closest('[data-zoom]');
    if (!button) return;
    zoom(button.dataset.zoom === 'reset' ? 1 : state.zoom + (button.dataset.zoom === 'in' ? .25 : -.25));
  });
  viewport.addEventListener('wheel', event => {
    if (!event.ctrlKey) return;
    event.preventDefault();
    zoom(state.zoom + (event.deltaY < 0 ? .15 : -.15), event.clientX, event.clientY);
  }, { passive: false });
  viewport.addEventListener('keydown', event => {
    const offset = { ArrowLeft:[-32,0], ArrowRight:[32,0], ArrowUp:[0,-32], ArrowDown:[0,32] }[event.key];
    if (event.target !== viewport) return;
    if (offset && state.zoom > 1) {
      event.preventDefault();
      state.panX += offset[0];
      state.panY += offset[1];
      updateTransform();
    } else if (['+', '=', '-', '0'].includes(event.key)) {
      event.preventDefault();
      zoom(event.key === '0' ? 1 : state.zoom + (event.key === '-' ? -.25 : .25));
    }
  });

  let drag = null;
  viewport.addEventListener('pointerdown', event => {
    if (state.zoom <= 1 || event.button !== 0 || !event.isPrimary) return;
    drag = { id: event.pointerId, x: event.clientX, y: event.clientY, panX: state.panX, panY: state.panY, moved: false };
  });
  viewport.addEventListener('pointermove', event => {
    if (!drag || event.pointerId !== drag.id) return;
    if (event.buttons === 0 && event.pointerType === 'mouse') { drag = null; return; }
    const x = event.clientX - drag.x;
    const y = event.clientY - drag.y;
    if (!drag.moved && Math.hypot(x, y) < 7) return;
    if (!drag.moved) {
      drag.moved = true;
      viewport.setPointerCapture(event.pointerId);
      viewport.dataset.dragging = 'true';
    }
    state.panX = drag.panX + x;
    state.panY = drag.panY + y;
    updateTransform();
  });
  const stopDrag = () => {
    drag = null;
    delete viewport.dataset.dragging;
  };
  viewport.addEventListener('pointerup', stopDrag);
  viewport.addEventListener('pointercancel', stopDrag);
  viewport.addEventListener('lostpointercapture', stopDrag);
  new ResizeObserver(updateTransform).observe(viewport);

  function setGuidance(stage = '') {
    if (stage === guide) return;
    const wasGuided = Boolean(guide);
    if (!wasGuided) freeState = { mode:state.mode, group:state.group, item:state.item, zoom:state.zoom, panX:state.panX, panY:state.panY, checked:state.checked, picked:new Set(state.picked) };
    guide = stage;
    guideDetails = false;
    board.closest('.workspace').dataset.guided = stage;
    if (guide) {
      chooseMode('explore');
      zoom(1);
    } else if (freeState) {
      Object.assign(state, freeState);
      updateTransform();
      render();
    }
  }
  document.addEventListener('journey:presenting',() => {
    if (board.getClientRects().length) render();
  });
  globalThis.Workshop = { escape, format, icon, setGuidance, refreshContext, toggleGuideDetails() {
    guideDetails = !guideDetails;
    if (!guideDetails) { state.item = null; state.group = null; }
    render();
    return guideDetails;
  }, selectItem, openPin(id) {
    if (!items.has(id)) return;
    if (guide) setGuidance('');
    if (state.mode === 'quiz') chooseMode('explore');
    selectItem(id);
    location.hash = 'explorer';
  } };
  drawBoard();
  render();
  updateTransform();
})();
