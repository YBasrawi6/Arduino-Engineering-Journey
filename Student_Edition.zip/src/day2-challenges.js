(() => {
  'use strict';
  const tasks = globalThis.Day2ChallengeData;
  const { escape } = globalThis.Workshop;
  const { publish } = globalThis.PresentationData;
  const actions = (key,label,css='secondary-button',extra='') =>
    '<button type="button" class="' + css + '" data-challenge-action="' + key + '"' + extra + '>' + label + '</button>';
  const photo = task => '<img src="assets/photos/' + task.image + '.webp" alt="' + task.title + '" decoding="async">';
  const list = rows => '<ul>' + rows.map(item => '<li>' + escape(item) + '</li>').join('') + '</ul>';
  const session = { id:'', minutes:25, seconds:1500, deadline:0, phase:'ready', hint:0, reveal:false, host:null };
  const taskOf = id => tasks.find(task => task.id === id);
  const remaining = () => session.deadline ? Math.max(0,Math.ceil((session.deadline-Date.now())/1000)) : session.seconds;
  function timeText(seconds) {
    return [Math.floor(seconds/60),seconds%60].map(part => String(part).padStart(2,'0')).join(':');
  }
  function clock() {
    return {seconds:remaining(), phase:session.phase, endsAt:session.deadline, id:session.id};
  }
  function context() {
    publish(session.id ? {kind:'challenge',id:session.id,phase:session.reveal ? 'solution' : session.phase,clock:clock()} :
      {kind:'challenge',phase:'vote'});
  }
  function votePanel() {
    const votes = globalThis.Journey.read('votes',{});
    return '<div class="challenge-grid day2-vote">' + tasks.map(task =>
      '<article class="surface challenge-choice">' + photo(task) + '<h2><bdi>' + task.en + '</bdi></h2><p>' + task.brief + '</p>' +
      '<label class="day2-vote-count">الأصوات<input type="number" min="0" max="9999" value="' + Number(votes[task.id] || 0) +
      '" data-challenge-vote="' + task.id + '"></label>' +
      actions('choose','اختيار التحدي','secondary-button',' data-challenge-id="' + task.id + '"') + '</article>').join('') +
      '</div><div class="mission-tools">' + actions('winner','اعرض الأعلى تصويتًا','primary-button') +
      '<output role="status" data-challenge-status></output></div>';
  }
  function wiringDiagram(task) {
    const height = 28 + task.wiring.length*35;
    return '<svg viewBox="0 0 790 ' + height + '" role="img" class="day2-solution-diagram" aria-label="مخطط توصيل ' + task.title + '">' +
      task.wiring.map(([from,to],i) => {
        const y = 36+i*35;
        return '<g><path d="M360 ' + (y-5) + 'h70"/><circle cx="360" cy="' + (y-5) + '" r="4"/><circle cx="430" cy="' +
          (y-5) + '" r="4"/><text x="343" y="' + y + '" text-anchor="end" direction="ltr">' + escape(from) +
          '</text><text x="446" y="' + y + '" text-anchor="start" direction="ltr">' + escape(to) + '</text></g>';
      }).join('') + '</svg>';
  }
  function timer() {
    const running = session.phase === 'running';
    return '<section class="surface day2-timer"><h3>مؤقت التحدي</h3><output data-challenge-time dir="ltr" aria-label="الوقت المتبقي">' +
      timeText(remaining()) + '</output><label>مدة التنفيذ بالدقائق <input type="number" data-challenge-minutes min="1" max="180" value="' +
      session.minutes + '"></label><div>' +
      actions(running ? 'pause' : 'start',running ? 'إيقاف مؤقت' : (session.phase === 'paused' ? 'استئناف' : 'ابدأ الوقت'),'primary-button',
        session.phase === 'ended' ? ' disabled' : '') +
      actions('extend','أضف 5 دقائق') + actions('reset','إعادة ضبط') +
      actions('finish','إنهاء وقت التنفيذ','secondary-button',session.phase === 'ended' ? ' disabled' : '') + '</div></section>';
  }
  function selectedPanel(task) {
    const circuit = globalThis.StudentLinks.circuit(task.id);
    return '<article class="surface challenge-feature"><header><div><h2><bdi>' + task.en + '</bdi></h2><p class="mission-lead">' +
      task.brief + '</p></div>' + photo(task) + '</header><div class="day2-challenge-body"><div>' +
      '<h3>القطع المتاحة</h3>' + list(task.parts) + '<h3>شروط النجاح</h3><p>' + task.success +
      '</p><p>حدّد المدخل والمخرج والمنافذ. ارسم الدائرة، واكتب طلب AI، ثم اختبر المحاكاة وصحّح الأخطاء.</p></div>' + timer() +
      '</div><div class="mission-tools"><a class="secondary-button" href="' + escape(circuit || 'https://www.tinkercad.com/dashboard/designs/circuits') + '" target="_blank" rel="noopener">Tinkercad</a>' +
      actions('back','التصويت') + (session.hint < 3 ? actions('hint','Hint ' + (session.hint+1)) : '') +
      (session.phase === 'ended' ? actions('reveal',session.reveal ? 'اطوِ الحل' : 'Reveal Solution','primary-button',
        ' aria-expanded="' + session.reveal + '"') : '') +
      '<a class="secondary-button" href="#journey/reality/' + task.id + '">From Simulation to Reality</a></div>' +
      (session.hint ? '<details class="engineering-detail" open><summary>Hint ' + session.hint + '</summary><p>' +
        task.hints[session.hint-1] + '</p></details>' : '') +
      (session.reveal ? '<section class="challenge-reveal" data-challenge-solution><h3>الدائرة المرجعية</h3>' + wiringDiagram(task) +
        '<p>' + task.test + '</p><details class="engineering-detail"><summary>الكود المرجعي</summary><pre class="mission-code" dir="ltr">' +
        escape(task.code) + '</pre>' + actions('download','تنزيل .ino') + '</details></section>' : '') + '</article>';
  }
  function render() {
    if (!session.host?.isConnected) return;
    const task = taskOf(session.id);
    session.host.innerHTML = task ? selectedPanel(task) : votePanel();
    context();
  }
  function select(id) {
    if (!taskOf(id)) return;
    Object.assign(session,{id,minutes:25,seconds:1500,deadline:0,phase:'ready',hint:0,reveal:false});
  }
  function mount(host) {
    session.host = host;
    host.addEventListener('change',event => {
      const { challengeVote } = event.target.dataset;
      if (challengeVote) {
        const votes = globalThis.Journey.read('votes',{});
        votes[challengeVote] = Math.min(9999,Math.max(0,Math.trunc(Number(event.target.value)) || 0));
        event.target.value = votes[challengeVote];
        globalThis.Journey.write('votes',votes);
      }
      if (event.target.hasAttribute('data-challenge-minutes')) {
        session.minutes = Math.min(180,Math.max(1,Math.trunc(Number(event.target.value)) || 25));
        session.seconds = session.minutes*60;
        session.deadline = session.phase === 'running' ? Date.now()+session.seconds*1000 : 0;
        if (session.phase === 'ended') session.phase = 'ready';
        session.reveal = false;
        render();
        host.querySelector('[data-challenge-minutes]')?.focus({preventScroll:true});
      }
    });
    host.addEventListener('click',event => {
      const part = event.target.closest('[data-challenge-action]');
      if (!part) return;
      const key = part.dataset.challengeAction;
      if (key === 'download' && session.reveal) {
        const task = taskOf(session.id);
        globalThis.JourneyMissions.downloadSketch('challenge-' + task.id,task.code);
        return;
      }
      if (key === 'choose') select(part.dataset.challengeId);
      if (key === 'winner') {
        const votes = globalThis.Journey.read('votes',{});
        const ranking = tasks.map(task => [task.id,Number(votes[task.id])||0]).sort((a,b) => b[1]-a[1]);
        if (!ranking[0][1] || ranking[0][1]===ranking[1][1]) {
          host.querySelector('[data-challenge-status]').textContent = ranking[0][1] ? 'تعادل التصويت. اختر أحد التحديات.' : 'أدخل أصوات القاعة.';
          return;
        }
        select(ranking[0][0]);
      }
      if (key === 'hint') session.hint = Math.min(3,session.hint+1);
      if (key === 'start' && session.phase !== 'ended') {
        session.deadline = Date.now()+session.seconds*1000;
        session.phase = 'running';
      }
      if (key === 'pause') Object.assign(session,{seconds:remaining(),deadline:0,phase:'paused'});
      if (key === 'extend') {
        const seconds = Math.min(180*60,remaining()+300);
        session.seconds = seconds;
        session.deadline = session.deadline ? Date.now()+seconds*1000 : 0;
        if (session.phase === 'ended') session.phase = 'paused';
        session.reveal = false;
      }
      if (key === 'reset') Object.assign(session,{seconds:session.minutes*60,deadline:0,phase:'ready',hint:0,reveal:false});
      if (key === 'finish') Object.assign(session,{seconds:0,deadline:0,phase:'ended'});
      if (key === 'reveal' && session.phase === 'ended') session.reveal = !session.reveal;
      if (key === 'back') {
        session.last = session.id;
        Object.assign(session,{id:'',seconds:1500,deadline:0,phase:'ready',hint:0,reveal:false});
      }
      render();
      (host.querySelector('[data-challenge-action="' + key + '"]:enabled') ??
        host.querySelector('[data-challenge-action]:enabled'))?.focus({preventScroll:true});
    });
    render();
  }
  setInterval(() => {
    if (!session.deadline) return;
    const seconds = remaining();
    if (!seconds) {
      Object.assign(session,{seconds:0,deadline:0,phase:'ended'});
      render();
      return;
    }
    const output = session.host?.querySelector('[data-challenge-time]');
    if (output?.isConnected) output.textContent = timeText(seconds);
  },250);
  function reality(id) {
    const task = taskOf(id) || taskOf(session.id) || taskOf(session.last) || tasks[0];
    const projectPhotos = {
      lighting:[['ldr','حساس الضوء'],['led','LED'],['resistor','مقاومة']],
      parking:[['ultrasonic','HC-SR04'],['servo','Servo Motor'],['lab-aa4','مصدر تغذية']],
      fan:[['lab-fan','مروحة DC'],['temp','TMP36'],['mosfet','MOSFET']],
    };
    return '<header class="scene-heading"><div><h1 id="scene-title"><bdi>From Simulation to Reality</bdi></h1><p>من المحاكاة إلى الواقع</p></div></header>' +
      '<nav class="mission-tools" aria-label="اختر مشروع التنفيذ الحقيقي">' + tasks.map(item =>
        '<a class="secondary-button" href="#journey/reality/' + item.id + '"' + (item === task ? ' aria-current="page"' : '') +
        '><bdi>' + item.en + '</bdi></a>').join('') + '</nav>' +
      '<div class="surface day2-reality"><div><h2>' + task.title + '</h2>' + list(task.parts) + '</div>' +
      '<div class="day2-reality-photos" aria-label="صور القطع في مشروع ' + task.title + '">' +
      projectPhotos[task.id].map(([file,label]) => '<figure><img src="assets/photos/' + file + '.webp" alt="' +
        label + '" decoding="async"><figcaption><bdi>' + label + '</bdi></figcaption></figure>').join('') + '</div></div>';
  }
  globalThis.Day2Challenges = {mount,clock,reality, selected:id=>(taskOf(id) || taskOf(session.id) || taskOf(session.last) || tasks[0]).id};
})();
