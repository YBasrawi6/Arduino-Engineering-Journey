(() => {
  'use strict';
  const scenes = globalThis.JourneyData;
  const { format, escape, setGuidance, toggleGuideDetails } = globalThis.Workshop;
  const deck = document.getElementById('journey-page');
  const explorer = document.getElementById('explorer-page');
  const boardWorkspace = explorer.querySelector('.workspace');
  const lesson = document.getElementById('lesson-page');
  const dialog = document.getElementById('deck-dialog');
  const media = matchMedia('(prefers-reduced-motion: reduce)');
  const state = {
    scene:'welcome', detail:'', previous:'welcome', spark:false, pulse:null, blink:null, blinking:false, frame:false,
    routeKind:'journey', context:null, practiceReturn:'',
  };
  const keyPrefix = 'arduino-workshop-restored:';
  function read(key, fallback) {
    try { return JSON.parse(localStorage.getItem(keyPrefix + key)) ?? fallback; }
    catch { return fallback; }
  }
  function write(key, value) {
    try { localStorage.setItem(keyPrefix + key, JSON.stringify(value)); }
    catch { /* Offline file contexts may disable persistence. */ }
  }
  let reduce = read('reduced-motion',media.matches);
  const sceneInfo = id => scenes.find(scene => scene.id === id);
  const deckLink = (id, label, cls = 'secondary-button') => '<a class="' + cls + '" href="#journey/' + id + '">' + label + '</a>';
  const action = (id, title, cls = 'secondary-button', options = '') =>
    '<button type="button" class="' + cls + '" data-deck-action="' + id + '"' + options + '>' + title + '</button>';
  const heading = (title, kicker, description) =>
    '<header class="scene-heading"><div><p class="eyebrow"><bdi>' + kicker + '</bdi></p><h1 id="scene-title">' + format(title) + '</h1>' +
    (description ? '<p>' + format(description) + '</p>' : '') + '</div></header>';
  const figure = (image, alt) => '<img src="assets/photos/' + image + '.webp" alt="' + escape(alt) + '">';
  const boardArt = (extra = '') => '<div class="board-art ' + extra + '"><div class="board-shadow"><img src="assets/uno-r3.jpg" alt="صورة حقيقية للوحة Arduino Uno R3" decoding="async"></div></div>';
  const paragraph = value => '<p>' + format(value) + '</p>';

  function welcome() {
    const resume = read('day1-position','');
    const recent = typeof resume === 'string' ? sceneInfo(resume.split('/')[0]) : null;
    return '<div class="welcome-scene"><div class="hero-copy"><p class="eyebrow"><bdi>THE ENGINEERING JOURNEY</bdi></p>' +
      '<h1 id="scene-title"><bdi>Arduino</bdi><span>من الفكرة إلى التنفيذ</span></h1>' +
      '<p class="hero-intro">ورشة تطبيقية في الإلكترونيات وتصميم الدوائر باستخدام الأردوينو والذكاء الاصطناعي</p>' +
      '<div class="hero-credit"><span>نادي الهندسة الكهربائية — جامعة الملك عبدالعزيز</span><strong>إعداد وتقديم يوسف بصراوي</strong></div>' +
      '<div class="hero-actions">' + deckLink('spark','ابدأ الرحلة <bdi>START EXPERIENCE</bdi>','primary-button start-button') +
      '<a href="#explorer" class="secondary-button">استكشف اللوحة مباشرة</a></div>' +
      (recent && recent.id !== 'spark' ? '<p class="resume-line">' + deckLink(resume,'تابع من ' + escape(recent.title),'text-button') + '</p>' : '') +
      '</div><div class="hero-visual"><div class="hero-glow"></div>' + boardArt('hero-board') +
      '<p class="hero-bench-label"><bdi>ARDUINO UNO REV3</bdi><span>لوحة الورشة</span></p></div></div>';
  }

  function circuit(automatic) {
    return '<div class="circuit-bench" data-circuit-state="off">' +
      '<svg class="spark-svg" viewBox="0 0 640 315" role="img" aria-label="' + (automatic ? 'دائرة خرج D8 ومقاومة ومصباح إلى الأرضي' : 'دائرة مصدر 5 فولت وزر ومقاومة ومصباح على التوالي') + '">' +
      '<path class="spark-wire" d="M94 124V71H195m66 0h80m82 0h95v74m0 55v48H94v-69"/>' +
      '<path class="spark-current" d="M94 124V71h424v177H94v-69"/>' +
      (automatic ? '<rect class="board-drive" x="45" y="120" width="98" height="64" rx="8"/><text x="94" y="153" text-anchor="middle">UNO</text>' :
      '<path class="symbol" d="M75 126h38m-27 11h16m-27 14h38m-27 11h16m-8 0v17m0-55v2"/>') +
      '<rect class="circuit-res" x="341" y="55" rx="8" width="82" height="32"/><path class="res-bands red" d="M355 56v30m15-30v30"/><path class="res-bands brown" d="M387 56v30"/><path class="res-bands gold" d="M406 56v30"/>' +
      '<circle cx="195" cy="71" r="6" class="wire-joint"/><circle cx="261" cy="71" r="6" class="wire-joint"/>' +
      (automatic ? '<path class="symbol" d="M195 71h66"/><text x="228" y="37" text-anchor="middle">Digital Output</text>' :
      '<path class="switch-arm" d="M195 71l66-31"/><text x="228" y="110" text-anchor="middle">زر لحظي</text>') +
      '<path class="symbol led-symbol" d="M518 145V155 M498 155H538L518 187Z M498 187H538 M518 187V200"/><path class="symbol led-rays" d="m545 164 16-13m-4 2 4-2-1 6m-14 27 16-13m-4 2 4-2-1 6"/><circle class="led-bloom" cx="523" cy="172" r="36"/>' +
      '<text x="53" y="211">GND</text><text x="57" y="107">' + (automatic ? 'D8' : '5 V') + '</text><text x="382" y="42" text-anchor="middle">220 Ω</text><text x="540" y="228">LED</text>' +
      '</svg><div class="circuit-controls">' +
      (automatic ? action('blink','شغّل الوميض','secondary-button',' aria-pressed="false"') :
      action('spark','اضغط الزر','push-button',' aria-pressed="false"')) +
      '<output class="circuit-output" data-led-status>المصباح مطفأ</output></div></div>';
  }
  function spark() {
    return '<header class="scene-heading final-scene-title"><h1 id="scene-title" dir="ltr">First Spark</h1></header>' +
      '<div class="stage-grid final-spark">' + circuit(false) +
      '<div class="stage-copy surface"><h2>كيف نشغّل الـLED؟</h2>' +
      '<div class="initial-tip" data-spark-tip>' + action('spark-reveal','اكشف الإجابة') + '</div>' +
      '<p data-spark-answer hidden>يغلق الزر مسار التيار. تحدّ المقاومة من التيار الذي يمر في الـLED.</p>' +
      '<div class="spark-question" data-spark-question' + (state.spark ? '' : ' hidden') + '>' +
      '<h3>كيف نخلي الـLED تومض وحدها؟</h3>' + deckLink('automatic','Blink','primary-button') +
      '</div></div></div>';
  }
  function automatic() {
    return '<header class="scene-heading final-scene-title"><h1 id="scene-title" dir="ltr">Blink</h1></header>' +
      '<div class="stage-grid auto-grid">' + circuit(true) + '<div class="stage-copy surface auto-board">' +
      boardArt() + action('reveal-flow','اكشف طريقة الوميض','secondary-button',' aria-expanded="false"') + '</div></div>' +
      '<div class="io-flow" data-flow hidden><div><bdi>Input</bdi><p>مثال قراءة زر. في مثال الوميض نعتمد على مؤقت Arduino.</p></div>' +
      '<div><bdi>Processing</bdi><p>ينفّذ البرنامج القاعدة، مثل تبديل المخرج كل ثانية.</p></div>' +
      '<div><bdi>Output · D8</bdi><p>تتبدّل إشارة D8 فتضيء LED وتنطفئ.</p></div></div>';
  }

  function adc() {
    return '<div class="surface model-panel adc-panel"><div><h2>كم يقرأ <bdi>A0</bdi>؟</h2>' +
      paragraph('لفّ [Potentiometer] لتغيير الجهد على [A0].') + '</div>' +
      '<div class="adc-input"><label for="guided-adc">جهد المنزلق</label><input id="guided-adc" type="range" min="0" max="5" step=".05" value="2.5">' +
      '<output data-adc-voltage><bdi>2.50 V</bdi></output></div><div class="reading-panel"><span><bdi>analogRead(A0)</bdi></span><output data-adc-read>512</output></div>' +
      '<details class="engineering-detail" data-advanced><summary>اعرف أكثر عن 10 بت وAREF</summary>' +
      paragraph('عند مرجع [5 V] تكون خطوة القياس حوالي [4.88 mV]. القيمة المعروضة تقريبية. [AREF] يحدد مرجع القياس عند اختيار المرجع الخارجي وإعداد البرنامج له.') +
      paragraph('المدخل التناظري يقيس الجهد. تعديل عرض النبضة [PWM] يغيّر زمن الحالة المرتفعة في خرج رقمي.') + '</details></div>';
  }
  function guidedBoard(scene) {
    const expl = scene.id === 'explorer';
    const details = {
      power:'اكشف VIN وReset وIOREF ومصادر الطاقة',digital:'اعرض PWM وUART وInterrupt وSPI',analog:'اكشف AREF وناقل I2C',
    };
    const supplements = {
      arduino:'<div class="guided-regions">' + deckLink('power','منطقة التغذية') + deckLink('digital','Digital I/O') + deckLink('analog','Analog Input') + '</div>',
      power:'<details class="engineering-detail surface model-panel" data-advanced><summary>المسار المغلق ومداخل التغذية</summary>' +
        paragraph('مصدر الطاقة يغذي القطعة، ويرجع التيار عبر [GND]. يمكنك تغذية اللوحة من [USB] أو مقبس [DC] أو [VIN] وفق حدود اللوحة.') + '</details>',
      digital:'<div class="surface io-quick"><div><strong>Digital Input</strong>' +
        paragraph('ينتظر [D2] إشارة الزر. مع [INPUT_PULLUP] تثبّت [Pull-up Resistor] القراءة على [HIGH]. عند ضغط الزر إلى [GND] يقرأ [LOW].') +
        '</div><div><strong>Digital Output</strong>' + paragraph('يبدّل [D8] بين [HIGH] و[LOW] لتشغيل مصباح بمقاومة.') + '</div></div>',
      analog:adc(),
    };
    return heading(scene.title,scene.en,scene.goal) + '<div class="guided-control">' +
      (details[scene.id] ? action('guide-details',details[scene.id],'secondary-button',' aria-pressed="false"') : '') +
      (expl ? '<a class="secondary-button" href="assets/uno-r3-pinout.pdf" target="_blank" rel="noopener">مخطط المنافذ PDF</a>' : '') +
      (scene.id === 'arduino' ? supplements.arduino : '') + '</div><div data-board-slot></div>' +
      (scene.id === 'arduino' ? '' : (supplements[scene.id] ?? ''));
  }

  function supplies() {
    return '<div class="power-stage"><section class="surface model-panel battery-panel"><h2>ماذا يحدث للجهد تحت الحمل؟</h2>' +
      '<p>زِد التيار وشاهد كيف يتغير جهد البطارية.</p>' +
      '<div class="battery-images"><figure>' + figure('lab-pp3','بطارية مستطيلة 9 فولت') + '<figcaption><bdi>9 V PP3</bdi></figcaption></figure>' +
      '<figure>' + figure('lab-aa4','حزمة أربع بطاريات AA') + '<figcaption><bdi>4 × AA</bdi></figcaption></figure></div>' +
      '<label class="range-row" for="load-current">تيار مفترض للحمل <output data-current>100 mA</output></label>' +
      '<input id="load-current" type="range" min="0" max="900" step="25" value="100">' +
      '<div class="battery-readings"><div><bdi>PP3</bdi><strong data-pp3>7.80 V</strong><span class="meter"><i data-pp3-bar></i></span></div>' +
      '<div><bdi>4 × AA</bdi><strong data-aa>5.92 V</strong><span class="meter"><i data-aa-bar></i></span></div></div>' +
      '<details class="engineering-detail" data-advanced><summary>اعرف أكثر عن نموذج الهبوط</summary>' +
      paragraph('[Vload = Voc − I × Rinternal]. القيم الافتراضية [9 V / 12 Ω] و[6 V / 0.8 Ω] للتعليم، وتختلف باختلاف البطارية وكيميائها وعمرها وحرارتها. النموذج يقص القيم السالبة عند الصفر. اختر مصدرًا بمواصفات وقياسات ملائمة لجهد محركك وتيار إقلاعه.') + '</details></section>' +
      '<section class="surface model-panel common-panel"><h2>نقطة صفر مشتركة</h2>' +
      paragraph('اربط الأرضيين حتى يفهم Motor Driver إشارة Arduino.') +
      '<svg class="ground-model" viewBox="0 0 460 195" role="img" aria-label="توصيل تحكم بين Arduino وMOSFET ومصدر محرك منفصل"><rect x="13" y="29" width="130" height="50" rx="8"/><rect x="189" y="29" width="95" height="50" rx="8"/><rect x="322" y="29" width="125" height="50" rx="8"/>' +
      '<text x="78" y="59">Uno D9</text><text x="235" y="59">MOSFET</text><text x="384" y="54">DC + MOTOR</text><text x="384" y="70" class="mini-text">دائرة المحرك</text>' +
      '<path class="signal-wire" d="M143 54h46"/><path class="load-wire" d="M284 54h38"/><path class="load-wire" d="M235 79v67h149V79"/>' +
      '<path class="ground-wire" d="M78 79v67h63m48 0h46"/><path class="ground-bridge" d="M141 146h48"/><circle cx="235" cy="146" r="4"/><text x="78" y="174">UNO GND</text><text x="380" y="174">DC (−)</text></svg>' +
      action('common','اربط الأرضي المشترك','primary-button',' aria-pressed="false"') + '<p data-common-result class="interaction-result" role="status">إشارة Gate بلا مرجع مشترك.</p>' +
      '<details class="engineering-detail" data-advanced><summary>الحماية وتغذية المحرك</summary><p>استخدم دايود حماية على طرفي المحرك الأحادي الاتجاه، كاثوده عند الموجب. غذِّ المحرك من مصدره. نربط السالبين هنا لمرجع الإشارة مع إبقاء الخطين الموجبين منفصلين.</p></details></section></div>' +
      '<div data-lab-slot></div><div data-lesson-slot></div>';
  }

  const embedded = { breadboard:'wiring' };
  const labGroups = {components:'resistive', sensors:'sensors', motors:'motors', displays:'displays', supply:'power'};
  const boardScenes = ['arduino','power','digital','analog','explorer'];
  const practical = ['day2','review','build','practice','final-challenge','reality'];
  const original = ['day1','spark','automatic',...boardScenes,'breadboard','supply','components','sensors','motors','displays',
    'build-reference','projects','challenges'];
  const extras = ['quick','library'];
  function recordings(scene) {
    return heading(scene.title,scene.en,'') + '<div class="day2-paths">' +
      [['day1','اليوم الأول'],['day2','اليوم الثاني']].map(([id,title]) => {
        const url = globalThis.StudentLinks.recording(id);
        return '<article class="surface day2-intro-card"><h2>' + title + '</h2>' +
          (url ? '<a class="secondary-button" href="' + escape(url) + '" target="_blank" rel="noopener">شاهد على YouTube</a>' :
          '<p>يُضاف رابط التسجيل عند توفره.</p>') + '</article>';
      }).join('') + '</div>';
  }
  function sceneBody(scene,detail) {
    const intro = globalThis.Day2Intro;
    if (scene.id === 'welcome') return intro.home();
    if (scene.id === 'day1') return welcome();
    if (scene.id === 'day2') return intro.start();
    if (scene.id === 'recordings') return recordings(scene);
    if (scene.id === 'quick') return intro.quick();
    if (scene.id === 'library') {
      if (Object.hasOwn(globalThis.JourneyLabData.items,detail)) {
        return heading('المكتبة الهندسية','ENGINEERING LIBRARY','') + '<div data-lab-slot></div>';
      }
      return intro.library(detail);
    }
    if (scene.id === 'reality') return globalThis.Day2Challenges.reality(detail);
    if (scene.id === 'spark') return spark();
    if (scene.id === 'automatic') return automatic();
    if (scene.id === 'build-reference') return globalThis.HotfixBuild.render(detail).replaceAll('#journey/build/','#journey/build-reference/');
    if (boardScenes.includes(scene.id)) return guidedBoard(scene);
    let extra = '';
    if (scene.id === 'review') return '<div data-day2-review></div>';
    if (scene.id === 'build') return '<div data-day2-build></div>';
    if (scene.id === 'practice') return '<div data-day2-practice></div>';
    if (scene.id === 'final-challenge') extra = '<div data-day2-challenge></div>';
    else if (scene.id === 'supply') extra = detail === 'explore' ?
      deckLink('supply','العودة إلى Power Bench') + supplies() : globalThis.FinalPower.render();
    else if (scene.id === 'breadboard') extra = '<div data-lesson-slot></div>';
    else if (labGroups[scene.id]) extra = '<div data-lab-slot></div>';
    else if (scene.id === 'projects') extra = '<div data-mission-slot></div>';
    else if (scene.id === 'challenges') extra = '<div data-challenge-slot></div>';
    return heading(scene.title,scene.en,scene.goal) + extra;
  }

  function ribbon(scene) {
    if (scene.id === 'welcome' || scene.id === 'day1') return '';
    const modern = practical.includes(scene.id) || extras.includes(scene.id);
    const last = ['challenges','reality'].includes(scene.id);
    const returnLink = state.practiceReturn && scene.id !== 'practice' ? deckLink('practice/' + state.practiceReturn,'العودة إلى المشروع','primary-button') : '';
    return '<nav class="scene-ribbon" aria-label="التنقل بين مشاهد الرحلة">' +
      action('prev','السابق','secondary-button') +
      '<div class="final-quick-nav">' + action('map','الأقسام') + returnLink +
      (modern ? deckLink('library','المكتبة') + deckLink('practice','المشاريع') + deckLink('final-challenge','التحدي') :
        deckLink('components','المكونات') + deckLink('projects','المشاريع')) + '</div>' +
      (last ? deckLink('welcome','الرئيسية') : action('next','التالي','primary-button')) + '</nav>';
  }
  function release() {
    globalThis.JourneyLab.leave();
    clearTimeout(state.pulse);
    clearInterval(state.blink);
    state.blink = null;
    if (boardWorkspace.parentElement !== explorer) explorer.append(boardWorkspace);
    if (lesson.parentElement !== deck.parentElement) deck.parentElement.append(lesson);
  }
  function activate(id, detail) {
    const scene = sceneInfo(id) ?? scenes[0];
    state.previous = state.scene;
    if (state.scene === 'practice' && scene.id === 'library') {
      state.practiceReturn = state.context?.id || state.detail || '';
    }
    if (scene.id === 'practice' || scene.id === 'welcome' || scene.id === 'day1' || scene.id === 'day2') state.practiceReturn = '';
    state.scene = scene.id;
    state.detail = detail;
    state.routeKind = 'journey';
    state.context = null;
    const embeddedPage = scene.id === 'supply' && detail === 'explore' ? 'power' : embedded[scene.id];
    document.body.dataset.route = 'journey';
    document.body.dataset.scene = scene.id;
    if (original.includes(scene.id) && scene.id !== 'day1') write('day1-position',scene.id + (detail ? '/' + detail : ''));
    deck.hidden = false;
    deck.setAttribute('aria-labelledby','scene-title');
    deck.innerHTML = '<div class="scene-body">' + sceneBody(scene,detail) + '</div>' + ribbon(scene);
    if (boardScenes.includes(scene.id)) {
      deck.querySelector('[data-board-slot]').append(boardWorkspace);
      setGuidance(scene.id === 'explorer' ? '' : scene.id);
      globalThis.Workshop.refreshContext();
    } else setGuidance('');
    if (embeddedPage) {
      deck.querySelector('[data-lesson-slot]').append(lesson);
      lesson.hidden = false;
    }
    const labSlot = deck.querySelector('[data-lab-slot]');
    if (labSlot) globalThis.JourneyLab?.mount(labSlot, {group:labGroups[scene.id], detail, scene:scene.id});
    const reviewSlot = deck.querySelector('[data-day2-review]');
    if (reviewSlot) globalThis.Day2Intro.review(reviewSlot);
    const buildSlot = deck.querySelector('[data-day2-build]');
    if (buildSlot) globalThis.Day2Intro.build(buildSlot,detail);
    const practiceSlot = deck.querySelector('[data-day2-practice]');
    if (practiceSlot) globalThis.Day2Projects.mount(practiceSlot,detail);
    const day2Challenge = deck.querySelector('[data-day2-challenge]');
    if (day2Challenge) globalThis.Day2Challenges.mount(day2Challenge);
    const missions = globalThis.JourneyMissions;
    const missionSlot = deck.querySelector('[data-mission-slot]');
    if (missionSlot) missions?.mountMissions(missionSlot,detail);
    const challengeSlot = deck.querySelector('[data-challenge-slot]');
    if (challengeSlot) missions?.mountChallenges(challengeSlot);
    if (scene.id === 'automatic') startBlink(false);
    if (scene.id === 'supply' && detail === 'explore') drawBattery();
    if (scene.id === 'build-reference') {
      const steps = globalThis.HotfixBuild.ids;
      globalThis.PresentationData.publish({kind:'build',phase:steps.includes(detail) ? detail : steps[0]});
    } else if (scene.id === 'reality') {
      globalThis.PresentationData.publish({kind:'reality',id:globalThis.Day2Challenges.selected(detail)});
    }
    return embeddedPage || '';
  }
  function free(page) {
    state.routeKind = 'free';
    state.context = null;
    state.scene = {electronics:'components',modules:'sensors',power:'supply',wiring:'breadboard',projects:'projects',
      challenges:'challenges',ai:'projects'}[page] || 'explorer';
    deck.hidden = true;
    document.body.dataset.route = 'free';
    delete document.body.dataset.scene;
    setGuidance('');
  }
  function goto(delta) {
    if ([...practical,'build-reference'].includes(state.scene) && advanceInside(delta)) return;
    const path = practical.includes(state.scene) ? ['welcome',...practical] : ['welcome',...original];
    const index = path.indexOf(state.scene);
    const next = index < 0 ? (delta < 0 ? 'day2' : 'practice') : path[Math.max(0,index+delta)];
    if (next && next !== state.scene) location.hash = 'journey/' + next;
  }
  function advance() {
    if (state.scene === 'spark' && !state.spark) {
      ignite();
      return;
    }
    const flow = deck.querySelector('[data-flow]');
    if (state.scene === 'automatic' && flow?.hidden) revealFlow();
    else goto(1);
  }
  function advanceInside(delta) {
    const scope = state.routeKind === 'journey' ? deck : document.querySelector('main');
    const button = scope.querySelector(delta > 0 ? '[data-show-next]' : '[data-show-prev]');
    if (!button || button.disabled || !button.getClientRects().length) return false;
    button.click();
    return true;
  }
  function setLit(on) {
    const circuit = deck.querySelector('.circuit-bench');
    if (!circuit) return;
    circuit.dataset.circuitState = on ? 'on' : 'off';
    circuit.querySelector('[data-led-status]').textContent = on ? 'المصباح مضاء' : 'المصباح مطفأ';
    circuit.querySelector('[data-deck-action="spark"]')?.setAttribute('aria-pressed',String(on));
  }
  function showQuestion() {
    state.spark = true;
    deck.querySelector('[data-spark-question]').hidden = false;

  }
  function ignite() {
    clearTimeout(state.pulse);
    setLit(true);
    showQuestion();
    state.pulse = setTimeout(() => setLit(false),720);
  }
  function revealFlow() {
    deck.querySelector('[data-flow]').hidden = false;
    deck.querySelector('[data-deck-action="reveal-flow"]').hidden = true;
  }
  function startBlink(enabled) {
    clearInterval(state.blink);
    state.blink = null;
    state.blinking = enabled;
    state.frame = enabled;
    setLit(state.frame);
    const button = deck.querySelector('[data-deck-action="blink"]');
    if (!button) return;
    button.textContent = enabled ? 'أوقف الوميض' : 'شغّل الوميض';
    button.setAttribute('aria-pressed',String(enabled));
    if (enabled) state.blink = setInterval(() => { state.frame = !state.frame; setLit(state.frame); },1000);
  }
  function drawBattery() {
    const current = Number(deck.querySelector('#load-current').value);
    const pp3 = Math.max(0,9 - current / 1000 * 12);
    const aa = Math.max(0,6 - current / 1000 * .8);
    deck.querySelector('[data-current]').textContent = current + ' mA';
    deck.querySelector('[data-pp3]').textContent = pp3.toFixed(2) + ' V';
    deck.querySelector('[data-aa]').textContent = aa.toFixed(2) + ' V';
    deck.querySelector('[data-pp3-bar]').style.width = pp3 / 9 * 100 + '%';
    deck.querySelector('[data-aa-bar]').style.width = aa / 6 * 100 + '%';
  }

  function showDialog(kind) {
    dialog.dataset.kind = kind;
    if (kind === 'map') {
      const categories = [...new Set(scenes.map(scene => scene.chapter))];
      dialog.innerHTML = '<div class="dialog-head"><h2 id="dialog-title">خريطة الرحلة</h2>' + action('close','إغلاق','quiet-button') + '</div><div class="map-grid">' +
        categories.map(chapter => '<div><h3>' + chapter + '</h3>' + scenes.filter(scene => scene.chapter === chapter).map(scene =>
          deckLink(scene.id,escape(scene.title),scene.id===state.scene?'map-current':'map-entry')).join('') + '</div>').join('') +
        '</div><p><a href="#explorer">افتح المستكشف الحر</a></p>';
    } else {
      dialog.innerHTML = '<div class="dialog-head"><h2 id="dialog-title">المساعدة والإعدادات</h2>' + action('close','إغلاق','quiet-button') +
        '</div><div class="settings-actions">' + action('motion',reduce?'شغّل الحركات':'قلّل الحركات','secondary-button',' aria-pressed="' + reduce + '"') +
        '</div>' +
        '<dl class="shortcut-list"><div><dt>← / →</dt><dd>التالي / السابق في العرض العربي</dd></div><div><dt>Space</dt><dd>اكشف الخطوة أو انتقل</dd></div>' +
        '<div><dt>M</dt><dd>خريطة الرحلة</dd></div><div><dt>D</dt><dd>التفاصيل المتقدمة</dd></div><div><dt>R</dt><dd>تقليل الحركة</dd></div>' +
        '<div><dt>Esc</dt><dd>إغلاق التفاصيل</dd></div></dl><p><a href="Start-Here.txt">دليل تشغيل النسخة المحلية</a></p>';
    }
    if (!dialog.open) dialog.showModal();
  }

  function setMotion(next,remember=true) {
    reduce = next;
    document.documentElement.dataset.reduced = String(reduce);
    if (remember) write('reduced-motion',reduce);
    if (reduce && state.scene === 'automatic') startBlink(false);
    const button = dialog.querySelector('[data-deck-action="motion"]');
    if (button) {
      button.textContent = reduce ? 'شغّل الحركات' : 'قلّل الحركات';
      button.setAttribute('aria-pressed',String(reduce));
    }
  }
  document.addEventListener('journey:context',event => { state.context = event.detail; });
  const advancedToggle = () => {
    const block = (state.routeKind === 'journey' ? deck : document.querySelector('#main')).querySelector('[data-advanced]');
    if (block) { block.open = !block.open; return true; }
    return false;
  };
  document.addEventListener('keydown',event => {
    if (event.defaultPrevented || event.ctrlKey || event.metaKey || event.altKey) return;
    const target = event.target;
    if (target instanceof Element && target.closest('input,select,textarea,[contenteditable]')) return;
    const key = event.key.toLowerCase();
    if (key === 'escape') {
      if (dialog.open) { dialog.close(); return; }
      const detail = document.querySelector('main details[data-advanced][open]');
      if (detail) { detail.open = false; event.preventDefault(); return; }
      return;
    }
    if (key === 'm') { event.preventDefault(); showDialog('map'); }
    if (key === 'r') { event.preventDefault(); setMotion(!reduce); }
    if (key === 'd' && advancedToggle()) event.preventDefault();
    if (dialog.open || state.routeKind !== 'journey' || (target instanceof Element && target.closest('#board-viewport,.breadboard-diagram'))) return;
    if (key === 'arrowleft' || key === 'arrowright') {
      event.preventDefault();
      const delta = key === 'arrowleft' ? 1 : -1;
      goto(delta);
    } else if (key === ' ' && !(target instanceof Element && target.closest('button,a,summary,[role=button]'))) {
      event.preventDefault();
      advance();
    }
  });
  document.addEventListener('click',event => {
    if (dialog.open && event.target.closest('#deck-dialog a[href^="#"]')) dialog.close();
    const button = event.target.closest('[data-deck-action]');
    if (!button) return;
    switch (button.dataset.deckAction) {
      case 'map': case 'help': showDialog(button.dataset.deckAction); break;
      case 'close': dialog.close(); break;
      case 'prev': goto(-1); break;
      case 'next': goto(1); break;
      case 'spark': ignite(); break;
      case 'spark-reveal':
        deck.querySelector('[data-spark-answer]').hidden = false;
        deck.querySelector('[data-spark-tip]').hidden = true;
        showQuestion();
        break;
      case 'blink': startBlink(!state.blinking); break;
      case 'reveal-flow': revealFlow(); break;
      case 'motion': setMotion(!reduce); break;
      case 'guide-details': button.setAttribute('aria-pressed',String(toggleGuideDetails())); break;
      case 'power-explore': location.hash = 'journey/supply/explore'; break;
      case 'common': {
        const grounded = button.getAttribute('aria-pressed') !== 'true';
        button.setAttribute('aria-pressed',String(grounded));
        button.textContent = grounded ? 'افصل الأرضي المشترك' : 'اربط الأرضي المشترك';
        button.closest('.common-panel').classList.toggle('grounded',grounded);
        deck.querySelector('[data-common-result]').textContent = grounded ? 'Arduino والدرايفر يقيسان الإشارة من نفس نقطة الصفر.' : 'إشارة Gate بلا مرجع مشترك.';
        break;
      }
    }
  });
  deck.addEventListener('input',event => {
    if (event.target.id === 'guided-adc') {
      const v = Number(event.target.value);
      deck.querySelector('[data-adc-voltage] bdi').textContent = v.toFixed(2) + ' V';
      deck.querySelector('[data-adc-read]').textContent = Math.min(1023,Math.floor(v / 5 * 1024));
    }
    if (event.target.id === 'load-current') drawBattery();
  });
  media.addEventListener('change',event => { if (read('reduced-motion',null) === null) setMotion(event.matches,false); });
  document.documentElement.dataset.reduced = String(reduce);
  globalThis.Journey = { release, activate, free, read, write, showDialog, isReduced:() => reduce };
})();
