globalThis.PhotoCredits = {
  "resistor": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/2780",
    "origin": "https://cdn-shop.adafruit.com/970x728/2780-03.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "pot": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/562",
    "origin": "https://cdn-shop.adafruit.com/970x728/562-04.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "capacitor": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/1589",
    "origin": "https://cdn-shop.adafruit.com/970x728/1589-05.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "diode": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/755",
    "origin": "https://cdn-shop.adafruit.com/970x728/755-02.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "led": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/299",
    "origin": "https://cdn-shop.adafruit.com/970x728/299-04.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "inductor": {
    "source": "enigma-shop.com",
    "page": "https://enigma-shop.com/products/leaded-inductors",
    "origin": "https://enigma-shop.com/cdn/shop/files/0410Inductor.jpg?v=1690150045&width=1445",
    "rights": "enigma-shop.com · غير موثّق كترخيص مفتوح"
  },
  "transistor": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/756",
    "origin": "https://cdn-shop.adafruit.com/970x728/756-08.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "mosfet": {
    "source": "www.smartkits.com.br",
    "page": "https://www.smartkits.com.br/transistor-mosfet",
    "origin": "https://images.tcdn.com.br/img/img_prod/751846/transistor_mosfet_irlz44n_canal_n_8738_1_e05c5a3e38554a0b920d2724cb7d7a40.jpg",
    "rights": "www.smartkits.com.br · غير موثّق كترخيص مفتوح"
  },
  "relay": {
    "source": "SparkFun",
    "page": "https://www.sparkfun.com/relay-spdt-sealed.html",
    "origin": "https://www.sparkfun.com/media/catalog/product/0/0/00100-02c.jpg?optimize=low&bg-color=255,255,255&fit=bounds&height=&width=&canvas=:",
    "rights": "SparkFun · غير موثّق كترخيص مفتوح"
  },
  "button": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/367",
    "origin": "https://cdn-shop.adafruit.com/970x728/367-02.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "latch": {
    "source": "hackspark.fr",
    "page": "https://hackspark.fr/en/switches-and-buttons/1084-self-locking-push-button-8x8mm-6-pin-switch-blue.html",
    "origin": "https://hackspark.fr/2778-large_default/self-locking-push-button-8x8mm-6-pin-switch-blue.jpg",
    "rights": "hackspark.fr · غير موثّق كترخيص مفتوح"
  },
  "buzzer": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/1536",
    "origin": "https://cdn-shop.adafruit.com/970x728/1536-08.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "ldr": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/161",
    "origin": "https://cdn-shop.adafruit.com/970x728/161-00.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "ir": {
    "source": "Joy-IT SensorKit",
    "page": "https://sensorkit.joy-it.net/en/sensors/ky-032",
    "origin": "https://sensorkit.joy-it.net/files/files/sensors/KY-032/KY-032.png",
    "rights": "Joy-IT SensorKit · غير موثّق كترخيص مفتوح"
  },
  "ultrasonic": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/3942",
    "origin": "https://cdn-shop.adafruit.com/970x728/3942-02.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "temp": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/165",
    "origin": "https://cdn-shop.adafruit.com/970x728/165-02.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "servo": {
    "source": "vueloverde.com",
    "page": "https://vueloverde.com/en/servos/126-servo-analogico-towerpro-sg90-9g-18kgcm-012s-60-48v.html",
    "origin": "https://vueloverde.com/325-thickbox_default/servo-analogico-towerpro-sg90-9g-18kgcm-012s-60-48v.jpg",
    "rights": "vueloverde.com · غير موثّق كترخيص مفتوح"
  },
  "driver": {
    "source": "SparkFun",
    "page": "https://www.sparkfun.com/sparkfun-full-bridge-motor-driver-breakout-l298n.html",
    "origin": "https://www.sparkfun.com/media/catalog/product/0/9/09540-03.jpg?optimize=low&bg-color=255,255,255&fit=bounds&height=&width=&canvas=:",
    "rights": "SparkFun · غير موثّق كترخيص مفتوح"
  },
  "relay-module": {
    "source": "Joy-IT SensorKit",
    "page": "https://sensorkit.joy-it.net/en/sensors/ky-019",
    "origin": "https://sensorkit.joy-it.net/files/files/sensors/KY-019/KY-019.png",
    "rights": "Joy-IT SensorKit · غير موثّق كترخيص مفتوح"
  },
  "seven": {
    "source": "www.sunfounder.com",
    "page": "https://www.sunfounder.com/products/30pcs-0-56-7-segment-led",
    "origin": "https://www.sunfounder.com/cdn/shop/products/sunfounder-esp32-for-busy-people-default-title-30pcs-0-56-7-segment-led-display-1-digit-red-common-cathode-29950565351659.jpg?v=1768446911",
    "rights": "www.sunfounder.com · غير موثّق كترخيص مفتوح"
  },
  "lcd": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/1447",
    "origin": "https://cdn-shop.adafruit.com/970x728/1447-05.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "oled": {
    "source": "Joy-IT",
    "page": "https://joy-it.net/en/products/SBC-OLED01",
    "origin": "https://joy-it.net/files/files/Produkte/SBC-OLED01/SBC-OLED01-2.png",
    "rights": "Joy-IT · غير موثّق كترخيص مفتوح"
  },
  "pir": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/189",
    "origin": "https://cdn-shop.adafruit.com/970x728/189-05.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "jumper-mm": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/758",
    "origin": "https://cdn-shop.adafruit.com/970x728/758-04.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "jumper-mf": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/1954",
    "origin": "https://cdn-shop.adafruit.com/970x728/1954-02.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "jumper-ff": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/1950",
    "origin": "https://cdn-shop.adafruit.com/970x728/1950-02.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "breadboard-top": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/239",
    "origin": "https://cdn-shop.adafruit.com/970x728/239-08.jpg",
    "rights": "Adafruit · غير موثّق كترخيص مفتوح"
  },
  "breadboard-strip": {
    "source": "learn.sparkfun.com",
    "page": "https://learn.sparkfun.com/tutorials/how-to-use-a-breadboard/all",
    "origin": "https://cdn.sparkfun.com/assets/f/8/7/0/f/513a1dfbce395fe624000001.JPG",
    "rights": "SparkFun Learn · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)"
  },
  "breadboard-rails": {
    "source": "learn.sparkfun.com",
    "page": "https://learn.sparkfun.com/tutorials/how-to-use-a-breadboard/all",
    "origin": "https://cdn.sparkfun.com/assets/3/d/f/a/9/518c0b34ce395fea62000002.jpg",
    "rights": "SparkFun Learn · [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/)"
  },
  "relay-fan": {
    "source": "Arduino Project Hub",
    "page": "https://projecthub.arduino.cc/placitech/smart-fan-using-the-plug-and-make-kit-d88a63",
    "origin": "https://projects.arduinocontent.cc/a8ad7c49-a20f-4c6a-a7c3-2027656b53bd.jpg",
    "rights": "PLACITECH · غير موثّق كترخيص مفتوح"
  },
  "mpu6050": {
    "source": "Adafruit",
    "page": "https://www.adafruit.com/product/3886",
    "origin": "https://cdn-shop.adafruit.com/970x728/3886-10.jpg"
  },
  "bluetooth": {
    "source": "DFRobot",
    "page": "https://wiki.dfrobot.com/tel0026/",
    "origin": "https://dfimg.dfrobot.com/enshop/image/data/TEL0026/TEL0026_Main_01_1200x630.jpg.webp"
  },
  "rfid": {
    "source": "Joy-IT",
    "page": "https://joy-it.net/en/products/SBC-RFID-RC522",
    "origin": "https://joy-it.net/files/files/Produkte/SBC-RFID-RC522/SBC-RFID-RC522%20%284%29.png"
  },
  "blink-circuit": {
    "source": "دائرة الورشة المحفوظة في Tinkercad",
    "page": "https://www.tinkercad.com/things/hkwb3ehavzE-01-led-basics-digital-output"
  },
  "uno-r3": {
    "source": "Pololu",
    "page": "https://www.pololu.com/product/2191",
    "origin": "https://a.pololu-files.com/picture/0J7809.1200.jpg?d65cee02196bd7b33f47b44ea65180e5"
  }
};
